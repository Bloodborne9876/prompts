<lora:neg4all_bdsqlsz_V3.5:0.8:lbw=MIDD>, official wallpaper, hires, (absurdres:1.2), texture, depth of field, (skinny body, narrow waist:1.2), (thin thighs:1.2), shiny skin, shiny hair,  BREAK
white background , simple background BREAK
2girls , <lora:miyu_edelfelt_v1:0.7:lbw=OUTD>ccmiyu, short hair, beret, white headwear, hair ornament, small breasts, collarbone, neck ribbon, red ribbon, white sailor collar, white shirt, puffy sleeves, short sleeves, school uniform, pleated skirt, black skirt ,  flat chest,  small breasts,  loli , 9yo  , loafers,  white legwear, BREAK
2girls , <lora:illyasviel_von_einzbern_(fate_kaleid_liner)_v1:0.7:lbw=OUTD> aaillya, long hair, beret, white headwear, small breasts, school uniform, neck ribbon, white shirt, collared shirt, short sleeves, black skirt , flat chest,  small breasts,  loli , 9yo  , loafers,  white legwear,  BREAK


# JK
<lora:neg4all_bdsqlsz_V3.5:0.8:lbw=MIDD>, official wallpaper, hires, (absurdres:1.2), texture, depth of field, (skinny body, narrow waist:1.2), (thin thighs:1.2), shiny skin, shiny hair , on grass ,  in park ,  sitting ,   (knees together feet apart:1.4), pink or white panties,  pantyshot,  pleated skirt,  black skirt , (head tilt:1.3),  loli, teen, small breasts, (looking away:1.4),  speak,   flat chest, front , full body , (white socks ,  loafers,:1.3)    BREAK , sunset , wind hair ,  wind clothes 
3girls , school uniform, black serafuku,  blonde hair , red eyes , open mouth , smile , speak  , in park 
3girls , school uniform, white serafuku,   black hair , blue eyes , smile , open mouth,  laughing,  glasses,   


2girls , splashing,   from side ,  interaction of water , one eye closed,   platinum blonde hair, short hair,  braid , red eyes , orange eyes ,  multicolored eyes,  (pointy ears:1.2),  smile , in beautiful lake , wet hair,  wet body , singing,  open mouth,  12yo , flat chest,  small breasts,  loli ,   nude , naked , completely nude,  earing , hair clip  ,
sunlight,  lens flare,



1girls , splashing,  interaction of water ,  platinum blonde hair, long hair,  braid , red eyes , orange eyes ,  multicolored eyes,  (pointy ears:1.2),  medium breasts,  in beautiful lake , wet hair,  wet body , open mouth,  18yo ,  nude , naked , completely nude,  earing , hair clip  , surprised,   front , embarrassed,  covering breasts, 
sunlight,  lens flare,


1girls , splashing, front , (head tilt:1.2), smile ,  platinum blonde hair, short hair,  braid , red eyes , orange eyes ,  multicolored eyes,  (pointy ears:1.2),  in beautiful lake , wet hair,  wet body  , open mouth,  12yo ,  medium breasts,     nude , naked , completely nude,  earing , hair clip  , hands on hair 
sunlight,  lens flare , pussy , vaginal 
## 質問


## エルフ

### 1
1girls ,  front , (head tilt:1.2),  light smile , ?,   platinum blonde hair, short hair,  braid , red eyes , orange eyes ,  multicolored eyes,  (pointy ears:1.2),  in park bench , in village,  from side , cleavage , hemp robe , simple white  robe 
sunlight,  lens flare  , open mouth, 

### 黒髪

best quality, masterpiece, very aesthetic, absurdres , (ultrahigh resolution textures), bokeh, intricate details, hyperdetailed, (official art, extreme detailed,) ( highest detailed), HDR+ BREAK
1girls ,  front , standing , platinum blonde hair, short hair,  braid , red eyes , orange eyes ,  multicolored eyes,  (pointy ears:1.2), on grass, in village,  from side , cleavage , hemp robe , simple white  robe , black obi ,   mini skirt , 
sunlight,  lens flare  , open mouth,  looking at viewer,  smile , 

### sex
score_9, score_8_up, score_7_up, best quality, masterpiece, very aesthetic, absurdres , megami magazine, bokeh, intricate details, hyperdetailed, (official art, extreme detailed,) ( highest detailed), HDR , game cg , megami magazine , BREAK <lora:Difference_EdgeEmphasisForEbaraPonylr1e04:0.3>, <lora:Difference_BodyShadowForEbaraPony:0.3> , teen , 14yo , realistic , large breasts,
<lora:gakuen_idolmaster_pony_v2:0.7> , in hotel ,  HIMESAKI_RINAMI , short sleeves, brown hair , (nude , naked , completely nude:1.3),  blue and purple eyes , multicolored eyes, , teen , long hair , 16yo , large breasts,   spread legs,  close-up pussy , multiple views,  heavy breathing, female orgasm,  nose blush,  open mouth, 1boy,  penis in pussy , looking at viewer,  , frown , embarrassed ,  ,  looking at viewer,  from above , lying , on bed ,  deep insertion , (x-ray:1.2) , (motion lines,  motion blur:1.4),  close eyes ,  orgasm,  pussy juice,  (trembling:1.5),   penis tightening ,

### りなみちゃｎ

1. おもちゃ？ですか…? 使ったことないです
2. えっ　あっ!!! 
こんなの……　すぐイッちゃう……っ
こんな……物みたいに扱われるなんて……
3. はぁ　はぁ (よだれ垂らす)
えっ?
4. じゅぽじゅぽ（イラマチオ）
5. じゅぽじゅぽ多視点　２P

6. おまんこ開き
えっ!? そんなセリフ…
笑顔で……言わなきゃ駄目ですか……
恋人…関係……ですか
6. おまんこ開き
JKの処女お、おま…んこに、おちん…ちん…を入れて
好きなときにしゃ、射精…してください。
6. おまんこ開き
もう、我慢できないです。処女おまんこがヒクヒクして、
おち…んちんを受け入れる準備が整っています。
ずっと大事にしていた処女おまんこをあなたに捧げ…ます……
7. ペニス当てる
早く……早く……!
8. 半分挿入（苦しそう)
あの、全部入りましたか……



## 
やぁ、リーリエ。君は「処女」だそうだが、このSNSには彼氏が写っているな。君が「処女」かどうか試そう。
今からその男たちとSEXをして処女膜が破られるか試そう
ところで、君の体に引火性物質が塗ってある。ロウソクには十分気を付けろよ。君の放火で死んだ人々に復讐されるかもしれん。


## ワークショップ

-初回
おはようございます、花海咲季です
おはようございます、花海佑芽です

- スリーサイズの紹介 スリーサイズは･･･

- おっぱいのサイズも紹介
えっ　胸のサイズもですか？
Cです。
Fです。

- はい、お願いします。


${alya=!{<lora:alya_anime_v2-soralz:0.7> ,ALYA, LONG HAIR, SILVER HAIR, AHOGE, CROSSED BANGS, red HAIR RIBBON, SIDELOCKS, BLUE EYES}}
${yuki=!{<lora:yuki_anime-soralz:0.7>,YUKI, BLACK HAIR, LONG HAIR, HALF UPDO, HAIR BETWEEN EYES, PURPLE EYES }}
${wear =!{nude , naked , completely nude | SCHOOL UNIFORM, GREY JACKET, OPEN JACKET, LONG SLEEVES, RED BOW, WHITE SHIRT, COLLARED SHIRT, BLACK VEST, BUTTONS, BLACK DRESS, WHITE THIGHHIGHS } } , 
1girls , ${yuki} , ${wear}, , medium breasts, 
on ground , tentacles , (many many tentacles , tentacle nest:1.1) , tentacle pit , in cave , { sitting , spread legs , { 2::arms up , arms wrap tentacles ,  restrained | sweat } , legs wrap tentacles | knees together feet apart, sitting, | doggystyle, all fours, from behind , ass , legs wrap tentacles | standing , (spread legs:1.3), (focus crotch:1.1) , (directly below:1.3) , (from below:1.2) , { 2::arms up ,  arms wrap tentacles , restrained | sweat } , legs wrap tentacles } , { 3-5$$tearing up | frown | surprised, panicking | streaming tears | cry | sad | scared | horror \(theme\) } , { 4::open mouth | teeth mouth } , { (looking away:1.5) | looking at viewer } , sweat, (mucus:1.2) , { 1-2$$(sweat:0.8) |  heavy breathing | open clothes,  nipples | multiple views } ,  { ( { light pink | light blue |  white }  panties:1.1)  , lace panties  , lace trim panties  ,  (close-up panties:1.3) | pussy  , vaginal  } ,   { (sweat:0.8) |  0.5::pee } BREAK ,  


${alya=!{<lora:alya_anime_v2-soralz:0.8> ,ALYA, LONG HAIR, SILVER HAIR, AHOGE, CROSSED BANGS, red HAIR RIBBON, SIDELOCKS, BLUE EYES}}
${yuki=!{<lora:yuki_anime-soralz:0.7>,YUKI, BLACK HAIR, LONG HAIR, HALF UPDO, HAIR BETWEEN EYES, PURPLE EYES }}
${wear =!{1.5::nude , naked , completely nude | SCHOOL UNIFORM, GREY JACKET, OPEN JACKET, LONG SLEEVES, RED BOW, WHITE SHIRT, COLLARED SHIRT, BLACK VEST, BUTTONS, BLACK DRESS, WHITE THIGHHIGHS } } , 
1girls , ${alya} , ${wear}, , medium breasts, 


score_9, , best quality, masterpiece, very aesthetic, absurdres , megami magazine, bokeh, intricate details, hyperdetailed, (official art, extreme detailed,) ( highest detailed), eyeliner, (long eyelashes:1.1), (multicolored eyes, shiny eyes:1.2) , iris space , shiny hair , detail hair , HDR BREAK , ( game cg, realistic:1.1), <lora:Difference_EdgeEmphasisForEbaraPonylr1e04:0.5> , (realistic:1.3),  15yo , 
${alya=!{<lora:alya_anime_v2-soralz:1:1:lbw=1,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0>> ,ALYA, LONG HAIR, SILVER HAIR, AHOGE, CROSSED BANGS, red HAIR RIBBON, SIDELOCKS, BLUE EYES}}
${yuki=!{<lora:yuki_anime-soralz:0.7>,YUKI, BLACK HAIR, LONG HAIR, HALF UPDO, HAIR BETWEEN EYES, PURPLE EYES }}
${wear =!{1.5::nude , naked , completely nude | SCHOOL UNIFORM, GREY JACKET, OPEN JACKET, LONG SLEEVES, RED BOW, WHITE SHIRT, COLLARED SHIRT, BLACK VEST, BUTTONS, BLACK DRESS, WHITE THIGHHIGHS } } , 
(1girl, solo:1.2) , ${alya} , ${wear}, , medium breasts,
{ 8-15$$  panicking | embarrassed | tearing up |  (sweat:0.8) | crying | tearing up | streaming tears | open eyes  | crying | sobbing |  scared |  shouting | panicking | half-closed eyes } ,  (surprised:1.2)     ,(motion blur:1.2),  heavy breathing,  
(tentalce irrumatio) , tentacle in mouth , (looking at another,  looking away:1.4), (bukkake,  cum on body,  facial,  cum on breasts:1.1),  { sweat |  (close-up face:1.2) }  , <lora:tentacles_Pony_V1.0:0.8> SHOKUSYU, TENTACLES,TENTACLES PIT  , { sweat |  cum in mouth , bukkake , facial }   {   (arms up  restrained:1.2) , { lying , on ground |  sitting , on ground  } , spread legs , lace panties |  all fours , doggystyle,  {  from side | __nsp/my/angle__  } }


score_9, , best quality, masterpiece, very aesthetic, absurdres , megami magazine, bokeh, intricate details, hyperdetailed, (official art, extreme detailed,) ( highest detailed), eyeliner, (long eyelashes:1.1), (multicolored eyes, shiny eyes:1.2) , iris space , shiny hair , detail hair , HDR BREAK , ( game cg, realistic:1.1), <lora:Difference_EdgeEmphasisForEbaraPonylr1e04:0.5> ,  15yo , loli , teen  , volumetric light, best shadows
${alya=!{<lora:alya_anime_v2-soralz:0.8> ,ALYA, LONG HAIR, SILVER HAIR, platinum hair ,  AHOGE, CROSSED BANGS, red strings HAIR RIBBON, SIDELOCKS, BLUE EYES }}
${yuki=!{<lora:yuki_anime-soralz:1:lbw=ALL:stop=24>,YUKI, BLACK HAIR, LONG HAIR, HALF UPDO, HAIR BETWEEN EYES, PURPLE EYES }}
${wear =!{  GREY JACKET, OPEN JACKET, LONG SLEEVES, RED BOW, WHITE SHIRT, COLLARED SHIRT, BLACK VEST, BUTTONS, BLACK DRESS, white thighhighs, black loafers} } , 
1girls , ${alya} , ${wear}, , medium breasts, 
in classroom,  standing , smile , closed eyes,  open mouth, 


score_9, , best quality, masterpiece, very aesthetic, absurdres , megami magazine, bokeh, intricate details, hyperdetailed, (official art, extreme detailed,) ( highest detailed), eyeliner, (long eyelashes:1.1), (multicolored eyes, shiny eyes:1.2) , iris space , shiny hair , detail hair , HDR BREAK , ( game cg, realistic:1.1), <lora:Difference_EdgeEmphasisForEbaraPonylr1e04:0.5> ,  15yo , loli , teen  , volumetric light, best shadows
${alya=!{<lora:alya_anime_v2-soralz:0.8> ,ALYA, LONG HAIR, SILVER HAIR, platinum hair ,  AHOGE, CROSSED BANGS, red strings HAIR RIBBON, SIDELOCKS, BLUE EYES }}
${yuki=!{<lora:yuki_anime-soralz:1:lbw=ALL:stop=24>,YUKI, BLACK HAIR, LONG HAIR, HALF UPDO, HAIR BETWEEN EYES, PURPLE EYES }}
${wear =!{ 3::nude , naked , completely nude | GREY JACKET, OPEN JACKET, LONG SLEEVES, RED BOW, WHITE SHIRT, COLLARED SHIRT, BLACK VEST, BUTTONS, BLACK DRESS, white thighhighs, black loafers} } , 
1girls , ${alya} , ${wear}, , medium breasts, 
on ground , tentacles , (many many tentacles , tentacle nest:1.1) , in cave , 
(empty eyes,  expressionless:1.3),  sweat, open mouth,  drooling,  motion lines,  (Pregnancy:1.3) ,  drooling,  <lora:HDA_TentacleSexXL_v1.2:1.2> from below  , sitting  spread legs, missionary,  pussy ,   arms up , low angle ,  open arms  , restrained arms  , arms wrap tentacles , legs wrap tentacles  ,open mouth,  drooling, breasts wrap tentacles , torso wrap tentacles  , (sweat:1.4),  large tentacles , large insertion , deep insertion ,   <lora:tentacle_pit:1>tentaclepitlora, (Pregnancy , pregnant:1.1)




## 

仕方ない、
学年中の女子から虐められている僕が仕返しするには
異能"触手凌辱"（トラブル)を使わざるを得ない