black hair,  long hair,  nude , naked, completely nude, 14yo, teen, small breasts ,   missionary,  sex , penis in pussy , indoors,  on bed,  missionary , lying , on bed , ,  pov , spread legs,   motion lines,  orgasm,  female orgasm,  looking at viewer,  open mouth,  (trembling:1.2),  heart-shaped pupils,  drooling,  saliva , 
 <lora:Difference_BodyShadowForEbaraPony:0.55>,  <lora:Difference_EdgeEmphasisForEbaraPonylr1e04:0.75> , 




 score_9, score_8_up, score_7_up,  best quality, masterpiece, very aesthetic, absurdres , (ultrahigh resolution textures), bokeh, intricate details, hyperdetailed, (official art, extreme detailed,) ( highest detailed), HDR+ BREAK 
black hair,  long hair, school uniform, black jacket , shirt , blue bow , blue eyes , light smile ,  black pleated skirt, small breasts,  long skirt , from above ,  in street ,  school bag,   close contact ,  close-up face , leaning forward,  open mouth,  
 <lora:Difference_BodyShadowForEbaraPony:0.55>,  <lora:Difference_EdgeEmphasisForEbaraPonylr1e04:0.75> 