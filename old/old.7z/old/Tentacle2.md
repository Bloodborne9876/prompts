
## ヘッダー
<!-- (tentacle pit:1.1) , tentacles , tentacle nest ,tentacles , tentacle pit , tentacles , <lora:tentacles_v0.4:0.75>  ,  { looking at viewer |  (looking at another,  looking away:1.5) } , BREAK open clothes,  { (__nsp/my/new_bra__ , __nsp/my/bra__:1.2) | 2::(nipples  , nsfw:1.2) } ,{ 0.8::frown , nose blush,  embarrassed,  sweat, tearing up,   |  cry , sad , clenched teeth,  sweat, tearing up,  streaming tears  | nose blush,  embarrassed,  (heavy breathing:1.2) , spoken heart,  heart-shaped pupils,  cum in pussy , cum , pussy juice | 3::cry , sad , tearing up,  streaming tears,  (shouting:1.2), surprised, open mouth  | 3::(expressionless:1.3), (empty eyes:1.5), (cum in pussy,  cum on body,  facial,  cum on breasts , bukkake,  :1.3), tearing up,  streaming tears,  open eyes , open mouth }, { 4::open mouth | closed mouth } , { open eyes | close eyes | one eye closed }  ,  BREAK
[X] -->

## タイトル
( trembling:1.4),  embarrassed,  surprised,  (trembling:1.5) ,{ 1.5::sweat | 0.5::(orgasm,  female orgasm:1.5)}  ,  { clenched teeth   }  ,    { 2-5$$cry | sad |  tearing up |  sobbing  | streaming tears |  (rape:1.3),   (gangbang:1.2) }  , { <lora:kneestogetherfeetapart:0.65:lbw=MIDD> , knees together feet apart, sitting  |   sitting , spread legs | spread legs } ,  tentacles,  arms wrap tentacles  , looking at viewer,  panties , pantyshot  , water surface, in tentacle pits ,  arms behind head , arms restrained tentacles , arms wrap tentacles legs wrap tentacles , mucus, 

## 破れ
in cave , arms up,  torn clothes,  (lifted clothes,  nipples:1.2),  restrained,  upper body,  clenched teeth,  embarrassed,  frown , crying,  tearing up,  arms wrap tentacles ,  arms tentacles restrained, open mouth, cum on body , cum on breasts,  facial,  <lora:bukkake_v0.4:0.75> 

### タイトル2
(tentacle pit:1.4) , tentacles , tentacle nest ,tentacle pit BREAK { 1.2::(sweat:0.8) ,  <lora:tentacles_v0.4:0.35> |  <lora:tentacles_v0.4:0.75> }   BREAK
 { {8-15$$(embarrassed, nose blush:1.3) |<lora:scared-expression-v1.8-000005:0.55:lbw=MIDD> | (trembling:0.8)| streaming tears | frown | angry | disgust | tearing up |  (sweat:0.8) | open eyes  | angry |  cry |  sad | sobbing |  shouting | panicking | half-closed eyes |  scared  }  }  ,  { 2::(sweat:0.8) |  0.3::cumin pussy , cum on body , cum explosion  }  (trembling:1.1), { 4::open mouth,  wavy mouth |   clenched teeth | (one eye closed:1.4)  , wavy mouth   | shouting , sweat,   | close mouth }   BREAK
[X] , { 1.2::(sweat:0.8) } BREAK
(from behind:1.3) , standing , (wall:1.1) , (touch the wall  , wall on hands:1.2) ,  standing,  ass focus ,  pussy , rear pussy,  (ass focus:1.2) , { doggystyle,  all fours | 2::leaning forward , (ass focus:1.3) }  , open mouth , (despair face :1.1),  pussy , vaginal , (peeing:1.2), ( tentacles in pussy ,:1.2)  , (looking at viewer:1.3),  open mouth,  open eyes 

### タイトル3
(tentacle pit:1.4) , tentacles , tentacle nest ,tentacle pit BREAK { 1.2::(sweat:0.8) ,  <lora:tentacles_v0.4:0.35> |  <lora:tentacles_v0.4:0.75> }   BREAK
 { {8-15$$tearing up |  (sweat:0.8) | open eyes  |  cry |  sad | sobbing   }  }  , { 4::open mouth }   BREAK

## 導入
(tentacle pit:1.4) , tentacles , tentacle nest ,tentacle pit BREAK { 1.2::(sweat:0.8) ,  <lora:tentacles_v0.4:0.35> |  <lora:tentacles_v0.4:0.75> }   BREAK
in cave , water surface , { 1::sitting , wariza , { mucus ,covering breasts,  covering crotch }    | <lora:kneestogetherfeetapart:0.65:lbw=MIDD> ,  knees together feet apart, sitting,  { arms up | 2::sweat } , ( white panties:1.3)  |  doggystyle,  all fours,  from behind , white panties  | standing ,  (spread legs:1.3), (focus crotch:1.1)  , (directly below:1.3) , (from below:1.2)  (colored panties:1.3) }  , {   3-5$$tearing up | frown | disgust | panicking |  streaming tears | cry | sad |   scared | horror \(theme\)  } , {  4::open mouth | teeth mouth } , { (looking away:1.5) | looking at viewer } ,  sweat,  (mucus:1.2) , { 1.2::(sweat:0.8) |  (multiple views:1.3) } BREAK

### パンチラ
(tentacle pit:1.4) , tentacles , tentacle nest ,tentacle pit BREAK { 1.2::(sweat:0.8) ,  <lora:tentacles_v0.4:0.35> |  <lora:tentacles_v0.4:0.75> }   BREAK
{ { sitting | standing }  from below , pantyshot  , colored panties ,  grab tentacles , (looking away:1.2),  } , {  4::open mouth | closed mouth | wavy mouth } , { 1.5::disgust , angry ,  { clenched teeth | open mouth }  | surprised }  , (multiple views:1.3), 

## 通常エロ
(tentacle pit:1.4) , tentacles , tentacle nest ,tentacle pit BREAK { 1.2::(sweat:0.8) ,  <lora:tentacles_v0.4:0.35> |  <lora:tentacles_v0.4:0.75> }   BREAK
 { {8-15$$(embarrassed, nose blush:1.3) |(trembling:1.3) | (motion lines , motion blur:1.3) | streaming tears | frown | disgust | tearing up |  (sweat:0.8) | open eyes  | crying | sobbing |  shouting | panicking | half-closed eyes |  scared  }  }  ,  { 2::(sweat:0.8) |  0.3::cumin pussy , cum on body , cum explosion  }  (trembling:1.1), { 4::open mouth,  wavy mouth |   clenched teeth | (one eye closed:1.4)  , wavy mouth   | shouting , sweat,   | close mouth }   BREAK
[X] , { 1.2::(sweat:0.8) |  (multiple views:1.3) } BREAK

##  不安
<!-- (tentacle pit:1.4) , tentacles , tentacle nest ,tentacle pit BREAK <lora:tentacles_v0.4:0.75>  BREAK
{ sitting , wariza | sitting | standing, upper body }   (looking away:1.5),  surprised,  { 2-5$$ scared |  <lora:scared-expression-v1.8:0.85:lbw=MIDD>  |  tearing up | streaming tears | (sweat:1.2)  |  open mouth | closed mouth   } BREAK hold up, { full body | upper body }  , (panties ,  nipples :1.2)  , ( torn legwear,  torn clothes:1.3),  -->

## 開脚レイプ訴え
<!-- (tentacle pit:1.4) , tentacles , tentacle nest ,tentacle pit BREAK { 1.2::(sweat:0.8) ,  <lora:tentacles_v0.4:0.35> |  <lora:tentacles_v0.4:0.75> }   BREAK
( trembling:1.4),  embarrassed,  surprised,  (trembling:1.5) ,  open mouth,   { 1.5::sweat | 0.5::(orgasm,  female orgasm:1.5)}  ,  { clenched teeth | open mouth , surprised |  wavy mouth |  0.7::saliva trail,  (drooling:1.2) , , shouting  }  ,    { 2-5$$cry | sad |  tearing up |  sobbing  | streaming tears |  (rape:1.3),   (gangbang:1.2) }  , { <lora:kneestogetherfeetapart:0.65:lbw=MIDD> , knees together feet apart, sitting  |  2::all fours,  doggystyle |   standing , spread legs |  3::{ front | from behind }  , (prone bone:1.3),  (lying on her stomach:1.3) , tearing up, top-down bottom-up , pussy focus , (tentacles in pussy:1.2)  | sitting , spread legs | sitting , wariza | spread legs } ,  tentacles,  arms wrap tentacles  ,  ( legs wrap tentacles:1.2) ,  {  1-4$$bukkake | cum on body |  cum on breasts,  facial | (multiple views , face , uterus:1.4)  | looking at viewer | (looking away:1.5) }  -->

(tentacle pit:1.4) , tentacles , tentacle nest ,tentacle pit BREAK { 1.2::(sweat:0.8) ,  <lora:tentacles_v0.4:0.35> |  <lora:tentacles_v0.4:0.75> }   BREAK
 { {8-15$$(embarrassed, nose blush:1.3) | crying |  (trembling:0.8)| streaming tears | frown tearing up |  (sweat:0.8) | open eyes | cry , sad | sobbing | shouting | panicking | half-closed eyes |  scared  }  }  ,  { 2::(sweat:0.8) |  0.3::cumin pussy , cum on body , cum explosion  }  (trembling:1.1), { 4::open mouth,  wavy mouth |   clenched teeth | (one eye closed:1.4)  , wavy mouth   | shouting , sweat }   BREAK
{ <lora:MissionaryVaginal-v2:0.75:lbw=MIDD> missionary vaginal, spread legs, { sweat | legs up} ,  deep, huge tentacles  , Amateur  | <lora:PSCowgirl:0.75:lbw=MIDD> ,  squatting cowgirl position, vaginal, pov, pussy in vaginal , cum in pussy,  cum in pussy,  tentacles in vaginal  , (motion lines,  motion blur,  trembling,:1.3)  | }

## 完堕ち
(tentacle pit:1.4) , tentacles , tentacle nest ,tentacle pit BREAK { 1.2::(sweat:0.8) ,  <lora:tentacles_v0.4:0.35> |  <lora:tentacles_v0.4:0.75> }   BREAK
 { 5-6$$(embarrassed:0.8) |  | (trembling:1.4)| (tears:0.7) |(drooling:0.8) | (sweat:0.8) | open eyes | fucked silly  }  ,  { 1.5::sweat | 0.5::cum in pussy , cum on body , cum explosion , ecstasy ,  orgasm , female orgasm  }   , (trembling:1.1), {1-2$$ open mouth | wavy mouth } , ,{ 1-3$$:light smile |  embarrassed   | ahegao }  , (heavy breathing:1.2) , sweat , spoken heart , (heart-shaped pupils:1.2),  drooling ,  pink eyes, (trembling:1.2) , motion lines,  pussy , vaginal , tentacles , in pussy BREAK
 [X] , { 1.2::(sweat:0.8) |  (multiple views:1.3) } BREAK

<!-- パンツあり
## パンチラ
 {10$$(embarrassed, nose blush:1.3) |   (tears:0.7) | (sweat:0.7) | open eyes | cry |  sad | sobbing |  tearing up |  streaming tears  | shouting | panicking | (sweat:0.8) |  frown } ,  { 4::open mouth,  wavy mouth |  2::shouting,  open mouth,   | clenched teeth , angry  }   BREAK
(tentacle pit:1.4) , tentacles , tentacle nest ,tentacle pit BREAK <lora:tentacles_v0.4:0.75>    BREAK  { (lace panties , lingrie ,  sexy and adult underwear with extremely detailed details:1.3) | pussy , vaginal , cum in pussy } ,  (looking away:1.5)  BREAK

lying , on water surface , covering breasts,  covering crotch,  <lora:covering_breasts_v0.1:1>  , torn clothes, __nsp/my/angle__ , (looking away:1.5), 
<lora:covering_breasts_v0.1:1> ,  covering crotch , covering breasts  , { standing , upper body , bottomless  | sitting , wariza  }, { front | from above } 
lying , on back , arms up , arms wrap tentacles , legs wrap tentacles , body wrap tentacles,  (looking away:1.5), 
(knees together feet apart:1.2), sitting, __nsp/my/panties__
__nsp/my/panties__ , dynamic pose,  panty shot , { standing | sitting | sitting , wariza }  , arms wrap tentacles , { 2::open clothes , bra | sweat,  }
{ standing | lying | sitting  }  , (spread legs:1.3),   __nsp/my/panties__ , (focus crotch:1.1)  , (directly below:1.3) , (from below:1.2) ,  bottomless , looking at viewer ,  embarrassed,  upper body,  (headless , body only:1.2) 
panties , { front | 4::from behind |  from above } , all fours,  doggystyle,  ass focus ,  surprised,  spoken exclamation mark, (lace panties:1.2) ,  (sexy and adult underwear with extremely detailed details:1.3), 
sitting , { on water surface | on ground }  , spread legs,  ass ,  spread arms , (arms wrap tentacles:1.2) , 
(from behind:1.4) ,  all fours,  doggystyle,  ass focus ,  pussy juice,  penis in pussy ,  head down , legs wrap tentacles , arms wrap tentacles  , (looking away:1.5),  pussy , vaginal , cum in pussy
(from behind:1.4) ,  all fours,  doggystyle,  ass focus ,  pussy juice,  penis in pussy ,  head down , legs wrap tentacles , arms wrap tentacles  , (looking away:1.5),  pussy , vaginal , cum in pussy
(front :1.4) ,  all fours,  doggystyle,   head down , legs wrap tentacles , arms wrap tentacles  , (looking away:1.5),  pussy in tentacles ,multiple views,  pussy
(front :1.4) ,  all fours,  doggystyle,   head down , legs wrap tentacles , arms wrap tentacles  , (looking away:1.5),  pussy in tentacles ,ultiple views,  pussy 
 -->

<!-- 
## パンチラ
 {10$$(embarrassed, nose blush:1.3) |   (tears:0.7) | (sweat:0.7) | open eyes | cry |  sad | sobbing |  tearing up |  streaming tears  | shouting | panicking | (sweat:0.8) |  frown } ,  { 4::open mouth,  wavy mouth |  2::shouting,  open mouth,   | clenched teeth , angry  }   BREAK
(tentacle pit:1.4) , tentacles , tentacle nest ,tentacle pit BREAK <lora:tentacles_v0.4:0.75>    BREAK  pussy , vaginal , cum in pussy,  (looking away:1.5)  BREAK -->

lying , on water surface , covering breasts,  covering crotch,  <lora:covering_breasts_v0.1:1>  , torn clothes, __nsp/my/angle__ , (looking away:1.5), 
<lora:covering_breasts_v0.1:1> ,  covering crotch , covering breasts  , { standing , upper body , bottomless  | sitting , wariza  }, { front | from above } 
lying , on back , arms up , arms wrap tentacles , legs wrap tentacles , body wrap tentacles,  (looking away:1.5), 
 , dynamic pose,  panty shot , { standing | sitting | sitting , wariza }  , arms wrap tentacles , { 2::open clothes , bra | sweat,  }
{ standing | lying | sitting  }  , (spread legs:1.3), (focus crotch:1.1)  , (directly below:1.3) , (from below:1.2) ,  bottomless , looking at viewer ,  embarrassed,  upper body,  (headless , body only:1.2) 
 { front | 4::from behind |  from above } , all fours,  doggystyle,  ass focus ,  surprised,  spoken exclamation mark, 
sitting , { on water surface | on ground }  , spread legs,  ass ,  spread arms , (arms wrap tentacles:1.2) , 
(from behind:1.4) ,  all fours,  doggystyle,  ass focus ,  pussy juice,  penis in pussy ,  head down , legs wrap tentacles , arms wrap tentacles  , (looking away:1.5),  pussy , vaginal , cum in pussy
(from behind:1.4) ,  all fours,  doggystyle,  ass focus ,  pussy juice,  penis in pussy ,  head down , legs wrap tentacles , arms wrap tentacles  , (looking away:1.5),  pussy , vaginal , cum in pussy
(front :1.4) ,  all fours,  doggystyle,   head down , legs wrap tentacles , arms wrap tentacles  , (looking away:1.5),  pussy in tentacles ,multiple views,  pussy, face 
spread legs , spread arms ,  legs wrap tentacles , arms wrap tentacles  , (looking away:1.5),  pussy in tentacles ,multiple views,  pussy , face 


## レイプ目
 { 1.2::(sweat:0.8) |  (multiple views:1.3) } BREAK { spread legs,  straddling,  cowgirl position,   missionary,  pussy , vaginal |  2::doggystyle,  all fours }  ,  half open mouth,  (expressionless:1.3),  (tearing up,  streaming tears:1.2),  { <lora:bukkake_v0.4:1:lbw=MIDD>   , bukkake, cum on body,  cum on breasts,  facial,  | 1.5::(pussy in tentacles:1.1) } , __nsp/my/angle__ ,    (looking away , motion lines motion blur :1.4),

 ## レイプ目オマン湖開 
empty eyes,  <lora:EmptyEyes_Diffuser_v10:1.1>    (trembling:1.5)   , BREAK ( open mouth,  heavy breathing,  tearing up,  streaming tears:1.2), 
lying  , spread legs , pussy  <lora:Saya-spread pussy(fingers)2:0.95> , spread pussy ,  
 

 ## 挿入
 tentacles, tentacle sex, tentacle pit, restrained, tentacles in pussy , vaginal ,  (spread legs:1.1),{ 1.2::(sweat:0.8) |  (multiple views:1.3) }
 all fours,  doggystyle,   tentacles, tentacle sex, tentacle pit, restrained, tentacles in pussy , vaginal ,  (open mouth:1.3),  streaming tears , from behind  , <lora:motion_blur_v0.3:1> , (motion lines,  motion blur:1.3), , { 1.2::(sweat:0.8) |  (multiple views:1.3) } 

## 汎用
  { spread legs, sitting | all fours,  doggystyle }  ,   open clothes,  nipples,  tentacles in pussy , (trembling:1.5),  (orgasm:1.5),  (multiple views:1.3),  ass 

## 連続

<lora:MissionaryVaginal-v2:0.75:lbw=MIDD> missionary vaginal, spread legs, { sweat | legs up} ,  deep, huge tentacles  , Amateur
breasts wrap tentacles , nipples on tentacles, upper body, 
sitting , spread legs , from below,  ceiling  ,    <lora:multiple_insertions_v0.2:0.75:lbw=MIDD> , multiple insertion , (tentacles in pussy , tentacles in vaginal:1.2) , missionary, 
(from behind:1.3) , standing , (wall:1.1) , (touch the wall  , wall on hands:1.2) ,  standing,  ass focus ,  pussy , rear pussy,  (looking away,:1.3)  ,  (ass focus:1.2) , { doggystyle,  all fours | 2::leaning forward , (ass focus:1.3) }  , open mouth , (despair face :1.1),  pussy , vaginal , (peeing:1.2), ( tentacles in pussy ,:1.2) 
(from behind:1.3) , standing , (wall:1.1) , (touch the wall  , wall on hands:1.2) ,  standing,  ass focus ,  pussy , rear pussy,  (looking away,:1.3)  ,  (ass focus:1.2) , { doggystyle,  all fours | 2::leaning forward , (ass focus:1.3) }  , open mouth , (despair face :1.1),  pussy , vaginal , (peeing:1.2), ( tentacles in pussy ,:1.2) 
<lora:ASSAS:0.3:lbw=MIDD> ,  pussy juice,   all fours,  doggystyle, from behind , pussy vaginal
<lora:ASSAS:0.3:lbw=MIDD> ,  pussy juice,   all fours,  doggystyle, from behind , pussy vaginal
standing  , (spread legs:1.3),  (focus crotch:1.1)  , (directly below:1.3) , (from below:1.2) ,  bottomless , looking at viewer ,  embarrassed, ,  pussy , vaginal , tentacles , in pussy  
standing  , (spread legs:1.3),  (focus crotch:1.1)  , (directly below:1.3) , (from below:1.2) ,  bottomless , looking at viewer ,  embarrassed, 
 standing  , (spread legs:1.3),  (focus crotch:1.1)  , (directly below:1.3) , (from below:1.2) ,  bottomless , looking at viewer ,  embarrassed, multiple views , pussy , face   
missionary, vaginal, tentacles in vaginal , spread legs , <lora:motion_blur_v0.3:1> , motion blur,  arms wrap tentacles , legs wrap tentacles ,   multiple views , pussy , face ,   __nsp/my/angle__
missionary, vaginal, tentacles in vaginal , spread legs , <lora:motion_blur_v0.3:1> , motion blur,  arms wrap tentacles , legs wrap tentacles ,   multiple views , pussy , face ,   __nsp/my/angle__
<lora:kneestogetherfeetapart:0.65:lbw=MIDD> , knees together feet apart, sitting, arms up , restrained tentacles,  arms wrap tentacles  ,  ( legs wrap tentacles:1.2)
<lora:kneestogetherfeetapart:0.65:lbw=MIDD> , knees together feet apart, sitting, arms up , restrained tentacles,  arms wrap tentacles  ,  ( legs wrap tentacles:1.2)
<lora:kneestogetherfeetapart:0.65:lbw=MIDD> , knees together feet apart, sitting, arms up , restrained tentacles,  arms wrap tentacles  ,  ( legs wrap tentacles:1.2) , multiple views , pussy , face 
missionary, vaginal, tentacles in vaginal , spread legs , <lora:motion_blur_v0.3:1> , motion blur,  arms up,  arms wrap tentacles , legs wrap tentacles ,  air hung  , spread arms , 
{ lying, , on back ,  missionary |  straddling , cowgirl position, from below,  ceiling } , missionary, vaginal, tentacles in vaginal , spread legs , <lora:motion_blur_v0.3:1> , motion blur,  multiple views , pussy   ,   arms wrap tentacles ,  legs wrap tentacles , (tentacles extending from the ground in pussy:1.3)
{ lying, , on back ,  missionary |  straddling , cowgirl position, from below,  ceiling } , missionary, vaginal, tentacles in vaginal , spread legs , <lora:motion_blur_v0.3:1> , motion blur,  multiple views , pussy   ,   arms wrap tentacles ,  legs wrap tentacles , (tentacles extending from the ground in pussy:1.3)
{ lying, missionary ,  {arms up | hands on own chest  |  breasts squeezed together }   |  straddling , cowgirl position, from below,  ceiling  ,  { sweat | hands on own chest  |  breasts squeezed together } } missionary, vaginal, tentacles in vaginal , spread legs , <lora:motion_blur_v0.3:1> , motion blur, 
sitting , spread legs,   , tentacles in pussy , tentacles grow in ground , <lora:large_insertion_v0.1:0.85> large insertion  , tentacles in pussy ,restrained,  mouth in tentacles
sitting , spread legs,   , tentacles in pussy , tentacles grow in ground , <lora:large_insertion_v0.1:0.85> large insertion  , tentacles in pussy ,restrained,  mouth in tentacles
sitting , spread legs,   , tentacles in pussy , tentacles grow in ground , <lora:large_insertion_v0.1:0.85> large insertion  , tentacles in pussy ,restrained,  mouth in tentacles
{ lying, missionary ,  {arms up | hands on own chest  |  breasts squeezed together }   |  straddling , cowgirl position, from below,  ceiling  ,  { sweat | hands on own chest  |  breasts squeezed together } } missionary, vaginal, tentacles in vaginal , spread legs , <lora:motion_blur_v0.3:1> , motion blur,  (multiple views:1.3)
{ lying, missionary ,  {arms up | hands on own chest  |  breasts squeezed together }   |  straddling , cowgirl position, from below,  ceiling  ,  { sweat | hands on own chest  |  breasts squeezed together } } missionary, vaginal, tentacles in vaginal , spread legs , <lora:motion_blur_v0.3:1> , motion blur,  (multiple views:1.3)
{ straddling , cowgirl position, from below,  ceiling  ,  { sweat | hands on own chest  |  breasts squeezed together } } missionary, vaginal, ( tentacles in vaginal:1.3) , from below , arms up , restrained,  spread legs,  <lora:motion_blur_v0.3:1> , motion blur
{ lying, missionary ,  {arms up | hands on own chest  |  breasts squeezed together }   |  straddling , cowgirl position, from below,  ceiling  ,  { sweat | hands on own chest  |  breasts squeezed together } } missionary, vaginal, tentacles in vaginal , spread legs , <lora:motion_blur_v0.3:1> , motion blur,  (multiple views:1.3)
{ lying, missionary ,  {arms up | hands on own chest  |  breasts squeezed together }   |  straddling , cowgirl position, from below,  ceiling  ,  { sweat | hands on own chest  |  breasts squeezed together } } missionary, vaginal, tentacles in vaginal , spread legs , <lora:motion_blur_v0.3:1> , motion blur,  (multiple views:1.3)
all fours,  doggystyle , { front |  4::(from behind , ass:1.2) } , tentacles in vaginal  ,  (mucus:1.2),   (tentacles wraps around legs:1.1), { water surface | 2::sweat } ,  (tentacles in pussy :1.3) 
all fours,  doggystyle , { front |  4::(from behind , ass:1.2) } , tentacles in vaginal  ,  (mucus:1.2),   (tentacles wraps around legs:1.1), { water surface | 2::sweat },{  <lora:multiple_insertions_v0.2:0.5:lbw=MIDD> , multiple insertion | tentacles in pussy | <lora:large_insertion_v0.1:0.5:lbw=MIDD> large insertion } , {(front:1.2) | from above | from below }
all fours,  doggystyle , { front |  4::(from behind , ass:1.2) } , tentacles in vaginal  ,  (mucus:1.2),   (tentacles wraps around legs:1.1), { water surface | 2::sweat },  (multiple views:1.3)
<lora:PSCowgirl:0.75:lbw=MIDD> ,  squatting cowgirl position, vaginal, pov, pussy in vaginal , cum in pussy,  cum in pussy,  tentacles in vaginal  , (motion lines,  motion blur,  trembling,:1.3) 
<lora:PSCowgirl:0.75:lbw=MIDD> ,  squatting cowgirl position, vaginal, pov, pussy in vaginal , cum in pussy,  cum in pussy,  tentacles in vaginal  , (motion lines,  motion blur,  trembling,:1.3) 
<lora:PSCowgirl:0.75:lbw=MIDD> ,  squatting cowgirl position, vaginal, pov, pussy in vaginal , cum in pussy,  cum in pussy,  tentacles in vaginal  , (motion lines,  motion blur,  trembling,:1.3) 
<lora:POVMissionary:0.35:lbw=MIDD> , {arms up | hands on own chest  |  breasts squeezed together , __nsp/myNSFW/commonArm__ } , { sex |  mlegs } ,  motion lines  ,  cum in pussy ,  (tentacles in pussy :1.3) , pussy , vaginal , (trembling:1.5)
<lora:POVMissionary:0.35:lbw=MIDD> , {arms up | hands on own chest  |  breasts squeezed together , __nsp/myNSFW/commonArm__ } , { sex |  mlegs } ,  motion lines  ,  cum in pussy ,  (tentacles in pussy :1.3) , pussy , vaginal , (trembling:1.5)
<lora:POVMissionary:0.35:lbw=MIDD> , {arms up | hands on own chest  |  breasts squeezed together , __nsp/myNSFW/commonArm__ } , { sex |  mlegs } ,  motion lines  ,  cum in pussy ,  (tentacles in pussy :1.3) , pussy , vaginal , (trembling:1.5)
<lora:EkuneCowgirl:0.75:lbw=MIDD> , cowgirlpose, cowgirl position, ass , pussy, anus  , bottomless  , ass grab , hip grab , __sell/template_missionary__  ,
<lora:POVDoggy:0.65> , (from behind , tentacles in pussy,  doggystyle:1.4) , looking at viewer, ,  (tentacles in pussy :1.3) 
<lora:POVDoggy:0.65> , (from behind , tentacles in pussy,  doggystyle:1.4) , looking at viewer, ,  (tentacles in pussy :1.3) 
<lora:POVDoggy:0.65> , (from behind , tentacles in pussy,  doggystyle:1.4) , looking at viewer, ,  (tentacles in pussy :1.3) 
<lora:fucsil1:0.55:lbw=MIDD> , (front:1.3), (motion lines:1.5), (trembling:1.3) , tentacles in vaginal , many many tentacles , tentacles in pussy , 
<lora:fucsil1:0.55:lbw=MIDD> ,  (from behind:1.3), (motion lines:1.5), (trembling:1.3) , tentacles in vaginal , many many tentacles , tentacles in pussy
<lora:fucsil1:0.55:lbw=MIDD> , from behind, (motion lines:1.5), (trembling:1.3) , tentacles in vaginal , many many tentacles , tentacles in pussy ,
{  (front:1.3) |  (from behind:1.3) }  , (prone bone:1.3),  ahegao,    pussy in tentacle ,  (lying on her stomach:1.3) , tearing up, top-down bottom-up , pussy focus , (tentacles in pussy:1.2)  , from side 
{ front | from behind }  , (prone bone:1.3),  ahegao,    pussy in tentacle ,  (lying on her stomach:1.3) , tearing up, top-down bottom-up , pussy focus , (tentacles in pussy:1.2)  , from side 
{ front | from behind }  , (prone bone:1.3),  ahegao,    pussy in tentacle ,  (lying on her stomach:1.3) , tearing up, top-down bottom-up , pussy focus , (tentacles in pussy:1.2)  , from side 
lying  , stomach,   spread legs , pussy , ass , , looking at viewer, pussy , <lora:Saya-spread pussy(fingers)2:0.8:lbw=MIDD> , spread pussy
lying  , stomach,   spread legs , pussy , ass , , looking at viewer, pussy , <lora:Saya-spread pussy(fingers)2:0.8:lbw=MIDD> , spread pussy , 
lying  , stomach,   spread legs , pussy , ass , , looking at viewer, pussy , <lora:Saya-spread pussy(fingers)2:0.8:lbw=MIDD> , spread pussy , 
 lying  , stomach,   spread legs , pussy , ass , , looking at viewer, pussy ,  spread pussy,  
lying  , stomach,   spread legs , pussy , ass , , looking at viewer, pussy ,, front , __nsp/myNSFW/commonArm__ ,  <lora:dskbSPu:0.4> , dskbSPu , hymen,  uterus,  internal cumshot, { 1.2::(sweat:0.8) } BREAK <lora:EmptyEyes_Diffuser_v10:1.2>  , (looking away , expressionless:1.5),  (open mouth,:1.3) 
lying  , stomach,   spread legs , pussy , ass , , looking at viewer, pussy ,, front , __nsp/myNSFW/commonArm__ ,  <lora:dskbSPu:0.4> , dskbSPu , hymen,  uterus,  internal cumshot, { 1.2::(sweat:0.8) } BREAK <lora:EmptyEyes_Diffuser_v10:1.2>  , (looking away , expressionless:1.5),  (open mouth,:1.3) 
lying  , stomach,   spread legs , pussy , ass , , looking at viewer, pussy ,, front , __nsp/myNSFW/commonArm__ ,  <lora:dskbSPu:0.4> , dskbSPu , hymen,  uterus,  internal cumshot, { 1.2::(sweat:0.8) } BREAK <lora:EmptyEyes_Diffuser_v10:1.2>  , (looking away , expressionless:1.5),  (open mouth,:1.3) 

<lora:aftersex:0.55:lbw=MIDD> , after sex, cum, lying, cumdrip, ass, on stomach, on back, fucked silly, sweat, cum pool, bukkake, trembling , <lora:cervix:0.55:lbw=MIDD> cervix, spread pussy, clitoris, urethra , spread legs,  ass  , (trembling:1.3), 
<lora:aftersex:0.55:lbw=MIDD> , after sex, cum, lying, cumdrip, ass, on stomach, on back, fucked silly, sweat, cum pool, bukkake, trembling
all fours,  doggystyle,  leaning forward, kneeling, front , pov ,  from below ,  upper body,  face focus , indoors,  on bed 

## レイプ後
<lora:EmptyEyes_Diffuser_v10:1.2>  empty eyes,  closed mouth,  tearing up,  streaming tears,  (looking away:1.3), 
<lora:aftersex:0.55:lbw=MIDD> , after sex, cum, lying, cumdrip, ass, on stomach, on back, fucked silly, sweat, cum pool, bukkake, trembling streaming tears,  on bed   , spread legs,  (expressionless:1.3), 

## 正常位 , 騎乗位 * 2 * 4
 (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , { standing  |  lying , ( spread legs:1.3) ,  ass  } , {arms up | hands on own chest  |  breasts squeezed together }   |  straddling , cowgirl position, from below,  ceiling  ,  { sweat | hands on own chest  |  breasts squeezed together } missionary, vaginal, pov ,  1boy, ( spread legs:1.3) , { multiple insertion | large insertion | shiny hair }  ,{  <lora:multiple_insertions_v0.2:0.75:lbw=MIDD> , multiple insertion | tentacles in pussy | <lora:large_insertion_v0.1:0.75:lbw=MIDD> large insertion } , {(front:1.2) | from above | from below }

## 正常位 , 騎乗位 2
 (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , { standing  |  lying , ( spread legs:1.3) ,  ass  } , {arms up | hands on own chest  |  breasts squeezed together }   |  straddling , cowgirl position, from below,  { sweat | hands on own chest  |  breasts squeezed together } missionary, vaginal,   ( spread legs:1.3) ,  {front | from above | from below } ,  (multiple views:1.2),  tentacles in vaginal , 

## その他
 (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , tentacles in pussy , cum in pussy , pussy juice,  dynamic pose,  from above , (looking at another,  looking away:1.5) , spread legs, 

## fera 
 <lora:SideFellatio:0.7:lbw=MIDD> , sidefellatio, tentacles  in mouth , fellatio, from side, cum in mouth , face up  , kneeing,  tearing up,  streaming tears,  tentacles  , tentacles grow from above 

, { sweat | 1.2::(multiple views:1.2) }  

 ## テンプレ 2 * 6
 <!-- (restrained:1.2) , { 1.5::frown , one eye closed  |  1.5::open mouth,   ,  trail ,  { sweat |  1.2::(empty eyes:1.2) } | (sexual ecstasy:1.3), orgasm ,  open eyes , in heat , seductive smile } ,  (heavy breathing:1.2) BREAK sobbing, <lora:tentacles_v0.4:1> , (many many oily tentacles:1.2), (mucus:1.2), (tentacle wraps around arms:1.1) ,  (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , sobbing ,  { all fours,  doggystyle , { from behind | front }  |  spread legs , { front | from from above } | cowgirl position , squatting |  lying , missionary | 2::dynamic pose } BREAK{  { tentacles in vaginal  | 2::<lora:multiple_insertions_v0.2:0.7>  multiple insertions |  tentacles in vaginal ,  <lora:large_insertion_v0.1:0.7> large insertion } , {  pussy juice | 2::pussy  juice , (cum in pussy , after vaginal,  cum explosion:1.2) } , (trembling:1.3) } , __nsp/my/angle__ ,  water surface -->

## 四つん這い * 1 * 3
all fours,  doggystyle , { front |  4::(from behind , ass:1.2) } , tentacles in vaginal  ,  (mucus:1.2),   (tentacles wraps around legs:1.1), { water surface | 2::sweat }, {  <lora:multiple_insertions_v0.2:0.75:lbw=MIDD> , multiple insertion | (tentacles in pussy:1.2) | large insertion } , { looking at viewer |  (looking at another,  looking away:1.5) } ,  { sweat | (multiple views:1.2) } 


## 逃走中
(from behind:1.3) , standing , (wall:1.1) , (touch the wall  , wall on hands:1.2) ,  standing,  ass focus ,  pussy , rear pussy,  (looking away,:1.3)  ,  (ass focus:1.2) , { doggystyle,  all fours | 2::leaning forward , (ass focus:1.3) }  , open mouth , (despair face :1.1),  pussy , vaginal , (peeing:1.2), ( tentacles in pussy ,:1.2) 

## フェラ * 1 * 3
## これだけでやること
(tentacle pit:1.4) , tentacles , tentacle nest ,tentacle pit BREAK { 1.2::(sweat:0.8) ,  <lora:tentacles_v0.4:0.35> |  <lora:tentacles_v0.4:0.75> }   BREAK
(fellatio , tentacle fellatio,  tentacles in mouth :1.2) , tentacles sex , tentacle in mouth , (looking at another,  looking away:1.4), (bukkake,  cum on body,  facial,  cum on breasts:1.1), 
<lora:EkunePOVFellatioV2:0.95:lbw=MIDD> , fellatio,  povfellatio,  cum in mouth, cum drip, (streaming tears, sobbing,  tearing up:1.3),  embarrassed  bukkake,  facial 


## メス堕ち後フェラ
(fellatio , tentacle fellatio,  tentacles in mouth :1.2) , tentacles sex , tentacle in mouth ,  {  2::kneeing | 2::sitting wariza }  , (looking at another,  looking away:1.4), (bukkake,  cum on body,  facial,  cum on breasts:1.1), { sweat |  1.5::arms behind back } , arms wrap tentacles  , legs wrap tentacles, 


<lora:EkunePOVFellatioV2:0.95:lbw=MIDD> , fellatio,  povfellatio,  cum in mouth, cum drip, (Tentacles grow from the wall or ground:1.1)  , doggystyle,  face down , all fours,   bukkake,  facial 
 { 5-6$$(embarrassed:0.8) | open eyes | fucked silly  }  ,  { ecstasy ,  orgasm , female orgasm  }   , (trembling:1.1),{ ahegao }  , (heavy breathing:1.2) , sweat , spoken heart , (heart-shaped pupils , pink eyes :1.2),  drooling ,  pink eyes , smile , <lora:bukkake_v0.4:1> , (spoken heart:1.2), 




## 完落ち * 1 * 3
looking at viewer, smile , laughing ,   { wariza | sitting  | standing }  ,  heart-shaped pupils,  spoken heart,  <lora:tentacles_v0.4:0.8:lbw=MIDD> , tentacles,  { from side |  pov  } ,  (restrained:1.4)  , (many many oily tentacles:1.2), (mucus:1.2)  , bukkake, <lora:bukkake_v0.4:0.7> , __nsp/my/angle__  , (cum on body , cum on face , cum on breasts,  cum in pussy:1.2) , grab tentacles 

## 中出し * 1 * 3
 tentacles in pussy , cum in pussy ,   <lora:kneestogetherfeetapart:0.7:lbw=MIDD> , knees together feet apart, sitting

 
## 救出後
{ empty eyes,  (expressionless:1.2)  |  cry , sad , clenched teeth,  sweat, tearing up,  streaming tears  | 1.5::nose blush,  embarrassed,  (heavy breathing:1.2) , spoken heart,  heart-shaped pupils,  } ,  cum in pussy , cum , pussy juice , { after sex,  cum in vaginal , (spread legs:1.1)  } , { sitting , on couch | lying }  , indoors ,  , open mouth  , face down , looking at down , arms on floor, 

# 横向き

## Pile

## バック
 ass, doggystyle, sex, all fours ,  top-down bottom-up , looking at another , looking to the side, {  <lora:multiple_insertions_v0.2:0.75:lbw=MIDD> , multiple insertion | sweat | <lora:large_insertion_v0.1:0.75:lbw=MIDD> large insertion } , tentacles in pussy 

## 正常位
restrained , tentacles , (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , { standing  |  lying ,  spread legs ,  ass  } , __nsp/my/angle__ ,{arms up | hands on own chest  |  breasts squeezed together }   |  straddling , cowgirl position, from below,  ceiling  ,  { sweat | hands on own chest  |  breasts squeezed together } missionary, vaginal, pov ,  1boy,  spread legs , { multiple insertion | large insertion | shiny hair }  ,{  <lora:multiple_insertions_v0.2:0.75:lbw=MIDD> , multiple insertion | tentacles in pussy | <lora:large_insertion_v0.1:0.75:lbw=MIDD> large insertion }

## 正常位色々
 (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , sobbing, spread legs,  sex , tentacles,  in pussy , { straddling | lying } , __nsp/my/angle__ ,   { looking at viewer |  (looking at another,  looking away:1.5) }  ,  sweat, nose blush,  {  multiple views, { all fours,  doggystyle | prone bone , flat chest   | face  }  | 2::sweat } 

## 横色々
 (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , sobbing,   prone bone,  ass, lying, sex from behind, pillow, prone bone,  lying, (sex from behind:1.3), (sex:1.3),  { looking at viewer |  (looking at another,  looking away:1.5) }  , legs together, (motion blur), (motion line), flat chest, (petite female body),  from side , { open eyes ,  open mouth,  one eye closed,   cum in pussy  ,( trembling:1.4) | frown , clenched teeth , tearing up , one eye closed , (motion lines:1.5),  } , sweat, nose blush, { multiple views, { from behind , pussy in tentacles  | face | front , focus pussy | from above , cowboy shot , wariza }  | 2::sweat } 

## 恐怖
in tentacle pit , tentacles , tentacle nest , open clothes,  { (__nsp/my/new_bra__ , __nsp/my/bra__:1.2) | 1.5::(nipples  , nsfw:1.2) } ,  tentacles , tentacle pit , restrained , tentacles , <lora:tentacles_v0.4:0.95> BREAK
 cry , sad , streaming tears,  sobbing , scared ,{ open eyes | one eye closed |  closed eyes } ,  { open mouth | closed mouth } ,   face down ,   (tentacles in pussy , cum in pussy , cum on body , facial,  cum on breasts,  cum on legs , bukkake:1.3)  , multiple views,  face 

 ## 色々
 (expressionless:1.3),  tearing up,  { open eyes | one eye closed |  closed eyes } ,  { open mouth | closed mouth } ,  looking at another,  looking to the side,  looking away,  ,   (tentacles in pussy , cum in pussy , cum on body , facial,  cum on breasts,  cum on legs , bukkake:1.3)  , multiple views,  face , sitting , standing , wariza 

# リアル万
<!-- { lying | sitting }  ,   heavy breathing,   spread legs , bottomless, , focus vaginal , detail vaginal , heavy breathing, open mouth, nose blush , panicking ,  pussy juice, cum in pussy, cum explosion, (trembling:1.4), (facial, bukkake, cum on body:1.3) , after vaginal, after sex, in classroom , fluorescent light ,  open mouth,   , closed mouth,  , (empty eyes:1.2),  (face down , looking at another:1.2),  in warehouse,  open clothes,  bra  <lora:newb_0.1:0.6> , perfect vaginal ,  focus crotch ,  open clothes,  nipples,  nsfw  , front , focus crotch ,( focus pussy:1.2) , { arms behind back | arms behind head  | hands on nipples }  , (trembling:1.4),  -->

## 終わり

empty eyes,  bukkake,  open mouth , ,  trail,   lying , { cry  | frown }  , tearing up  , streaming tears,    tentacle-pit , tentacle-pit,tentacles,  in tentacles pit , (many many oily tentacles:1.2), (mucus:1.2), { spread legs | bukkake } ,  cum on body,  cum in pussy,  facial,  cum on breasts, after pussy ,  <lora:tentacles_v0.4:0.8:lbw=MIDD> , __nsp/my/angle__ ,  <lora:bukkake_v0.4:0.75:lbw=MIDD>

## 終わり 2 * 2
streaming tears,  tearing up,  open mouth,  after sex,  orgasm,  female orgasm,  <lora:aftersex:0.7:lbw=MIDD> , after sex, cum, lying, cumdrip, ass, on stomach, on back, fucked silly, sweat, cum pool, bukkake, trembling , { pillow hug | sheets grab } 

## 終わり2
 { (__nsp/my/new_bra__ , __nsp/my/bra__:1.2) | 2::(nipples  , nsfw:1.2) } ,{ 1.2::frown , nose blush,  embarrassed,  sweat, tearing up,   |  cry , sad , clenched teeth,  sweat, tearing up,  streaming tears  | 1.5::nose blush,  embarrassed,  (heavy breathing:1.2) , spoken heart,  heart-shaped pupils, },  cum in pussy , cum , pussy juice , { 2::open mouth | closed mouth } , { open eyes | close eyes | one eye closed }  ,   { looking at viewer |  (looking at another,  looking away:1.5) } , BREAK
cry , sad ,  after sex,  orgasm,  female orgasm,  <lora:aftersex:0.7:lbw=MIDD> , after sex, cum, lying, cumdrip, ass, on stomach, on back, fucked silly, sweat, cum pool, bukkake, trembling , { pillow hug | sheets grab }  ,  


## 救出　保護

{ (tentacle pit:1.1) , tentacles , <lora:tentacles_v0.4:0.95> | hospital bed,  in hospital }  , saliva trail,  { sitting | lying ,  , on back  } , (spread legs:1.2) , ass ,  (expressionless:1.3), (empty eyes:1.5), (cum in pussy,  cum on body,  facial,  cum on breasts , bukkake,  :1.3), ( looking at another,  looking away:1.2) ,  tearing up,  streaming tears,  open eyes , (open mouth:1.2) , (trembling:1.5),  crotch focus , ( heavy breathing:1.2), 

## レイプ目
(expressionless:1.3), (empty eyes:1.7), scared,  (trembling:1.6),  (cum in pussy,  cum on body,  facial,  cum on breasts , bukkake,  :1.3), ( looking at another,  looking away:1.2) ,  tearing up,  streaming tears,  open eyes , open mouth , spread legs,  ass ,  

## タイトル
{ sad , cry}  , (heavy breathing:1.2)  , tearing up,  streaming tears, <lora:tentacles_v0.4:0.8:lbw=MIDD> , (many many oily tentacles:1.2), (mucus:1.2), (__nsp/my/panties__:1.2) , __nsp/my/new_panties__ , focus panties , detail panties , { 2::{front | cowboy shot }, ( knees together , legs closed:1.3) , (front:1.2), pov , {  sitting ,spread legs |   { <lora:hugging_own_legs_v0.3:1> hugging own legs | 2::hands on floor } } },  water surface , { looking at viewer | looking to the side | face down } 

## サムネ

(tentacle pit:1.1) , tentacles , tentacle nest , open clothes,  { (__nsp/my/new_bra__ , __nsp/my/bra__:1.2) | 2::(nipples  , nsfw:1.2) } ,{ 4::open mouth | closed mouth } , { open eyes | close eyes | one eye closed }  ,  tentacles , tentacle pit , tentacles , <lora:tentacles_v0.4:0.75>  , looking at viewer, BREAK
(tentacle pit:1.1) , tentacles , tentacle nest , open clothes,  { (__nsp/my/new_bra__ , __nsp/my/bra__:1.2) | 2::(nipples  , nsfw:1.2) } ,{ 0.8::frown , nose blush,  embarrassed,  sweat, tearing up,   |  cry , sad , clenched teeth,  sweat, tearing up,  streaming tears  | nose blush,  embarrassed,  (heavy breathing:1.2) , spoken heart,  heart-shaped pupils,  cum in pussy , cum , pussy juice | 8::cry , sad , tearing up,  streaming tears,  (shouting:1.2), surprised, open mouth  | 3::(expressionless:1.3), (empty eyes:1.5), (cum in pussy,  cum on body,  facial,  cum on breasts , bukkake,  :1.3), ( looking at another,  looking away:1.2) ,  tearing up,  streaming tears,  open eyes , open mouth }, { 4::open mouth | closed mouth } , { open eyes | close eyes | one eye closed }  ,  tentacles , tentacle pit , tentacles , <lora:tentacles_v0.4:0.75>  , looking at viewer, BREAK