# 着替え怒られ
multiple girls, 2girls, 3girls,   (looking at another:1.3),  platinum blonde hair,  __nsp/my/hair_length__ , __nsp/my/hair__ , <lora:covering_breasts_v0.1:1> , locker room,  frown,  angry ,  (covering crotch:1.1), (covering breasts:1.1)  ,  { 2::(nude:1.2) | __nsp/my/bra__ , panties ,  lingerie } , embarrassed , (standing:1.1) ,  surprised,  open mouth,  (spoken !:1.1),  front ,  { bottomless |  upper body } , <lora:flat2:-0.2> , locker room,  (from below:1.2), 

# カベSEX
petite, glorywall, bent over, full view,  cry, sad , tearing up,  streaming tears,  blush , open mouth,  <lora:bluearchivefull1:0.8:OUTD> shirokodef, silver hair , blue scarf ,  blue eyes , medium hair , none ear , lower body, through wall, outdoors, standing, (mugshot on wall), expressionless, thin thighs, ass focus, wet vagina, sweat , trembling, dripping, pussy, bottom only , rear pussy,  bottomless, cum in pussy,  (trembling:1.3)(trembling:1.3) , face down ,  from behind, bottomless

# キモイ
1girl , solo , school uniform,  pleated skirt,  loafers, miniskirt,  stomping, panties , ceiling ,  black hair,  long hair,  braid ,   from below,  school uniform,  classroom,  face down, sitting, on desk,  angry , sadistic smile , open mouth,  blush , bottomless,  sole ,  lace panties, 

#スカートたくし上げ　二人
 illustration  ,  (Top Quality, 8k:1.1), (Sharp Focus:1.2), (perfect anatomy:1.2),  BREAK
class room , from from below,  ceiling,  BREAK
2 girls, black hair, long hair, wavy hair,  sadistic smile , (smile ,  grin:1.3) , school uniform , pleated skirt, front , skirt lift,  lifted by self,  nsfw , panties , cotton panties , detail panties ,  front , looking at viewer,  braid , BREAK
2 girls, brown hair, short hair, (blush:1.2) , embarrassed,  nose blush,  open eyes , frown ,  standing, mascara,  blonde hair,  micro mini skirt , school uniform, pleated skirt, front,  skirt lift,  lifted by self,  nsfw , panties , lace panties , sweat, front , looking at viewer, tearing up, ponytail,  BREAK


# 二人ブラ見せ
2 girls, black hair, long hair, wavy hair,  sadistic smile , (smile ,  grin:1.3) , school uniform , open clothes,  bra , detail bra , lace bra , __nsp/my/hair__ , __nsp/my/hair_length__ ,  lifted by self,  nsfw , panties , cotton panties , detail panties ,  front , looking at viewer,  braid ,  upper body , (selfie:1.2)  BREAK
2 girls, brown hair, short hair, (blush:1.2) , embarrassed,  nose blush,  open eyes , frown ,  standing, mascara,  blonde hair,   school uniform , open clothes,   bra , detail bra , cotton bra , sweat,  looking at viewer, tearing up, __nsp/my/hair__,  __nsp/my/hair_length__  (selfie:1.2)  upper body

(maid , maid headdress , maid apron ,  mini skirt:1.3) __nsp/my/new_panties__ ,  { <lora:skirt_tug_v0.1:1>   (skirt tug:1.1) , looking at down , light frown , blush , nose blush ,  face down , standing , (spoken exclamation mark:1.2),  (bottomless:1.1) , from below , ceiling  | smile , skirt lift,  lifted by self , front  , pov  }  , classroom ,  lace panties,  detail panties 


# 盗撮風
nude , __nsp/my/bra__ , panties , (fisheye:1.2) , (Fish eye lens:1.2) ,  <lora:undressing_panties_v0.1:1:MIDD> , (nude , __nsp/my/bra__:1.1) , spoken exclamation mark,  surprised , (washroom:1.2)  , frown , looking at viewer, blush, embarrassed, indoors , undressing, panty pull , pulled by self , { from below | from above } ,  (fake screenshot:1.3)

# バック

    1boy , 1girl , from behind, standing , wall ,  ass focus , penis , penis in pussy , back , vaginal , sex  ,    (sex from behind:1.2) , {(nude:1.2) | open clothes, nipples, shiny hair } , { frown | smile | one eye closed } , { closed mouth | open mouth } ,  breath,  saliva,  saliva trail,    penis , cum in pussy  , solo , sweat, tearing up, open mouth, frown, motion blur , motion lines, (sweat:1.2) , { 2::tearing up | shiny hair } , cum in pussy,  cum explosion, 


✨🤟😁🤗😍😆👍🙌✨👩‍👩‍👦‍👦sex sex sex wet wet✨✨ ❗ 🙏😁❤	

# フェラ
1boy , 1girl ,  (fellatio:1.2) ,  kneeling , licking penis ,  penis , cum shot , grab penis , mouth in penis , mouth  , hetero,  cum in mouth,  oral , sweat, laughing,  spoken heart,  ahegao,  (facial , cum on body:1.2) , upper body , bottomless,  face focus , from side ,   indoors,  looking up , looking at another  ,  on bed , 


#四つん這い
, <lora:doggystyle_piledriver_v0.3:1> , top-down bottom-up ,  from behind, looking back , pussy juice,  sweat,  smile , blush,  <lora:POVMissionary:1> , 


# シーのポーズ（黙って)
shushing,clothes lift,skirt lift,lifted by self, frown, teeth ,  <lora:Saya-shushing:1:INS>

#寝そべり開脚
1girl, solo , spread legs, bottomless, { open clothes,  nude , pussy, anal , female masturbation ,puffy nipples , focus vaginal , detail vaginal  | lace panties , focus panties , detail panties , wet panties } , fingering, on bed,  heavy breathing, open mouth, nose blush , panicking , frown , <lora:Saya-lying spread legs:0.6:MIDD>  , pussy juice, 

#Saya
 smile, laughing,  one eye closed,  1girl,vaginal,torso grab, <lora:Saya-pov missionary(torso grab):1:MIDD>
 
 1girl,vaginal, thigh grab,   ,  <lora:Saya-pov missionary(holding legs):0.9:MIDD> ,  { scared ,  cry , sad , streaming tears , tearing up ,  open mouth , cum , cum in pussy , cum drip , cum explosion , face down , looking at down   |   { frown | smile (spoken heart:1.2) , }  (pussy juice:1.2) , nose blush |  sweat } , (motion lines:1.2),  trembling,  sweat, tearing up,, 



# 一次保存

(illustration:1.1) , game cg,   (perfect anatomy:1.2)  ,  detail eyes , shiny skin,  shiny hair,  detail eyes ,   (Top Quality, 8k:1.1), (Sharp Focus:1.2), (perfect anatomy:1.2),  BREAK
class room , from from below,  ceiling,  BREAK
2 girls, 1girl , solo , <lora:bluearchivefull1:1>, arisdef, front , skirt lift,  lifted by self,  nsfw , panties , cotton panties , detail panties ,  front , looking at viewer,  shushing,clothes lift,skirt lift,lifted by self, frown, teeth ,  <lora:Saya-shushing:1:INS> , panties   BREAK
2 girls, 1girl , solo , <lora:bluearchivefull1:1>, midoridef , front , skirt lift,  lifted by self,  nsfw , panties , cotton panties , detail panties ,  front , looking at viewer,  shushing,clothes lift,skirt lift,lifted by self, frown, teeth ,  <lora:Saya-shushing:1:INS> , panties 

#立ち下から

 spread legs, bottomless, tearing up, focus vaginal , smile , detail vaginal , heavy breathing, open mouth, nose blush , frown , spread legs, bottomless, hands on crotch , from below

 # オナニー

 ( breasts grab , grabbing another’s breast:1.2) , { ecstasy face ,  open mouth , one eye closed | closed mouth , frown, nose blush } , sitting , spread legs,  vaginal , on bed ,  saliva,  swet , 

 # ちんこ挿入前

- 正常位
 <lora:IPV1:0.8:OUTALL> , 1boy, penis, imminent penetration, lying, on back, spread legs, pov, leg grab , embarrassed,  frown ,  ecstasy face ,  grab penis   <lora:PSCowgirl:1>

- 騎乗位

 <lora:IPV1:0.9:OUTALL>, 1boy, penis, imminent penetration, spread legs,<lora:PSCowgirl:0.4>, squatting , ceiling , from below, smile , 

- バック