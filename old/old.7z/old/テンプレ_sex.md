# ストーリー候補


## 512 * 768 縦長

## 前座 

8k wallpaper, extremely detailed fingers, detail eyes , perfect anatomy, highly detailed background, shiny skin, narrow waist, BREAK
1girl, 1boy ,   breasts, mature female,   BREAK
<lora:pecorine_v1:1> 24yo,  (large breasts:1.2), aapeco, very long hair, ahoge, braid, tiara, hair ribbon, { red ascot, cleavage, shrug (clothing), white dress, short sleeves, white gloves, pleated skirt, red skirt |  2::(nude, naked:1.5) }   BREAK

nsfw , {3-10$$(embarrassed, nose blush:1.3) | (ecstasy:1.3) | (slut:1.2) | (vulgarity:1.3) | (fucked silly:1.1) | (wet:0.8) | (trembling:0.8)| (tears:0.7) | (drooling:0.6) | (sweat:0.8) | {  4::open eyes | (closed eyes:1.2) } | wince | (orgasm:1.5) | (half open eyes:1.4) | (feeling weak:1.5) | cum in pussy , cum on body | cum explosion } , on bed , in door , {3::open mouth | parted lips | closed mouth }   |   BREAK


<!-- 8k wallpaper, extremely detailed fingers, detail eyes , perfect anatomy, highly detailed background, shiny skin, narrow waist  BREAK
{ (embarrassed,blush:1.3), (wet:0.8),(sweat:0.8),(trembling:1.3) , (parted lips:1.3),(harf open eyes:1.4),(feeling weak:1.5) , open mouth  | (embarrassed,blush:1.3),(wet:0.8),(sweat:0.8),(trembling:1.3) ,(parted lips:1.3),(harf open eyes:1.4),(feeling weak:1.5) , open mouth } ,  { 1-3$$(cum in pussy:1.2) | cum on breasts | cum on body | shiny skin , (motion blur:1.3) } , (trembling:1.5) BREAK -->

# 催眠表情
nsfw , nsfw , {20$$(embarrassed, nose blush:1.3) | (ecstasy:1.3) | (slut:1.2) | (vulgarity:1.3) | (wet:0.8) | (trembling:0.8)| (tears:0.7) | (drooling:0.6) | (sweat:0.8) | { open eyes } | wince | (orgasm:1.5) |(feeling weak:1.5) | sweat}    , (heavy breathing:1.2) ,  { 6::sweat |  cum in pussy , cum on body , cum explosion  }  (trembling:1.1),  BREAK

# レイプ
nude  ,  naked , tearing up,  streaming tears,  wavy mouth,  sobbing ,  pussy juice,  heavy breathing,  open mouth,  (looking away:1.5),  (motion lines,  trembling,:1.5) , (expressionless:1.3), (empty eyes:1.7), scared,  (trembling:1.6) , open mouth,  cum in pussy , 

# すやすや


# 表情

nsfw , {20$$(embarrassed, nose blush:1.3) | (ecstasy:1.3) | (slut:1.2) | (vulgarity:1.3) | (wet:0.8) | (trembling:0.8)| (tears:0.7) | (drooling:0.6) | (sweat:0.8) | {  6::open eyes | (closed eyes:1.4) } | wince | (orgasm:1.5) |(feeling weak:1.5) | sweat}  , { ahegao,  wave mouth, frown |  shouting , open mouth |   sweat , frown  }  , (heavy breathing:1.2) ,  { 6::sweat |  cum in pussy , cum on body , cum explosion  }  (trembling:1.1),  { tareme  } ,   BREAK

## アヘ顔
nsfw , {20$$(embarrassed, nose blush:1.3) | (ecstasy:1.3) | (slut:1.2) | (vulgarity:1.3) | (wet:0.8) | (trembling:0.8)| (tears:0.7) | (drooling:0.6) | (sweat:0.8) | {  6::open eyes | (closed eyes:1.4) } | wince | (orgasm:1.5) |(feeling weak:1.5) | sweat}  ,{ ahegao,  wave mouth, frown | seductive smile  }  , (heavy breathing:1.2) ,  (trembling:1.4), tareme  , (heavy breathing:1.2) ,  { 1.5::sweat |  cum in pussy , cum on body , cum explosion  }  (trembling:1.1),  { tareme  } ,   BREAK


<!-- nsfw , {20$$(embarrassed, nose blush:1.3) | (ecstasy:1.3) | (slut:1.2) | (vulgarity:1.3) | (wet:0.8) | (trembling:0.8)| (tears:0.7) | (drooling:0.6) | (sweat:0.8) | {  6::open eyes | (closed eyes:1.4) } | wince | (orgasm:1.5) |(feeling weak:1.5) | sweat}  , { ahegao,  wave mouth, frown | sweat , frown | {4$${ tearing up |   streaming tears |  cry | sad | sobbing | scared   } }  }  , (heavy breathing:1.2) ,  { 6::sweat |  cum in pussy , cum on body , cum explosion  }  (trembling:1.1),  { tareme  } ,   BREAK -->

## アヘ顔
{ ahegao,  wave mouth, frown | seductive smile  }  , (heavy breathing:1.2) ,  (trembling:1.1), tareme

## くっころ
angry ,  disgust,   clenched teeth,  (heavy breathing:1.2) ,  (trembling:1.1),   clenched teeth, tearing up,  streaming tears,  saliva 

## 新

### SEX
 ,( 1boy , spread legs,  missionary , sex , penis in vaginal , pussy juice , focus crotch , lying , on bed :1.3) , { hands on own chest  |  breasts squeezed together , __nsp/myNSFW/commonArm__ } , sex ,  (motion lines , trembling:1.3),  on back ,   spread legs, 


 <lora:DildoRidingBack:0.95:lbw=MIDD> , DILDORIDINGBACK ,  DILDO  , DILDO RIDING , FROM BEHIND
## StylePile
<lora:MissionaryVaginal-v2:0.75:lbw=MIDD> missionary vaginal, spread legs, { sweat | legs up} ,  deep, huge tentacles  , Amateur

<lora:POVMissionary:0.6:lbw=MIDD> , {arms up | hands on own chest  |  breasts squeezed together , __nsp/myNSFW/commonArm__ } , sex ,  motion lines , on back , 
{ lying, missionary ,  {arms up | hands on own chest  |  breasts squeezed together }   |  straddling , cowgirl position, from below,  ceiling  ,  { sweat | hands on own chest  |  breasts squeezed together } } missionary, vaginal, 1boy, penis, spread legs , <lora:motion_blur_v0.3:1> , motion blur, 
{ lying, missionary ,  {arms up | hands on own chest  |  breasts squeezed together }   |  straddling , cowgirl position, from below,  ceiling  ,  { sweat | hands on own chest  |  breasts squeezed together } } missionary, vaginal, 1boy, penis, spread legs , <lora:motion_blur_v0.3:1> , motion blur, 
<lora:PSCowgirl:0.75:lbw=MIDD> , 1boy,squatting cowgirl position, vaginal, pov, pussy
<lora:PSCowgirl:0.75:lbw=MIDD> , 1boy,squatting cowgirl position, vaginal, pov, pussy
<lora:CONCEPT-HipGrabCowgirl:1> , POVHipGrabCowgirl, hetero, vaginal , penis in vaginal , open pussy , 
lying , ass focus , from behind , on back ,  missionary, vaginal, 1boy, penis, spread legs , <lora:motion_blur_v0.3:1> , motion blurbest quality, masterpiece, very aesthetic, absurdres , (ultrahigh resolution textures), bokeh, intricate details, hyperdetailed, (official art, extreme detailed,) ( highest detailed), HDR+ , , 
<lora:EkuneCowgirl:0.75:lbw=MIDD> , cowgirlpose, (1boy, penis:1.1), cowgirl position, ass , pussy, anus  , bottomless  , ass grab , hip grab  , on bed ,
<lora:SideFellatio:1> , 1boy , sidefellatio, 1boy, penis , fellatio, from side, cum in mouth , face up  , kneeing, 1boy 
<lora:POVDoggy:0.4:lbw=MIDD> , from behind , all fours , doggy style ,  penis in pussy, on bed , sheet grab,  doggystyle, pov hands, ass grab, ({ pillow hug | sheet grab}:1.2) ,  looking at viewer, 
nsfw,pov,astride,thrusting <lora:cowgirl_with_hands_on_knees_v1.0:0.8:lbw=MIDD> , thrusting
 <lora:front_view_all_fours_doggystyle_v1.0:0.85> doggystyle, all fours,  sex from behind, facing viewer
 lying on bed , stomach,   spread legs , pussy , (looking away:1.3)  ,  on bed , indoors, pussy , <lora:Saya-spread pussy(fingers)2:0.8> , spread pussy , front , { cum in pussy | 2::sweat} , 
sitting , spread legs , pussy , ass , indoors, pussy ,, front , <lora:dskbSPu:0.2:lbw=MIDD> , dskbSPu , uterus ,  focus crotch, front , crotch focus , 
<lora:Saya-lying on back6:0.8:lbw=MIDD> , on back , spread legs,  pussy , vaginal , on back , on bed , 

## StylePile
<!-- <lora:IPV1:0.8:lbw=MIDD> , 1boy, penis, imminent penetration, lying, on back, spread legs, 1, leg grab
<lora:POVMissionary:0.6:lbw=MIDD> , {arms up | hands on own chest  |  breasts squeezed together , __nsp/myNSFW/commonArm__ } , sex ,  motion lines , on back , 
{ lying, missionary ,  {arms up | hands on own chest  |  breasts squeezed together }   |  straddling , cowgirl position, from below,  ceiling  ,  { sweat | hands on own chest  |  breasts squeezed together } } missionary, vaginal, 1boy, penis, spread legs , <lora:motion_blur_v0.3:1> , motion blur, 
<lora:PSCowgirl:0.75:lbw=MIDD> , 1boy,squatting cowgirl position, vaginal, pov, pussy
<lora:CONCEPT-HipGrabCowgirl:1> , POVHipGrabCowgirl, hetero, vaginal , penis in vaginal , open pussy , 
lying , ass focus , from behind , on back ,  missionary, vaginal, 1boy, penis, spread legs , <lora:motion_blur_v0.3:1> , motion blur, 
<lora:EkuneCowgirl:0.75:lbw=MIDD> , cowgirlpose, (1boy, penis:1.1), cowgirl position, ass , pussy, anus  , bottomless  , ass grab , hip grab  , on bed ,
<lora:SideFellatio:1> , 1boy , sidefellatio, 1boy, penis , fellatio, from side, cum in mouth , face up  , kneeing, 1boy 
<lora:POVDoggy:0.4:lbw=MIDD> , from behind , all fours , doggy style ,  penis in pussy, on bed , sheet grab,  doggystyle, pov hands, ass grab, ({ pillow hug | sheet grab}:1.2) ,  looking at viewer, 
1girl, 1boy, doggystyle, all fours, sex from behind, facing viewer, nsfw <lora:Doggy:0.8:lbw=MIDD> , on bed , { pillow hug | sheets grab } , { from side|  front } 
nsfw,pov,astride,thrusting <lora:cowgirl_with_hands_on_knees_v1.0:0.8:lbw=MIDD> , thrusting
 <lora:front_view_all_fours_doggystyle_v1.0:0.85> doggystyle, all fours,  sex from behind, facing viewer
 lying on bed , stomach,   spread legs , pussy , ass , , looking at viewer,  on bed , indoors, pussy , <lora:Saya-spread pussy(fingers)2:0.9> , spread pussy , front , cum in pussy , 
sitting , spread legs , pussy , ass , indoors, pussy ,, front , <lora:dskbSPu:0.2:lbw=MIDD> , dskbSPu , uterus ,  focus crotch, front , crotch focus , 
<lora:Saya-lying on back6:0.8:lbw=MIDD> , on back , spread legs,  pussy , vaginal , on back , on bed ,  -->

## 1024 対応

<lora:kneestogetherfeetapart:1> , knees together feet apart, sitting, pussy , vaginal , arms behind back , detail vaginal , detail pussy 
<lora:SidewayAss:1> , sidewayassms , spread pussy , spread ass ,hand on own ass ,lying
{ lying, missionary ,  {arms up | hands on own chest  |  breasts squeezed together }   |  straddling , cowgirl position, from below,  ceiling  ,  { sweat | hands on own chest  |  bearsts squeezed together } } missionary, vaginal, 1boy, penis, spread legs , <lora:motion_blur_v0.3:1> , motion blur, 
 lying on bed , stomach,   spread legs , pussy , ass , , looking at viewer,  on bed , indoors, pussy , <lora:Saya-spread pussy(fingers)2:0.8:lbw=OUTD> , spread pussy , front 
<lora:pzuri:1:1:lbw=MIDD> , 1boy, breasts, heavy breathing, paizuri,penis  , ejaculation, projectile_cum, nipples, breasts squeezed together, cum on breast, 1boy, (penis:1.2), smile , laughing, front , looking at viewer,  pov , sweat, { cum | cum shot | sweat } 

### ヘッダー
{ nose blush,  embarrassed,  { smile | light smile }  | 1.5::nose blush,  embarrassed,  (heavy breathing:1.2) , spoken heart }, { 2::open mouth | closed mouth } , { open eyes | one eye closed }  , looking at viewer, BREAK


### 胸寄せ
<lora:breasts_squeezed_together_v0.2:1> , { 2::breasts squeezed together | 2::v arms | hands on own chest } , upper body,  { 2:: from below |   cowboy shot }   from above,  looking at viewer, smile ,  indoors,  in hotel 

### 体操座り
<lora:kneestogetherfeetapart:0.8:lbw=MIDD> , knees together feet apart, sitting, panties, pantyshot
 
### バック顔
 <lora:front_view_all_fours_doggystyle_v1.0:0.85> doggystyle, all fours,  sex from behind, facing viewer

### うつ伏せ
<lora:wpose:0.75:lbw=MIDD> , ass, lying, on stomach, pussy, spread legs, anus, spread legs, upper body,  on bed , { pillow hug | pillow grab } 

### 横向きにお尻
 <lora:SidewayAss:0.8:lbw=MIDD> , sidewayassms , spread pussy,spread ass ,hand on own ass

### オマンこ見せ1 
<!-- pussy show, 1girl, anus, ass, pussy, multiple views, looking at viewer, breasts, simple background,  white background, stomach,  uncensored, side-tie bikini bottom, from behind, kneeling,  thighs, nude, back ,  <lora:pussy show:1:lbw=IND> -->

### くぱぁ
 lying on bed , stomach,   spread legs , pussy , ass , , looking at viewer,  on bed , indoors, pussy , <lora:Saya-spread pussy(fingers)2:0.9> , spread pussy , front , cum drip , tearing up,  streaming tears, 

### 挿入前
<lora:IPV1:0.8:lbw=MIDD> , 1boy, penis, imminent penetration, lying, on back, spread legs, 1, leg grab

### 騎乗位挿入前
<lora:IPV1:0.9>, 1boy, penis, imminent penetration, spread legs, <lora:PSCowgirl:0.4>, squatting

### 終わり
<lora:aftersex:0.75> , after sex, cum, lying, cumdrip, ass, on stomach, on back, fucked silly, sweat, cum pool, bukkake, trembling , <lora:cervix:0.75> cervix, spread pussy, clitoris, urethra , on bed ,  spread legs,  ass  , (trembling:1.3), 

## 本番

### 悲しみヘッダー
{ cry , sad , sobbing | scard |  (expressionless:1.3), (empty eyes:1.7), scared,  (trembling:1.6),  (cum in pussy,  cum on body,  facial,  cum on breasts , bukkake,  :1.3) } , ( looking at another,  looking away:1.2) ,  tearing up,  streaming tears,  (open eyes , open mouth:1.3) , saliva trail


### ヘッダー
{ nose blush,  embarrassed,  sweat | 1.5::nose blush,  embarrassed,  (heavy breathing:1.2) , spoken heart , cum in pussy , cum , pussy juice }, { 2::open mouth | closed mouth } , { open eyes | close eyes | one eye closed }  , looking at viewer, BREAK

### 正常位　騎乗位
{ lying, missionary ,  {arms up | hands on own chest  |  breasts squeezed together }   |  straddling , cowgirl position, from below,  ceiling  ,  { sweat | hands on own chest  |  breasts squeezed together } } missionary, vaginal, 1boy, penis, spread legs ,__sell/template_missionary__ , <lora:motion_blur_v0.3:1> , motion blur, 

## キス

 <lora:POV_KISS:0.4:lbw=MIDD>  , on bed ,  straddling
 
### 足上げ正常位 512 , 768推奨
 <lora:missionary_raised_legs:0.6:lbw=MIDD> , missionary, vaginal, sex

###　騎乗位
 <lora:PSCowgirl:1:lbw=MIDD> , 1boy,squatting cowgirl position, vaginal, pov, pussy in vaginal , cum in pussy,  cum in pussy,  

### 正常位2              
<lora:POVMissionary:0.6:lbw=MIDD> , {arms up | hands on own chest  |  breasts squeezed together , __nsp/myNSFW/commonArm__ } , { sex |  mlegs } ,  motion lines  , on bed , indoors,  cum in pussy 

### 脚とじ
<lora:missionary_legs_toghether_v1:0.35:lbw=MIDD> , sex  , vaginal , missionary ,  {arms up | hands on own chest  |  breasts squeezed together , __nsp/myNSFW/commonArm__ } , sex ,  penis in pussy , 1boy ,  motion lines  ,{  barefoot, feet, soles  | shiny hair }  , on bed 

### ガイド挿入
completely nude, cowgirl position, gradient background, imminent penetration,  <lora:guipen:1> , penetration guide 

### バック
lying , ass focus , from behind , on back ,  missionary, vaginal, 1boy, penis, spread legs ,__sell/template_missionary__ , <lora:motion_blur_v0.3:1> , motion blur, 

### バック
<lora:POVDoggy:0.4:lbw=MIDD> , from behind , penis in pussy, on bed , sheet grab,  doggystyle, pov hands, ass grab, ({ pillow hug | sheet grab}:1.2) ,  looking at viewer, 


### 後ろ騎乗位
<lora:EkuneCowgirl:0.45:lbw=MIDD> , cowgirlpose, (1boy, penis:1.1), cowgirl position, ass , pussy, anus  , bottomless  , ass grab , hip grab , __sell/template_missionary__  , on bed ,

### 横フェラ
 <lora:SideFellatio:1> , sidefellatio, 1boy, penis, fellatio, from side, smile , laughing,  (heavy breathing:1.2),  

# 768 * 512 横長
1girl, (1boy, doggystyle:1.3), all fours, (sex from behind:1.3), facing viewer, nsfw ,  <lora:Doggy:0.8:lbw=IND> , on bed , { pillow hug | sheets grab } 
<lora:PSCowgirl:0.75:lbw=MIDD> , 1boy,squatting cowgirl position, vaginal, pov, pussy
<lora:EkunePOVFellatioV2:0.75:lbw=MIDD> , fellatio,  povfellatio, 1boy , (penis:1.2) ,  cum in mouth, cum drip, all fours ,  front , pov ,  from above , (facial,  bukkake:1.3) , collarbone, 
 <lora:EkuneSideDoggy:0.75:lbw=MIDD> ,  sidedoggystyle, 1boy, ass, doggystyle, sex, all fours, standing sex, torso grab, top-down bottom-up,  ({ pillow hug | sheet grab}:1.2) ,  looking at viewer,  sweat, (trembling:1.3)
 <lora:EkuneProneBone:0.75:lbw=MIDD> , proneposition, prone bone, 1boy, ass, lying, sex from behind, pillow, prone bone, (1boy:1.2),  lying, (sex from behind:1.3), (sex:1.3), looking at viewer, legs together, (motion blur), (motion line), boy holding girl , from side  ,  ({ pillow hug | sheet grab}:1.2) , (trembling:1.3) ,  looking at viewer,  sweat, nose blush, 
 <lora:EkuneProneBone:0.75:lbw=MIDD> , proneposition, prone bone, 1boy, ass, lying, sex from behind, pillow, prone bone, (1boy:1.2),  lying, (sex from behind:1.3), (sex:1.3), looking at viewer, legs together, (motion blur), (motion line), boy holding girl , from side  ,  ({ pillow hug | sheet grab}:1.2) , (trembling:1.3) ,  looking at viewer,  sweat, nose blush, 
 <lora:fucsil1:0.75:lbw=MIDD> ,  on bed, simple background, indoors, sex from behind, 1boy, (motion lines:1.5), (trembling:1.3), (motion blur:1.2), 
 <lora:fucsil1:0.75:lbw=MIDD> ,  on bed, simple background, indoors, sex from behind, 1boy, (motion lines:1.5), (trembling:1.3), (motion blur:1.2), 

## 新正常位
<lora:MissionaryVaginal-v2:0.7:lbw=MIDD> ,spreading legs,(missionary vaginal fuck) , laying in bed , uncensored , 1pillow ,  (pov),(deep penetration:1.3), (motion lines,  motion blur:1.2),  ( torso grab:1.2),  half open mouth,  heavy breathing,  embarrassed,  Creampie , close up , Amateur  , sweat,  drooling, <lora:pov_torso_grab_v0.1a:1>pov hands


## パイズリ 640 * 640推奨
<lora:pzuri:1:1:lbw=MIDD> , 1boy, breasts, heavy breathing, paizuri,penis  , ejaculation, projectile_cum, nipples, breasts squeezed together, cum on breast, 1boy, (penis:1.2), smile , laughing, front , looking at viewer,  pov , sweat, { cum | cum shot | sweat } 


## フェラ 768*512 (横長推奨)
<lora:EkunePOVFellatioV2:1:lbw=MIDD> , fellatio,  povfellatio, 1boy , (penis:1.2) ,    bukkake,  { sweat | facial , bukkake ,  <lora:bukkake_v0.4:1> } 

## 横ドギー 768*512 推奨
 <lora:EkuneSideDoggy:0.65:lbw=MIDD> ,  sidedoggystyle, 1boy, ass, doggystyle, sex, all fours, standing sex, torso grab, top-down bottom-up,  ({ pillow hug | sheet grab}:1.2) ,  looking at viewer,  sweat, (trembling:1.3)

## 横寝るバック　768*512 (横長推奨)
 <lora:EkuneProneBone:0.7:lbw=MIDD> , proneposition, prone bone, 1boy, ass, lying, sex from behind, pillow, prone bone, (1boy:1.2),  lying, (sex from behind:1.3), (sex:1.3), looking at viewer, legs together, (motion blur), (motion line), flat chest, (petite female body), boy holding girl , from side  ,  ({ pillow hug | sheet grab}:1.2) , (trembling:1.3) ,  looking at viewer,  sweat, nose blush, 

## 後ろから
 <lora:fucsil1:1:lbw=MIDD> ,  on bed, simple background, indoors, sex from behind, 1boy, (motion lines:1.5), (trembling:1.3)

## オナ
 <lora:masturbation-v1:1>masturbation, fingering, female_masturbation, grabbing_own_breast , sitting , on bed , spread legs,  __nsp/my/angle__ , looking at viewer, 

# 640 * 640
<lora:pzuri:0.6:lbw=MIDD> , 1boy, breasts, heavy breathing, paizuri,penis  , ejaculation, projectile_cum, nipples, breasts squeezed together, cum on breast, 1boy, (penis:1.2), smile , laughing, front , looking at viewer,  pov , sweat, { cum | cum shot | sweat } 
<lora:female_masturbation_v0.5:0.7> , 1girl , female masturbation, { open eyes  | one eye closed | closed eyes }  { spread legs | wariza | lying , on stomach } , on bed , pussy, orgasm, female orgasm, pussy juice, nose blush, ,  { closed mouth | open mouth }  , sweat,  __nsp/my/angle__ , { own breast grab | sweat }  , (trembling:1.5), 
<lora:female_masturbation_v0.5:0.7> , 1girl , female masturbation, { open eyes  | one eye closed | closed eyes }  , { 3::spread legs | wariza }  , on bed , pussy, ahegao , pussy juice, nose blush, ,  { closed mouth | open mouth }  , sweat,  __nsp/my/angle__ , { own breast grab | sweat }  , (trembling:1.5), 
1girl, 1boy, doggystyle, all fours, sex from behind, facing viewer, nsfw <lora:Doggy:0.8:lbw=MIDD> , on bed , { pillow hug | sheets grab } 
nsfw,pov,astride,thrusting <lora:cowgirl_with_hands_on_knees_v1.0:0.8:lbw=MIDD> , thrusting ,( motion lines,  motion blur,:1.4)  

# Batch
lying , on bed , pussy , vaginal , open crotch , hands on crotch 


## 終わり

streaming tears,  tearing up,  open mouth,  after sex,  orgasm,  female orgasm,  sitting , on couch  ,  spread legs,  empty eyes,  looking at another,  looking to the side,  after sex, cum,  cumdrip, fucked silly, sweat, cum pool, bukkake, trembling , { pillow hug | sheets grab } , hands on pussy,  hands on vaginal , 

## レイプ目
{  nipples | __nsp/my/new_bra__ } ,  (expressionless , empty eyes :1.3),  streaming tears,  tearing up,  after sex,  pussy , on bed , lying , (looking at another,  looking away:1.2),  open mouth,  open eyes ,  (spread legs, ass ,   cum in pussy,  cum on body,  facial,  cum on breasts:1.2),  cum explosion, 

### 終わり
squatting cowgirl position, vaginal, pov,  on bed, after sex, cum in pussy , cum explosion

# 640 * 640 

##　真下
 standing  , (spread legs:1.3),   floral pattern embroidery panties ,   __nsp/my/panties__ , (focus crotch:1.4)  ,  bow panties ,  (detail panties:1.2) , narrow waist ,  (Directly below:1.3) , (from below:1.2) ,  bottomless , (skirt lift,  lifted by self:1.1) , looking at viewer ,  embarrassed,  upper body,  (headless , body only:1.2) 

### 椅子座り真下
looking down , face down , ceiling , arms on knee , frown , (from below:1.2), floral pattern embroidery panties , (directory below:1.2) , sitting , on chair , mini skirt , pleated skirt, ,smile , embarrassed, front , ?, spoken question mark , head tilt , smile ,


## オナニー
### ヘッダー
{ nose blush,  embarrassed,  sweat | 1.5::nose blush,  embarrassed,  (heavy breathing:1.2)  }, { 2::open mouth | closed mouth } , { open eyes | one eye closed }  , looking at viewer, BREAK female masturbation,  fingers in pussy ,  cowboy shot,   full body,  looking away   ( recording mark  , battery indicator:1.3), 


 ### パンツオナ

 upper body,  (looking at another,  looking to the side,  looking away:1.1),  hands on crotch , <lora:hand_in_panties_v0.82:1> , hand in panties , indoors,  hotel room, __nsp/my/angle__ , { own breast grab | sweat }  , (trembling:1.5), 

### 通常
<lora:female_masturbation_v0.5:1> , 1girl , female masturbation,  { front | cowboy shot } ,  { 2::(sitting ,  spread legs:1.2) | 2::(sitting , wariza:1.2) | lying , on stomach } , on bed , pussy, pussy juice, nose blush , sweat, { own breast grab | sweat }  , (trembling:1.5), 


### 枕オナ

<lora:pillow_sex_v0.3:1> 1girl, (crotch rub, pillow humping:1.2),  pussy,  sweat, { own breast grab | sweat } , { own breast grab | sweat }  , (trembling:1.5), 

### フィニッシュ
<lora:female_masturbation_v0.5:0.7> , 1girl , female masturbation, { 3:: sitting , spread legs | sitting , wariza }  , on bed , pussy , pussy juice, sweat,  __nsp/my/angle__ , { own breast grab | sweat }  , (trembling:1.5),  heavy breathing,  sweat,  looking at another,  looking to the side,  looking away, 

### 見つかり
(surprised, spoken exclamation mark, panicking:1.1),    ,  open mouth ,   open eyes BREAK<lora:female_masturbation_v0.5:0.7> , 1girl , female masturbation, { 3:: sitting , spread legs | sitting , wariza }  , on bed , pussy , pussy juice, sweat,  , { own breast grab | sweat }  , (trembling:1.5),  heavy breathing,  sweat,  looking at viewer,  front 

## 角オナ

<lora:table_humping_v0.1:1lbw=MIDD>  table humping, crotch rub, office, white panties, skirt lift, lanyard, table, lifting, suggestive fluid, face down , looking at another,  looking to the side,  female orgasm,  panties, lifted by self,   embarrassed,  orgasm,  ecstasy,  nose blush,   { own breast grab | sweat }  , (trembling:1.5), 

## 手コキ　512 * 512
<lora:cuddling_handjob_v0.1b:1> , cuddling handjob  , 1boy , penis , penis grab , (motion lines:1.4),  on bed ,  lying , 


# Controlnet

## オマンコ開き
C:\イラスト関係\成果\保存\Controlnet\ctrlnet\OpenposeNSFWPresenting_v10\OpenPose\batch

pussy , vaginal , open pussy ,  cum in pussy 

## 足裏 深度　無し

(front:1.2) , sitting , on bed , in classroom , focus face , skirt , sole , barefoot ,  __api/panties__ , __nsp/my/new_panties__ 

## 騎乗位 openPose

straddling , cowgirl position, from below,  ceiling  , sweat ,  missionary, vaginal, 1boy, penis, spread legs ,__sell/template_missionary__ , <lora:motion_blur_v0.3:1> , motion blur

## オナにー

 nude , spread legs,  perfect pussy , focus crotch  <lora:newb_0.1:0.2> , open pussy , female masturbation,  hands in pussy ,  orgasm,  female orgasm,  pussy juice,  sweat,  heavy breathing,   clenched teeth,  frown , trembling,   

sitting , on chair , female masturbation,  pussy juice,  panties , ahegao , nose blush,  in classroom, 

## メイドパイズリ

1girl , solo , <lora:gakuen_idolmaster_pony_v2:0.75>  , HANAMI_UME ,HANAMI_UME , wavy hair,  medium hair,  orange hair,  orange eyes,  large breasts,   ahoge  , maid,  maid headdress,  maid apron,  bare shoulders,  large breasts,  miniskirt,  black thighhighs,  paizuri, in classroom , pov , indoors,  from above , penis , nipples,  (motion lines,  motion blur:1.3),  lotion on breasts,  head tilt,  heavy breathing,  orgasm, ecstasy, (bukkake , cum on breasts,  cum on body:1.2),   light smile ,  heavy breathing, 

