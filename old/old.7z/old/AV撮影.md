
nsfw , {15$$(embarrassed, nose blush:1.3) | (ecstasy:1.3) | (slut:1.2) | (vulgarity:1.3) | (fucked silly:1.1) | (wet:0.8) | (trembling:0.8)| (tears:0.7) | (drooling:0.6) | (sweat:0.8) | {  4::open eyes | (closed eyes:1.2) } | wince | streaming tears | sobbing | nose blush | streaming tears |  (orgasm:1.5) | (half open eyes:1.4) | (feeling weak:1.5) | cum in pussy , cum on body | cum explosion } , on bed , in door , {3::open mouth | parted lips | closed mouth }   |   BREAK



# たくし上げ

light smile,  ?,  sweat,  (spoken question mark,:1.3) 
panties , {sitting , wariza }  ,  detail panties { front | from above } , bottomless ,  skirt , (skirt lift,  lifted by self:1.2) , looking at viewer , { in door } , front ,  panties , __nsp/my/panties__ , 

# lying on bed 
lying , on bed , skirt lift,   spoken exclamation mark,   covering breasts,  covering crotch,  skirt lift,  panties, 


arms behind head  ,  lying , on bed , skirt lift,   spoken exclamation mark,   covering breasts,  covering crotch,    panties, 

spread legs,  panties,  ass focus , arms behind back , white panties 