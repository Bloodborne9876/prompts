# 見出し1

人気キャラ ** と休日SEXするだけのCG集です。
各シチュエーションの枚数は1～3枚程度です。
SEXのCGはありません。一部モザイクはしています。

- 販売内容
  - 単品
  　- 制服 , 全裸  合計 枚　※全裸多め
  　- 早期購入特典 休日オナニー

- 提供方法
  - 単品毎の zip , pdf ファイル

- 免責事項
 - 法令遵守のため必要な箇所にガウスぼかし処理が入ります。
 - 各シチュエーションで特定の衣装のみの場合があります。
 - 月末など本商品を他の商品とセット販売で他のサイトやBoothで販売する可能性があります。
 - AIイラストのため、指や手などに欠損や指が増えている場合があります。あらかじめご了承ください。
 - 登場人物は全員20歳以上です。


# 見出し2

主なシチュエーション：

- 【縦長】
- 立ち胸寄せ
- 四つん這いコンドーム咥え
- 座り挿入おねだり
- うつ伏せ挿入おねだり
- 横向きにお尻を向け挿入おねだり 
- 挿入前ち◯こ見せつけ
- 正常位、騎乗位
- バック
- 横フェラ
- バック
- 後ろ騎乗位


- 【縦長】
- フェラ
- バック
- 寝バック

などなどです。

# 見出し


◆作品情報◆

人気Vtuberの星街す◯せいちゃんにガチ恋していた主人公が、す◯せいちゃんを触手の穴に落としたらどうなるか、観察してみたイラスト集です。
セリフはサンプル画像のみのため、本体にはありません。
イラストにすこしストーリー性があります。

◆この作品はこんな人におすすめ◆
・触手好きな人
・拘束好きな人
・Vtuberが好きな人
・パンチラ好きな人
・清楚なアイドルが触手と戯れるのを見ることが好きな紳士
・実用性（オ○ニー等）のある作品を探している人

◆表情◆
　・くっころ顔
　・泣き顔
　・一部アヘ顔

◆衣装◆
　・通常衣装 or 裸

◆シチュエーション◆

・パンチラ
・拘束正常位
・拘束騎乗位
・騎乗位（杭打ちピストン）
・フェラ
・拘束バック
・拘束寝バック
・屈服お◯んこ広げ中出し懇願
・屈服中出し痙攣

・提供方法
　・解像度 1280 * 1280
　・ファイル形式 , 高画質jpg , pdf
合計 148枚

---
・ 必要に応じてモザイク処理を施しています。
・ 登場する人物は全て20歳以上です。
・ すべての内容はフィクションであり、同人活動の範囲で作成しています。
・ 原作の設定、思想、経験、言動とは一切関係がありません。
・ この作品は全てAIを用いて作成しております。
・ 画像はStable Diffusionを使用して生成しております。
・ 本編にはセリフなどテキストは含まれません。
・ 技術的な制約やAIの学習データによって、細部に破綻や不自然さが含まれる場合があります。購入前に、そのことを理解し、同意した上で購入を検討していただくことをお願いいたします。



# 見出し3
早期購入特典

休日オナニー、手コキ

内容：
通常オナ
枕オナ
フィニッシュ
手コキ
パイズリ

※必要に応じてモザイク有り

となっています。


### patreon

画像の人物は20歳以上を想定して生成しております。もしくは人間では有りません。
この作品は全てAIを用いて作成しております。
画像はStable Diffusionを使用して生成しております。
技術的な制約やAIの学習データによって、細部に破綻や不自然さが含まれる場合があります。
イラストは他のサイトなどで販売のため転用する可能性があります。
上記に同意の上、閲覧ください。

The person in the image is created with the assumption that the person is 20 years old or older. Or rather, it's not human.
This work is entirely created using AI.
The images are generated using stable diffusion.
Due to technical issues and AI training data, there may be interruptions or artifacts in the details.\
Please agree to the above before viewing.


画像の人物は20歳以上を想定して生成しております。もしくは人間では有りません。この作品は全てAIを用いて作成しております。画像はStable Diffusionを使用して生成しております。技術的な制約やAIの学習データによって、細部に破綻や不自然さが含まれる場合があります。イラストは他のサイトなどで販売のため転用する可能性があります。上記に同意の上、閲覧ください。
The person in the image is created with the assumption that the person is 20 years old or older. Or rather, it's not human.This work is entirely created using AI.The images are generated using stable diffusion.Due to technical issues and AI training data, there may be interruptions or artifacts in the details.\Please agree to the above before viewing.

### テンプレ

---
続きはこちらで販売しています。 
会員登録不要で購入できますのでご検討ください。
2月末まで10%オフとなっています。
モザイクの量はトップの絵より相当薄くなっています。

他の商品も御覧ください。
https://0xffff.gumroad.com


---
枚数 196枚
提供方法 zip , pdf
モザイクの量はトップの絵より相当薄くなっています。
https://0xffff.gumroad.com/l/yadxv/g2s1q9u



---
こちらで続きを公開中です。
よろしければご覧ください。モザイクの量はこのイラストより大幅に薄くしています。

---
続きは下記サイトで販売しています。
サンプルイラストは各販売店を御覧ください。
価格は同じです。zipファイルが恒久的にダウンロードしたい方は、Gumroad版をおすすめします。
Booth : https://tanukimart.booth.pm/
Gumroad : https://0xffff.gumroad.com/




---
ご要望にお答えして、Gumroadでのサブスクを開設しました🪄
全部ではないですが、追加イラストがある場合があります。
しばらくトライアルで置いておきますので、よろしければご覧ください。
https://0xffff.gumroad.com/l/jczqdf

以下の店舗で様々なイラスト集を販売中です。よろしければご覧ください。
Booth : https://tanukimart.booth.pm/
Gumroad : https://0xffff.gumroad.com/
その他リンク集：https://potofu.me/0xffff



---
Gumroadでサブスクやってます。投げ銭代わりにご利用ください。
試作や先行公開など行っています。詳しくはお品書きをご覧ください。
https://0xffff.gumroad.com/l/jczqdf

以下の店舗で様々なイラスト集を販売中です。よろしければご覧ください。
Booth : https://tanukimart.booth.pm/
Gumroad : https://0xffff.gumroad.com/
その他リンク集：https://potofu.me/0xffff