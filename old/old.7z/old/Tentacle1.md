 illustration  ,  (Top Quality, 8k:1.1), (Sharp Focus:1.2), (perfect anatomy:1.2) BREAK
1girl,  solo , <lora:hoshimachi_suisei_v1:0.8:lbw=OUTD> sui1, 1girl, solo, side ponytail, hoshimachi suisei, fingerless gloves, single thighhigh, jewelry, single sock, thigh strap, bracelet, blue socks, buttons, single kneehigh, plaid dress, blue choker, blue belt, plaid skirt, mini crown, grey skirt, blue ascot, long sleeves, plaid jacket BREAK
{ panicking,  surprised |   frown  | 3::scared, cry  } ,  tearing up ,  BREAK 
in cave , on floor , (many many oily tentacles:1.2), (mucus:1.2), (tentacle swarm:1.2), spread legs, (tentacle wraps around arms:1.1), (tentacle wraps around legs:1.1), (tentacle wraps around breasts:1.1), (tentacle wraps around waist:1.1), sobbing, perfect anatomy, dynamic pose,  
{ from above | from below | front }  ,  __nsp/my/new_panties__ , __nsp/my/panties__ ,   <lora:horo_tentacle:1:lbw=OUTD> , wet clothes,  <lora:against_glass_v0.2:1> 

shiny hair,  shiny skin, masterpiece,  best quality,  (perfect anatomy:1.2) ,  detail eyes , focus eyes break
1girl,  solo ,<lora:suisei1:1> suiseidef ,  { sweat  |  2::torn clothes,  torn skirt,  torn jacket ,  plaid skirt, mini crown, grey skirt, blue ascot, long sleeves, plaid jacket , nipples  | naked , (nude:1.2)  } BREAK  


illustration  ,  (Top Quality, 8k:1.1), (Sharp Focus:1.2), (perfect anatomy:1.2) BREAK
1girl,  solo , <lora:hoshimachi_suisei_v1:0.8:lbw=OUTD> sui1, 1girl, solo, side ponytail, hoshimachi suisei, fingerless gloves, single thighhigh, jewelry, single sock, thigh strap, bracelet, blue socks, buttons, single kneehigh, plaid dress, blue choker, blue belt, plaid skirt, mini crown, grey skirt, blue ascot, long sleeves, plaid jacket , { sweat | 2:: (torn clothes,  torn legwear,  torn shirt,  torn skirt:1.4) }   BREAK
{panicking,  surprised |  frown   | scared, cry , tearing up,  teardrop,  streaming tears  } ,  sweat , (shouting:1.2), (many many oily tentacles:1.2), (mucus:1.2), wet clothes,  <lora:against_glass_v0.2:1:lbw=MIDD> , hands on glass ,  window fog , knee on glass



# 基本

## 前座

### パンチラ

#### たくし上げ
{ frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth |  3::disgust , sweat,  }  BREAK
(__nsp/my/new_panties__ , __nsp/my/panties__:1.2) , {sitting , wariza | sitting  } ,  detail panties { front | from above } , bottomless ,  skirt , (skirt lift,  lifted by self:1.3) , looking at viewer , water surface , 

#### 膝抱え
(__nsp/my/new_panties__ , __nsp/my/panties__:1.2) ,  ( knees together , legs closed:1.3) , (front:1.2), { <lora:hugging_own_legs_v0.3:1> hugging own legs | squatting } , (looking at another,  looking away:1.3),

#### 立膝
{ frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat,   }  ,  { open mouth | 1.5::closed mouth }   , (heavy breathing:1.2),  <lora:tentacles_v0.4:0.8:lbw=MIDD> , (many many oily tentacles:1.2) , <lora:kneestogetherfeetapart:0.7:lbw=MIDD> , knees together feet apart, sitting, panties , __nsp/my/panties__ ,  pantyshot


## ランダム
{ { 2::frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat,   }  , dynamic pose, frown , disgust , looking at another , looking to the side,     tentacles, tentacles pit , (many many oily tentacles:1.2), (mucus:1.2), <lora:tentacles_v0.4:0.7:lbw=MIDD> , (panties:1.1) , {  leaning forward , doggystyle,  | sitting | 1.5::wariza  } , ? , { spoken question mark | spoken ellipsis }    (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , <lora:tentacles_v0.4:0.6:lbw=MIDD>  , { front | from behind }  | 
{ frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat,   }  ,  { open mouth | 1.5::closed mouth }   , (heavy breathing:1.2),  <lora:tentacles_v0.4:0.8:lbw=MIDD> , (many many oily tentacles:1.2) , tentacles on arms ,   (mucus:1.2), (__nsp/my/panties__:1.2) , __nsp/my/new_panties__ , { {front | cowboy shot }, ( knees together , legs closed:1.3) , (front:1.2), pov , {  sitting ,  { wariza | 2::spread legs ,  (tentacles restraint legs:1.2) | 2::hands on floor } } } ,  tentacles,  tentacle pit , { water surface |  tentacle pit  }  , { looking at viewer | looking to the side | face down }  |
{ frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat,   } , tentacles , tentacle pit , restrained , tentacles ,  { open mouth | 2::closed mouth } , <lora:tentacles_v0.4:1>  , (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , tearing up ,   standing  , (spread legs:1.3),  (focus crotch:1.2)   , narrow waist ,  (Directly below:1.3) , (from below:1.2) ,  bottomless , (skirt lift,  lifted by self:1.1) , looking at viewer ,  embarrassed,  upper body,  (headless , body only:1.2) , dynamic pose } 

## エロ顔
{  (embarrassed,blush:1.3) , light smile , open mouth  |  nsfw,(ecstasy:1.3) ,(slut:1.2),(vulgarity:1.3),(fucked silly:1.1),(steam:1.1),(wet:0.8),(trembling:0.8),(tears:0.7) ,(sweat:0.8), wince , female orgasm,  heavy breathing, light smile | (embarrassed,blush:1.3), (steam:0.8),(wet:0.8),(sweat:0.8),(trembling:1.3) , (parted lips:1.3),(harf open eyes:1.4),(feeling weak:1.5) , open mouth  | (embarrassed,blush:1.3), ,(steam:0.8),(wet:0.8),(sweat:0.8),(trembling:1.3) ,(parted lips:1.3),(harf open eyes:1.4),(feeling weak:1.5) , open mouth } BREAK
(tentacle pit:1.1) , tentacles , tentacle nest ,tentacles , tentacle pit , tentacles , <lora:tentacles_v0.4:0.75>   BREAK

## エロ顔
{  (embarrassed,blush:1.3), (steam:0.8),(wet:0.8),(sweat:0.8),(trembling:1.3) , (parted lips:1.3),(harf open eyes:1.4),(feeling weak:1.5) , open mouth  | (embarrassed,blush:1.3), ,(steam:0.8),(wet:0.8),(sweat:0.8),(trembling:1.3) ,(parted lips:1.3),(harf open eyes:1.4),(feeling weak:1.5) , open mouth } BREAK
(tentacle pit:1.1) , tentacles , tentacle nest ,tentacles , tentacle pit , tentacles , <lora:tentacles_v0.4:0.75>   BREAK



## pile2

in tentacle pit , tentacles , tentacle nest , open clothes,  { (__nsp/my/new_bra__ , __nsp/my/bra__:1.2) | (nipples  , nsfw:1.2) } ,{ 1.2::frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat, tearing up,  streaming tears  | 1.5::female orgasm, (ecstasy:1.2),  open clothes,    (heavy breathing:1.2) , cum in pussy , cum ,   , ahegao,  } ,  tentacles , tentacle pit , restrained , tentacles , <lora:tentacles_v0.4:0.95> BREAK

 {  (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) ,   { standing  |  lying ,  spread legs ,  ass  } ,  nsfw , vaginal , vore , being swalloed, restrained , bound wrists , __nsp/my/angle__ ,{arms up | hands on own chest  |  breasts squeezed together }   |  straddling , cowgirl position, from below,  ceiling  ,  { sweat | hands on own chest  |  breasts squeezed together } missionary, vaginal, pov ,  1boy,  spread legs , {  <lora:multiple_insertions_v0.2:0.75:lbw=MIDD> , multiple insertion | 1.5::(tentacles in pussy:1.2)  |  <lora:large_insertion_v0.1:0.75:lbw=MIDD> large insertion }  }
 | 
{ 1.2:: all fours,  { front  |  3::ass ,   from behind } , pussy in tentacles,  mouth in tentacles, fellatio,  {  lora:multiple_insertions_v0.2:0.75:lbw=MIDD> , multiple insertion | sweat | <lora:large_insertion_v0.1:0.75:lbw=MIDD> large insertion } } 
|
{ 1.5::{ all fours,  doggystyle , on stomach,  {  cowboy shot , front  | 3::from behind ,ass focus } , (tentacles in pussy:1.1) , (many many oily tentacles:1.2), (mucus:1.2), (tentacle wraps around arms:1.1) ,  (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1)  , (restrained:1.2) ,  water surface , { multiple views,  { uterus,  pussy | front } |  sweat, } } 
| 
{ 0.3:: { fellatio ,  tentacles fellatio}  , tentacles in mouth , facial ,  cum in mouth ,  <lora:tentacles_v0.4:0.8:lbw=MIDD> , tentacles,  { from side |  pov  } ,  (restrained:1.4)  , (many many oily tentacles:1.2), (mucus:1.2)   } 
| 
{ 0.8::looking at viewer,  { wariza | standing | spread legs , focus crotch  }  ,  empty eyes,  heart-shaped pupils,  spoken heart,  <lora:tentacles_v0.4:0.95:lbw=MIDD> , tentacles,  { from side |  pov  } ,  (restrained:1.4)  , (many many oily tentacles:1.2), (mucus:1.2)  , multiple views, front , ass , bukkake, <lora:bukkake_v0.4:0.7> } 
|
{ 1.2::looking at viewer, spread legs,   empty eyes,  heart-shaped pupils,  spoken heart,  <lora:tentacles_v0.4:0.95:lbw=MIDD> , tentacles,  front  , (many many oily tentacles:1.2), (mucus:1.2) ,  <lora:cervix:1:lbw=MIDD> , cervix ,  clitoris , urethra , cum in pussy , cum explosion } } 

# ガラス窓

<!-- { frown | scared, cry , tearing up,  teardrop,  streaming tears |   (sexual ecstasy:1.3), orgasm ,  open eyes , in heat , seductive smile  } ,  sweat , (many many oily tentacles:1.2), (mucus:1.2), wet clothes,  <lora:against_glass_v0.2:1:lbw=MIDD> , (hands on glass:1.2) , heavy breathing ,  { 2::sitting,  wariza | standing } , <lora:tentacles_v0.4:0.7:lbw=MIDD> , tentacles , tentacles pit , creature's nest ,  -->


## 目覚め * 10
 <!-- lying,  on  floor , sleeping, { closed eyes |  half-closed eyes } ,  full body,  (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , <lora:tentacles_v0.4:0.6:lbw=MIDD> , (many many oily tentacles:1.2), (mucus:1.2), (__nsp/my/panties__:1.2) , __nsp/my/new_panties__ , focus panties , detail panties , { closed eyes | one eye closed } ,   on tentacles pit , {  sleep on back  | sleep on  stomach | Lying down } , close mouse ,  water surface -->

## 正面

{ 2::frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat,   }  , dynamic pose, frown , disgust , looking at another , looking to the side,     tentacles, tentacles pit , (many many oily tentacles:1.2), (mucus:1.2), <lora:tentacles_v0.4:0.7:lbw=MIDD> , (panties:1.2) , ? ,  (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , <lora:tentacles_v0.4:0.6:lbw=MIDD>   ,  down blouse,  prone bone,  bottom up , doggystyle,  all fours  , { front | 2::(from behind , panties:1.2) }  , (open mouth:1.2)

## 胸隠し * 1 * 3

 { frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat,   } , <lora:covering_breasts_v0.1:1> ,  { open mouth | 2::closed mouth }, covering crotch , covering breasts  , { standing , upper body , bottomless  | sitting , wariza  }, open mouth, { front | from above } , , tentacles,  in tentacles pit , (many many oily tentacles:1.2), (mucus:1.2), <lora:tentacles_v0.4:0.4:lbw=MIDD> , __nsp/my/angle__ ,{  water surface | on ground }  , (open mouth:1.2)

# 後ろマルチビュー

{ 2::frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat,   }  , dynamic pose, frown , disgust , looking at another , looking to the side,     tentacles, tentacles pit , (many many oily tentacles:1.2), (mucus:1.2), <lora:tentacles_v0.4:0.7:lbw=MIDD> , (panties:1.1) , {  leaning forward , doggystyle,  | sitting | 1.5::wariza  } , ? , { spoken question mark | spoken ellipsis }    (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , <lora:tentacles_v0.4:0.6:lbw=MIDD>  , { front | from behind }  , (open mouth:1.2)


## 2
{ 2::frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat,   }  , dynamic pose, frown , disgust , looking at another , looking to the side,     tentacles, tentacles pit , (many many oily tentacles:1.2), (mucus:1.2), <lora:tentacles_v0.4:0.7:lbw=MIDD> , (panties:1.2) , { (ass:1.3) , all fours,  doggystyle,  } , ? , { spoken question mark | spoken ellipsis }    (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , <lora:tentacles_v0.4:0.6:lbw=MIDD>  , from behind , { multiple views,  face | sweat } 


# 座り膝抱え * 1 * 3
<!-- 
 { frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat,   } ,  (__nsp/my/panties__:1.2) , __nsp/my/new_panties__ , focus panties , detail panties , looking at another,  looking to the side,   ( knees together , legs closed:1.3) , (front:1.2), { <lora:hugging_own_legs_v0.3:1> hugging own legs | squatting} , tentacles,  in tentacles pit , (many many oily tentacles:1.2), (mucus:1.2), <lora:tentacles_v0.4:0.4:lbw=MIDD> , __nsp/my/angle__ , { water surface  | on ground }  -->

## 座りパンチラ * 2 * 6

{ frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat,   }  ,  { open mouth | 1.5::closed mouth }   , (heavy breathing:1.2),  <lora:tentacles_v0.4:0.8:lbw=MIDD> , (many many oily tentacles:1.2) , tentacles on arms ,   (mucus:1.2), (__nsp/my/panties__:1.2) , __nsp/my/new_panties__ , ( knees together , legs closed:1.3) , (front:1.2), pov , {  sitting ,  { wariza | 2::spread legs , (front:1.2) ,   (tentacles restraint legs:1.2) | 1.2::hands on floor } }  ,  tentacles,  tentacle pit , { water surface |  tentacle pit  }  , { looking at viewer | looking to the side | face down } , legs around tentacles  , (open mouth:1.2)

<!-- 
## 釣られる * 1 * 3
 
 { frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat,   } , { open mouth | 2::closed mouth },  {from below , (panties:1.2) | from above }  , (tentacle wraps around arms:1.1) ,  (tentacles wraps around legs:1.1) , suspended from tentacles ,  tearing up ,tentacle-pit  ,tentacles, (many many oily tentacles:1.2), (mucus:1.2), <lora:tentacles_v0.4:0.8:lbw=MIDD> ,   sky , stretching arms , stretching legs , floating in the air , floating body , floating,    -->

## 下から見る * 1 * 3
 { frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat,   } , tentacles , tentacle pit , restrained , tentacles ,  { open mouth | 2::closed mouth } , <lora:tentacles_v0.4:1>  , (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , tearing up ,   standing  , (spread legs:1.3),  (focus crotch:1.2)   , narrow waist ,  (Directly below:1.3) , (from below:1.2) ,  bottomless , (skirt lift,  lifted by self:1.1) , looking at viewer ,  embarrassed,  upper body,  (headless , body only:1.2) , dynamic pose, (pussy:1.2)  

<!-- 
## 拘束 * 10
 { panicking,  surprised | female orgasm, (ecstasy:1.2),   ,  tearing up,  open clothes,  ,  (heavy breathing:1.2)  } , tentacles , tentacle pit , restrained , tentacles , open mouth,   ,  , <lora:tentacles_v0.4:1>  , (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , sobbing,  { standing  |  lying ,  spread legs ,  ass  } ,  nsfw , vaginal , vore , being swalloed, restrained , bound wrists , __nsp/my/angle__ , { sweat | 2:: <lora:projectile_cum_v0.2:1>  , projectile cum  , bukkake,  cum in pussy,  cum on body,  facial,  cum on breasts,  }  -->

## 正常位 , 騎乗位 * 2 * 4
 <!-- {  { frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat,   } | female orgasm, (ecstasy:1.2),   ,  tearing up,  open clothes,  ,  (heavy breathing:1.2)  } , tentacles , tentacle pit , restrained , tentacles , open mouth,   ,  , <lora:tentacles_v0.4:1>  , (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , sobbing,  { standing  |  lying ,  spread legs ,  ass  } ,  nsfw , vaginal , vore , being swalloed, restrained , bound wrists , __nsp/my/angle__ ,{arms up | hands on own chest  |  breasts squeezed together }   |  straddling , cowgirl position, from below,  ceiling  ,  { sweat | hands on own chest  |  breasts squeezed together } missionary, vaginal, pov ,  1boy,  spread legs , { multiple insertion | large insertion | shiny hair }  ,{  <lora:multiple_insertions_v0.2:0.75:lbw=MIDD> , multiple insertion | sweat | <lora:large_insertion_v0.1:0.75:lbw=MIDD> large insertion } -->
 
## 四つん這い
 <!-- {  { frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat,   } | female orgasm, (ecstasy:1.2),   ,  tearing up,  open clothes,  ,  (heavy breathing:1.2)  }  , tentacles , tentacle pit , restrained , tentacles , open mouth,   ,  , <lora:tentacles_v0.4:1>  ,  sobbing,  all fours,  { front  |  3::ass ,   from behind } , pussy in tentacles,  mouth in tentacles, fellatio,  {  <lora:multiple_insertions_v0.2:0.75:lbw=MIDD> , multiple insertion | sweat | <lora:large_insertion_v0.1:0.75:lbw=MIDD> large insertion } -->


 ## テンプレ 2 * 6
 <!-- (restrained:1.2) , { 1.5::frown , one eye closed  |  1.5::open mouth,   ,   ,  { sweat |  1.2::(empty eyes:1.2) } | (sexual ecstasy:1.3), orgasm ,  open eyes , in heat , seductive smile } ,  (heavy breathing:1.2) BREAK sobbing, <lora:tentacles_v0.4:1> , (many many oily tentacles:1.2), (mucus:1.2), (tentacle wraps around arms:1.1) ,  (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , sobbing ,  { all fours,  doggystyle , { from behind | front }  |  spread legs , { front | from from above } | cowgirl position , squatting |  lying , missionary | 2::dynamic pose } BREAK{  { tentacles in vaginal  | 2::<lora:multiple_insertions_v0.2:0.7>  multiple insertions |  tentacles in vaginal ,  <lora:large_insertion_v0.1:0.7> large insertion } , {  pussy juice | 2::pussy  juice , (cum in pussy , after vaginal,  cum explosion:1.2) } , (trembling:1.3) } , __nsp/my/angle__ ,  water surface -->

## 後ろから * 1 * 3
<!-- {  { frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat,   } |  open mouth,   ,   | (sexual ecstasy:1.3), orgasm ,  open eyes , in heat } ,  (heavy breathing:1.2)  ,  empty eyes,  sobbing, <lora:tentacles_v0.4:0.8:lbw=MIDD> ,  tentacles ,  all fours,  doggystyle , on stomach,  {  cowboy shot , front  | 3::from behind ,ass focus } , tentacles in vaginal  , (many many oily tentacles:1.2), (mucus:1.2), (tentacle wraps around arms:1.1) ,  (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1)  , (restrained:1.2) ,  water surface , { multiple views,  { uterus,  pussy | front } |  sweat, } -->

## フェラ * 1 * 3
<!-- (sexual ecstasy:1.3), open mouth , tearing up,  ,  (heavy breathing:1.2)  ,  { fellatio ,  tentacles fellatio}  , tentacles in mouth , , facial ,  cum in mouth ,  <lora:tentacles_v0.4:0.8:lbw=MIDD> , tentacles,  { from side |  pov  } ,  (restrained:1.4)  , (many many oily tentacles:1.2), (mucus:1.2)  -->

## 完落ち * 1 * 3
<!-- (sexual ecstasy:1.3), open mouth , { tearing up | sweat } , sweat,  (heavy breathing:1.2)  , { smile | frown | one eye closed }  , looking at viewer,  { wariza | standing | spread legs , focus crotch  }  ,  empty eyes,  heart-shaped pupils,  spoken heart,  <lora:tentacles_v0.4:0.8:lbw=MIDD> , tentacles,  { from side |  pov  } ,  (restrained:1.4)  , (many many oily tentacles:1.2), (mucus:1.2)  , multiple views, front , ass , bukkake, <lora:bukkake_v0.4:0.7> -->

## 中出し * 1 * 3
<!-- (sexual ecstasy:1.3), open mouth ,{ tearing up | sweat } , sweat,  (heavy breathing:1.2)  , { smile | frown | one eye closed }  , looking at viewer, spread legs,   empty eyes,  heart-shaped pupils,  spoken heart,  <lora:tentacles_v0.4:0.8:lbw=MIDD> , tentacles,  front  , (many many oily tentacles:1.2), (mucus:1.2) ,  <lora:cervix:1:lbw=MIDD> , cervix ,  clitoris , urethra , cum in pussy , cum explosion,   -->



# 横向き

## Pile
  { frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat  | female orgasm, (ecstasy:1.2),   ,  tearing up,  open clothes,  ,  (heavy breathing:1.2)  } , tentacles , tentacle pit , restrained , tentacles , open mouth,   ,  , <lora:tentacles_v0.4:1>  , (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , sobbing,   ass, doggystyle, sex, all fours, standing sex, torso grab, top-down bottom-up,{ open eyes ,  open mouth,  one eye closed,   cum in pussy  ,( trembling:1.4) | frown , clenched teeth , tearing up , one eye closed , (motion lines:1.2),  } , looking at another , looking to the side,  { 2::sweat |   multiple views }  
  { frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat  | female orgasm, (ecstasy:1.2),   ,  tearing up,  open clothes,  ,  (heavy breathing:1.2)  } , tentacles , tentacle pit , restrained , tentacles , open mouth,   ,  , <lora:tentacles_v0.4:1>  , (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , sobbing,   spread legs,  sex , tentacles,  in pussy , (front:1.3) ,  { multiple views  { ass | face }   | 1.5::sweat }  
  { frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat  | female orgasm, (ecstasy:1.2),   ,  tearing up,  open clothes,  ,  (heavy breathing:1.2)  } , tentacles , tentacle pit , restrained , tentacles , open mouth,   ,  , <lora:tentacles_v0.4:1>  , (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , sobbing,   spread legs,  sex , tentacles,  in pussy , (front:1.3) ,  { multiple views  { ass | face }   | 1.5::sweat }  
  { frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat  | female orgasm, (ecstasy:1.2),   ,  tearing up,  open clothes,  ,  (heavy breathing:1.2)  } , tentacles , tentacle pit , restrained , tentacles , open mouth,   ,  , <lora:tentacles_v0.4:1>  , (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , sobbing,   spread legs,  sex , tentacles,  in pussy , { straddling | lying } , __nsp/my/angle__ ,  looking at viewer,  sweat, nose blush,  {  multiple views, { all fours,  doggystyle | prone bone , flat chest   | face  }  | 2::sweat } 


## 寝バック
  { frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat  | female orgasm, (ecstasy:1.2),   ,  tearing up,  open clothes,  ,  (heavy breathing:1.2)  } , tentacles , tentacle pit , restrained , tentacles , open mouth,   ,  , <lora:tentacles_v0.4:1>  , (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , sobbing,   ass, doggystyle, sex, all fours, standing sex, torso grab, top-down bottom-up,{ open eyes ,  open mouth,  one eye closed,   cum in pussy  ,( trembling:1.4) | frown , clenched teeth , tearing up , one eye closed , (motion lines:1.2),  } , looking at another , looking to the side,  { 2::sweat |   multiple views }  

## 足広げ

  { frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat  | female orgasm, (ecstasy:1.2),   ,  tearing up,  open clothes,  ,  (heavy breathing:1.2)  } , tentacles , tentacle pit , restrained , tentacles , open mouth,   ,  , <lora:tentacles_v0.4:1>  , (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , sobbing,   spread legs,  sex , tentacles,  in pussy , (front:1.3) ,  { multiple views  { ass | face }   | 1.5::sweat }  

## 正常位色々

  { frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat  | female orgasm, (ecstasy:1.2),   ,  tearing up,  open clothes,  ,  (heavy breathing:1.2)  } , tentacles , tentacle pit , restrained , tentacles , open mouth,   ,  , <lora:tentacles_v0.4:1>  , (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , sobbing,   spread legs,  sex , tentacles,  in pussy , { straddling | lying } , __nsp/my/angle__ ,  looking at viewer,  sweat, nose blush,  {  multiple views, { all fours,  doggystyle | prone bone , flat chest   | face  }  | 2::sweat } 

## 横色々
  { frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat  | female orgasm, (ecstasy:1.2),   ,  tearing up,  open clothes,  ,  (heavy breathing:1.2)  } , tentacles , tentacle pit , restrained , tentacles , open mouth,   ,  , <lora:tentacles_v0.4:1>  , (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , sobbing,   prone bone,  ass, lying, sex from behind, pillow, prone bone,  lying, (sex from behind:1.3), (sex:1.3), looking at viewer, legs together, (motion blur), (motion line), flat chest, (petite female body),  from side , { open eyes ,  open mouth,  one eye closed,   cum in pussy  ,( trembling:1.4) | frown , clenched teeth , tearing up , one eye closed , (motion lines:1.5),  } ,  looking at viewer,  sweat, nose blush,  multiple views, { from behind , pussy in tentacles  | face | front , focus pussy | from above , cowboy shot , wariza } 
  




# リアル万
<!-- { lying | sitting }  ,   heavy breathing,   spread legs , bottomless, , focus vaginal , detail vaginal , heavy breathing, open mouth, nose blush , panicking ,  pussy juice, cum in pussy, cum explosion, (trembling:1.4), (facial, bukkake, cum on body:1.3) , after vaginal, after sex, in classroom , fluorescent light ,  open mouth,   , closed mouth,  , (empty eyes:1.2),  (face down , looking at another:1.2),  in warehouse,  open clothes,  bra  <lora:newb_0.1:0.6> , perfect vaginal ,  focus crotch ,  open clothes,  nipples,  nsfw  , front , focus crotch ,( focus pussy:1.2) , { arms behind back | arms behind head  | hands on nipples }  , (trembling:1.4),  -->

## 終わり

empty eyes,  bukkake,  open mouth , ,  ,   lying , { cry  | frown }  , tearing up  , streaming tears,    tentacle-pit , tentacle-pit,tentacles,  in tentacles pit , (many many oily tentacles:1.2), (mucus:1.2), { spread legs | bukkake } ,  cum on body,  cum in pussy,  facial,  cum on breasts, after pussy ,  <lora:tentacles_v0.4:0.8:lbw=MIDD> , __nsp/my/angle__ ,  <lora:bukkake_v0.4:0.75:lbw=MIDD>

## 終わり 2 * 2
streaming tears,  tearing up,  open mouth,  after sex,  orgasm,  female orgasm,  <lora:aftersex:0.7:lbw=MIDD> , after sex, cum, lying, cumdrip, ass, on stomach, on back, fucked silly, sweat, cum pool, bukkake, trembling , { pillow hug | sheets grab } 

## 終わり2
streaming tears,  tearing up,  open mouth,  after sex,  orgasm,  female orgasm,  sitting , on couch  ,  spread legs,  empty eyes,  looking at another,  looking to the side,  after sex, cum,  cumdrip, fucked silly, sweat, cum pool, bukkake, trembling , { pillow hug | sheets grab } , hands on pussy,  hands on vaginal , 

## 救出　保護

empty eyes, cry , sad  ,  (heavy breathing:1.2)  , tearing up,  streaming tears, { pregnancy |   after sex,  cum in vaginal } , { sitting , on couch | lying }  , indoors , on bed , open mouth  , face down , looking at down , scared, 

## タイトル
{ sad , cry}  , (heavy breathing:1.2)  , tearing up,  streaming tears, <lora:tentacles_v0.4:0.8:lbw=MIDD> , (many many oily tentacles:1.2), (mucus:1.2), (__nsp/my/panties__:1.2) , __nsp/my/new_panties__ , focus panties , detail panties , { 2::{front | cowboy shot }, ( knees together , legs closed:1.3) , (front:1.2), pov , {  sitting ,spread legs |   { <lora:hugging_own_legs_v0.3:1> hugging own legs | 2::hands on floor } } },  water surface , { looking at viewer | looking to the side | face down } 



## 全体

  { panicking,  surprised  ,  __nsp/my/tear__ |   frown  , __nsp/my/tear__  | scared, cry , __nsp/my/tear__ | 6:: (sexual ecstasy:1.3), orgasm, in heat,  heart-shaped pupils, (trembling:1.4), open mouth , pussy juice , fucked silly , heavy breathing ,  } BREAK 
in cave , <lora:tpit:1.2> , tpit , tentacle pit  , (restrained, cum, tentacles, tentacle pit:1.3)  , sweat ,  vaginal,  pussy , tentacles fellatio , pussy in tentacles ,  (focus crotch:1.4) ,  narrow waist ,  looking at down ,  cum on body,  facial,  cum on breasts, { pussy in vaginal  | <lora:multiple_insertions_v0.2:1> multiple insertions |  <lora:large_insertion_v0.1:1> | <lora:multiple_insertions_v0.2:1> multiple insertions  , <lora:large_insertion_v0.1:1> } , __nsp/my/angle__ 

(restrained:1.4) , panicking,  surprised , open mouth,  (heavy breathing:1.2)  , tearing up,  streaming tears , teardrop , empty eyes,  sobbing, <lora:tentacles_v0.4:0.8> , (many many oily tentacles:1.2), (mucus:1.2), (tentacle wraps around arms:1.1) ,  (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , sitting ,  spread legs, pussy vaginal  , front , pov , 


##フェラ

in cave , <lora:tpit:1.2> , tpit , tentacle pit  , (restrained, cum, tentacles, tentacle pit:1.3)  ,  upper body ,    <lora:projectile_cum_v0.2:1> ,  projectile cum , bukkake , excessive cum, after fellatio , cum in mouth ,  
tentacles in mouth,  (mouth in tentacles:1.2) ,  (restrained:1.2),   { from side  | from above } 


星街すいせい。目が覚めたようだな。
私は君の事を知っている。
君の部屋には触手の生物が蔓延っている。このテープの後、一斉に触手が襲いかかるだろう。
部屋から出る方法は１つ。触手の攻めに耐えきり快楽堕ちしないことだ。
選択は君次第だ。ゲームを始めよう。


## テンプレ

illustration  , focus eyes , ultra detail eyes ,   (Top Quality, 8k:1.1), (Sharp Focus:1.2), (perfect anatomy:1.2) BREAK
1girl,  solo ,
[X] BREAK
[Y] BREAK


 sleep on back , in hotel ,   on bed , closed eyes , bra ,   <lora:sukebra(bsb&fsb):1> , fsb , frosuke ,  lying,  on  floor , sleeping, { closed eyes |  half-closed eyes } , upper body, 
