# 導入

 {  sweat | breasts squeezed together |  grabbing breasts } ,  { white | light bloue | light pink  panties  } , nipples,  open clothes,  sitting , on bed , { sweat | spread legs | (knees apart feet together:1) } , open mouth ,  { 1-2$$heavy breathing | embarrassed | spoken heart | spoken musical note |  (light smile,  head tilt:1.2) } 

  nipples, all fours,  doggystyle,  heavy breathing,  open mouth,  { 1-2$$ heavy breathing | embarrassed | spoken heart | spoken musical note |  (light smile,  head tilt:1.2) }  , from below , on bed, 

# フェラ型総合
1boy , penis , { licking penis | penis grab | fellatio | irrumatio | deepthroat  } ,  { sweat | orgasm drooling } ,  { from side , looking up , kneeing    | 4::pov }   , { sweat | 0.75::head grab }    , looking at viewer,   { heavy breathing | orgasm | embarrassed | sweat | spoken heart  }   , {  cum in mouth , facial , cum on body  |  2::sweat } 

# 射精
1boy ,   mouth in penis ,  (irrumatio:1.3)  , fellatio,  mouth in penis , penis , in mouth , open mouth,  tearing up ,   , pov , on bed, doggystyle,  all fours,  from above  ,  , close-up , face 

# ごっくん
 { 2::sweat |  1boy , penis , penis grab } , (motion lines:1.4),   kneeing, , front ,   open mouth , cum in mouth , cum in throat,  cum in throat,  drooling,  light smile, { sweat  , heavy breathing,  light smile | 0.3::heart-shaped pupils,  spoken heart,  orgasm } , { heavy breathing | (head tilt:1.2)} 

# ごっくん2
(motion lines:1.4),   kneeing, , front ,   open mouth , cum in mouth , cum in throat,  cum in throat,  drooling,  light smile, { sweat  , heavy breathing,  light smile | 0.3::heart-shaped pupils,  spoken heart,  orgasm } , { heavy breathing | (head tilt:1.2)} 

# オナ
sitting , on white couch , masturbation,   spread legs ,   grabbing  breasts ,   sweat,  embarrassed, heavy breathing,  {  open mouth , drooling | 0.3::clenched teeth one eye closed , trembling  | 0.3::ahegao,  open mouth,  drooling }  pussy juice,   female orgasm,  __nsp/my/angle__ , heavy reathing, 

# くぱぁ
 nude , naked,  spread pussy , pussy juice,   sitting , on white couch , { 2::sweat |   grabbing  breasts }   sweat,  embarrassed, heavy breathing,  {  open mouth , drooling | 0.3::clenched teeth one eye closed , trembling  | 0.3::ahegao,  open mouth,  drooling }  pussy juice,   female orgasm,  { front | from below } , heavy reathing,  tearing up, cervix,  <lora:cervix_Pony_V1.0:1>  spread pussy, cervix , cervix prolapse, ( spoken x-ray  cum  in uterus:1.2)

# こすりつけ
open mouth, grabbing penis ,   orgasm,  drooling,  looking at viewer,  heavy breathing,    lying , on bed ,  holding own legs  , { sweat | drooling | trembling } ,

# お尻突き出し
<lora:Pov_Standing_Doggy_Style__Missionary_looking_up:1> Pov Standing Doggy Style, curving back towards viewer , (trembling,  motion lines:1.2),  (holding arms:1.2) ,  mouth open  , (from behind:1.3) , orgasm,  heavy breathing,  open mouth,  cum in pussy,  orgasm,  (drooling,  trembling:1.2), 

# 胸隠し
 standing , { embarrassed | nose blush } , { 2::full body | upper body } , { covering breasts | covering crotch | breasts squeezed together,  } , looking away , in hotel , { frown | tearing up | disgust }  , { open mouth,  |clenched teeth | close mouth } , pussy , 

# フェラ
1boy ,   mouth in penis ,  (irrumatio:1.3)  , fellatio,  mouth in penis , penis , in mouth , open mouth,  tearing up ,   , pov , on bed, doggystyle,  all fours,  from above  ,  , close-up , face 

# 強制フェラ
head grabbing  , { fellatio |  2::irrumatio , deepthroat }  , {  (surprised:1.3) | crying , streaming tears,  frown  } ,  look up,  tearing up,  drooling,  { open eyes | one eye closed } , heavy breathing  , motion lines, trembling,  penis ,  from side , , kneeing, 

## 背面座位
1boy , faceless male,  ,( reverse upright straddle:1.3), penis ,  sex  , ecstasy,  orgasm,   holding legs  ,  grabbing from behind,  heavy breathing,  tearing up,  (ecstasy:1.4) , (covering crotch:1.1),  <lora:jyojishitagi_Pony_V1.0:1>jyojipan,bra ,underwear,  lift bra , nipples, 

## 正常位
missionary,  sex , pov ,   { holding legs | torso grab | holding hands | holding arms } ,   {arms up |   breasts squeezed together |  __nsp/myNSFW/commonArm__ } ,   motion lines  , trembling,  { 1-3$$orgasm | sweat |  heavy breathing | head tilt |  one eye closed | frown |  trembling | spoken heart | heart-shaped pupils }  , open mouth,  close-up pussy , 

## ガラス越し
  sex from behind , standing doggy  , doggystyle,  sex , Against glass sex , against glass, front,  sex from behind, 1boy,  motion lines  , trembling,  { 1-3$$orgasm | sweat |  heavy breathing | head tilt |  one eye closed | frown |  trembling | spoken heart | heart-shaped pupils }  , open mouth,  , ahegao , trembling,  female orgasm,  drooling,  hands on glass , breasts on glass , (multiple views,  uterus in pussy , uterus in penis , front :1.3) 

## 立ちバック
<lora:Pov_Standing_Doggy_Style__Missionary_looking_up:1> Pov Standing Doggy Style, curving back towards viewer , holding arms ,  mouth open


## 騎乗位
{ cowgirl position |  1.5::reverse cowgirl position , from behind ,  torso grab  | squatting cowgirl position | straddling | upright straddle | 1.5::reverse upright straddle , from behind , torso grab }  ,  sex ,   motion lines  , trembling,  { 1-3$$orgasm | sweat |  heavy breathing | head tilt |  one eye closed | frown |  trembling | spoken heart | heart-shaped pupils }  , { sweat , orgasm, female orgasm  |  drooling,  embarrassed,  heavy breathing,  open mouth } , { 1.2::open eyes | one eye closed }   close-up pussy  , pussy juice  , cum explosion,  cum in pussy,   { sweat |  (x-ray,  uterus:1.2) , { light smile , open mouth |  surprise }  } , 

## パイズリ
  { 2::from side | pov }  ,  kneeing, , look up , paizuri , penis , { heavy breathing | orgasm | embarrassed | sweat | spoken heart  }  , open mouth,  heavy breathing, 

## お風呂
<lora:mixed_bathing_from_behind_pony_v01a:1.2> { 5::mixed bathing, 1girl, 1boy,looking at viewer,pov,nude,breasts, nipples,(from behind:1.3), grabbing another's breast,  from behind | mixed bathing, 1girl, 1boy,looking at viewer, ,(from behind:1.3), breasts,pov,nude,nipples } , pov ,  open mouth,  

## 後ろクパァ
 from behind , hands on bathroom wall , light smile,  pussy juice , orgasm,  light smile , ass ,  pussy , from below  , pov , spread pussy,   heavy breathing,  open mouth, 

## くぱぁ
lying on bed,  { 7-7$$orgasm | sweat |  heavy breathing | head tilt |   trembling | spoken heart | heart-shaped pupils }  , open mouth,  , ahegao , trembling,  female orgasm,  drooling,  , ahegao , cum in pussy,   looking at viewer,  spoken heart,  spread pussy , wet hair,  wet,  trembling, 

## まとめ
1boy , on bed, sex , heavy breathing , { close mouth , (trembling:1.2)  | open mouth,  drooling } ,  { 1-2$$tearing up |  female orgasm | streaming tears }  , (motion lines, trembling:1.2),  {  skirt lift,  lifted by self,   { cowgirl position | missionary }  , pussy , vaginal ,   spread legs,  deep insetion  , { cum in pussy | sweat }   |  { front | from behind ,  , { cum in pussy | sweat }  } , all fours,  doggystyle  , { pillow grab |  sheet grab} ,  { ass grab | torso grab } | prone bone , { front | from side ,  { cum in pussy | sweat }  }  , { pillow grab |  sheet grab}  }  , { cum in pussy | sweat  }

# 正常位
1boy ,  on bed ,  penis in pussy ,  cum in pussy ,  1boy ,  (missionary,  sex , penis in pussy:1.3)  ,   on back , spread legs,  deep penetration,  ,    (torso grab:1.3),  (motion lines,  motion blur:1.8),  <lora:missionary:0.85>missionary sex 


nsfw , {20$$(embarrassed, nose blush:1.3) | (ecstasy:1.3) | (slut:1.2) | (vulgarity:1.3) | (wet:0.8) | (trembling:0.8)| (tears:0.7) | (drooling:0.6) | (sweat:0.8) | {  6::open eyes | (closed eyes:1.4) } | wince | (orgasm:1.5) |(feeling weak:1.5) | sweat}  , { ahegao,  wave mouth, frown |  shouting , open mouth |   sweat , frown  }  , (heavy breathing:1.2) ,  { 6::sweat |  cum in pussy , cum on body , cum explosion  }  (trembling:1.1),  { tareme  } ,   BREAK
{ lying, missionary ,  {arms up | hands on own chest  |  breasts squeezed together }   |  straddling , cowgirl position, from below,  ceiling  ,  { sweat | hands on own chest  |  breasts squeezed together } } missionary, vaginal, 1boy, penis, spread legs , motion blur, 

## バック
all fours,  doggystyle,   1boy , sex , front  , heavy breathing,  penis in pussy ,  (motion lines,  trembling:1.3),  
<lora:HDA_Doggystyle_HairPulledBackXL:1>HDA_MasterpieceXL_v.1, 1girl, HDA_HikariXL, HDA_Doggystyle_HairPulledBackXL, front , close up face 

## 断面図

multiple views, ( x-ray , cum in uterus :1.2) 

 # バック
 all fours,  doggystyle,  from behind , 1boy , sex , missionary,  crying , sad , pussy , ass  , in tent , torso grab,  pov , heavy breathing,  penis in pussy ,  (motion lines,  trembling:1.3),  looking at viewer, deep insertion , missionary ,  spread legs, 


 ## オマンコ見せ

 on bed , spread legs,  penis in pussy , ahegao , drooling, missionary,  pussy juice , spread pussy ,  close-up pussy , ceiling,  from below 

 ## しゃがみ
 sitting , squatting,  (knees apart feet together:1.5),   (front:1.3) , { smile , (head tilt:1.3) | (expressionless,  looking away:1.3) } ,  (front:1.2) , outdoors,  on bed ,  close-up pussy 

## 睡眠強姦
sleep,  (sleeping:1.3),  open mouth,  pajamas,  open clothes, closed eyes, nipples,   spread legs,  on bed   , medium breasts,   sleep assault , missionary,  sex , pov ,  pussy juice  , motion lines,  (trembling:1.2),  { torso grab | leg grab | grabbing another's breast }  , { 3::sweat | (multiple views, x-ray ,  cum in pussy,  uterus,:1.3) }

## 乳首吸い
crying,  tearing up,  , clenched teeth,  heavy breathing,  embarrassed,   upper body,    ( restrained,  arms up,  1.2),  breasts,  from below ,  nipples,  1boy,  (breast sucking:1.2),   faceless male,  fat man , tongue out,   grabbing another's breast,  


 ## 胸寄せ
 sitting , wariza , embarrassed , frown , light smile,  arms between breasts,  cleavage,   from above , head tilt , looking at viewer,  close-up face , indoors,  on bed 

sitting , wariza , embarrassed , light smile ,  open mouth,  arms breasts squeezed together ,  from above , head tilt , looking at viewer,  close-up face , indoors,  on bed 

## 胸隠し
lying , on bed ,  covering breasts,  open mouth,  upper body,  on bed , pillow,   close-up pussy ,  frown , embarrassed,  on back  , spread legs, 

 ## pale
  indoors,  in love  hotel ,  BREAK
  open mouth,  from below , spread legs,  standing , close-up pussy , embarrassed,  ceiling,  open mouth, 
   

   ## ディルドオナにー


   nude , naked, completely nude,  on floor , masturbation,  orgasm,  open mouth,  cowgirl position , dildo riding,   ,  front , small breasts,  flat chest,  drooling,   hands on Clitoris ,  hands on nipples,  trembling,  female orgasm, female ejaculation, 


   
## 流れ

- 四つん這い
- パイズリ 
-  doggystyle,  from above , heavy breathing,  pov , from above , paizuri,  open mouth,   orgasm,  sweat , licking penis,  cum shot ,  facial,  cum on breasts,  cum on body,  light smile , sweat,  cum in mouth , cum in throat, 
-  

- オナにー
masturbation,  lying on bed , __nsp/my/angle__ , { close-up face | close-up pussy } , heavy breathing, spread legs,  pussy , female masturbation,  orgasm,   { 2-3$$close eyes | trembling | heavy breathing | { 3::open mouth |  clenched teeth } | pussy in finger } ,  spread pussy, 

- オマンコ見せ
 on bed , spread legs, nose blush,  heavy breathing, open mouth,  pussy juice , spread pussy ,  close-up pussy , cervix,  <lora:cervix_Pony_V1.0:1> spread pussy, cervix , cervix prolapse,  { frown | light smile | orgasm } , __nsp/my/angle__ , sweat, 

- バック
 on bed ,all fours,  doggystyle, torso grab, heavy breathing,  heart-shaped pupils,   pussy,  orgasm,  looking at viewer,  penis in pussy , spread legs, {front , close-up face faceless male , { surprised | orgasm | ahegao } | pov , from behind , ass } ,   , (motion lines,  motion blur,:1.3) , trembling, 

- 騎乗位
-  { 2::straddling , from behind , ass , penis in pussy |  cowgirl position }  , orgasm , heavy breathing,  straddling, pov ,  from below , motion lines,  trembling,  motion blur,  open mouth,  looking at viewer,  sweat,  
-   { cowgirl position } , { 2-3$$cum in pussy  | x-ray | uterus  |  uterus in cum | multiple views }   , orgasm , heavy breathing,  straddling, pov ,  from below , motion lines,  trembling,  motion blur,  open mouth,  looking at viewer,  sweat,  
- 中出し後開き
light smile , on bed , spread legs, nose blush,  heavy breathing, open mouth,  pussy juice , spread pussy ,  close-up pussy , cervix,  <lora:cervix_Pony_V1.0:1> spread pussy, cervix , cervix prolapse,  {  light smile | orgasm } , __nsp/my/angle__ , sweat,  cum in pussy , cum in cervix,  multiple views,  cum explosion,  


- 挿入
{ sitting position, hug, face to face, straddle , faceless male |  missionary | grabbing from behind,  penis in pussy  }  , penis in pussy , sex ,  orgasm , heavy breathing,  motion lines,  trembling,  motion blur,  open mouth,  looking at viewer,  sweat,   { orgasm |  (ahegao:0.9) }  , drooling,   , sweat,  (motion lines:1.2),  multiple views,  pussy juice,  { sweat | (x-ray , uterus:1.1) }  ,  cum in pussy ,  cum in uterus , cum explosion,  

- ラスト
tearing up,  orgasm,  lying on bed , trembling,  from above , spread pussy,  cum in pussy,  cum explosion,  happy,  spoken heart,  multiple views,  close-up pussy , 

- standing , from below , cum explosion,  spread pussy,   spread pussy,  orgasm,  open mouth,  light smile , (head tilt:1.2),  spread legs,  penis , pov 