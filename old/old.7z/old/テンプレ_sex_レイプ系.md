

## 表情
 { {8-15$$(embarrassed, nose blush:1.3) | (trembling:0.8)| streaming tears | frown | angry | disgust | tearing up |  (sweat:0.8) | open eyes  | angry |  cry |  sad | sobbing |  shouting | panicking | half-closed eyes |  scared  }  }  ,  { 2::(sweat:0.8) |  0.3::cumin pussy , cum on body , cum explosion  }  (trembling:1.1), { 4::open mouth,  wavy mouth |    (one eye closed:1.4)  , wavy mouth   | shouting , sweat,   | close mouth }   BREAK


## 取り囲み

<lora:gangbang2:0.3:lbw=MIDD>1girl ,sex,(vaginal),cum,sweat,(gangbang:1.1),(multiple boys:1.2), spread legs,  pussy in vaginal , penis grabbing,  (projectile cum:1.2),

## レイプ後
 <lora:EmptyEyes_Diffuser_v10:1.2>  (expressionless:1.2),   spread legs,  cum in pussy,  cum explosion  , after sex,  on  back ,  on bed , (looking away:1.5) ,fog , heavy breathing,  half closed mouth,  (lying on bed:1.3) ,  spread legs,  pussy , vaginal 



 crying, tearing up,  streaming tears,   (all fours,  doggystyle:1.2),   <lora:EmptyEyes_Diffuser_v10:1.2>  (expressionless:1.2),   cum in pussy,  cum explosion  , after sex,   on bed  (looking away:1.5) ,fog , heavy breathing,  half closed mouth,    spread legs,  pussy , vaginal  , (from behind:1.5)  , (trembling:1.5), <lora:MultipleAsses_v1:0.8:lbw=MIDD> ,   from behind ,  ass , pussy juice, (open mouth:1.3), 


 ## 制服レイプ

 1girl ,  school uniform,  pleated skirt,   { serafuku | shirt ,  bow , checkered skirt } ,   { 1-2$$ hair hair ornament |  hair ribbon | hair ornament  |  hairclip | 0.4::glasses }   15 yo , { small | medium} breasts, __nsp/my/hair__ ,  __nsp/my/hair_color__ , __nsp/my/hair_length__ ,  { 1-3$$crying , tearing up | embarrassed |surprised } , back allay , indoors,  on floor , night ,  { open mouth , heavy breathing , orgasm  |  (mouth wrap duct tape:1.2)  } ,   { arms behind back , restrained | sweat } ,  { black |white thighhighs } ,  clothes lift, lifted bra  ,  nipples,  
{ missionary | cowgirl position | on stomach,  prone bone }  ,  pussy , vaginal , sex , 1boy , deep insertion , deep penetration, cum in pussy ,  close-up face , x-ray , cum in pussy , 1boy ,  torso grab,  (trembling,  motion lines,  motion blur:1.2),  tightening pussy , tightening  uterus ,  trembling uterus  , 

## レイプ2
{ 1-3$$crying | tearing up  | streaming tears }  , back allay , indoors,  on floor , night ,  { open mouth ,  heavy breathing , (trembling:0.8)  | { 1.2::sweat |  (blindfold:1.3) } ,  (mouth wrap duct tape:1.3)  } ,    ,  { black |white thighhighs | sole } , BREAK  
{ missionary , { arms behind back | arms  up | covering breasts  }  ,  { torso grab |  breasts grab  }   | cowgirl position , { torso grab | leg grab }  , { arms behind back | covering breasts  | sweat }   |  { all fours,  doggystyle , |  on stomach,  prone bone   } ,  { torso grab |  hip grab }  , { front , close-up face | from behind , close-up pussy , ass } , { arms behind back , restrained  |  sweat  }   }  ,  pussy , vaginal , sex , 1boy , deep insertion , deep penetration, { sweat | 0.7::cum in pussy , orgasm,  (trembling:1.3),  }   , { 0.3::sweat |  multiple views , close-up pussy  | 1.4::multiple views ( x-ray , uterus in pussy:1.3) } ,  tightening pussy , tightening  uterus ,  trembling uterus  , 

## レイプ3
{ 1-3$$crying | tearing up  | streaming tears | female orgasm | fucked silly }   , { in locker room | in warehouse |  indoors,  on bed  }  ,  { open mouth ,  heavy breathing , (trembling:0.8)  | { 1.5::sweat }  } ,    ,  { black |white thighhighs | sole } , BREAK  
{ missionary , { arms behind back | arms  up | covering breasts  }  ,  { torso grab |  breasts grab  }   | cowgirl position , { torso grab | leg grab }  , { arms behind back | covering breasts  | sweat }   |  { all fours,  doggystyle , |  on stomach,  prone bone   } ,  { torso grab |  hip grab }  , { front , close-up face | from behind , close-up pussy , ass } , { arms behind back , restrained  |  sweat  }   }  ,  pussy , vaginal , sex , 1boy , deep insertion , deep penetration, { 1.2::sweat | 0.7::cum in pussy , orgasm,  (trembling:1.3),  }   , { 0.3::sweat |  1.4::multiple views , ( x-ray , uterus)   | multiple views , ( x-ray , uterus in pussy:1.3) } ,  tightening pussy , tightening  uterus ,  trembling uterus  , 

## レイプ4
on bed ,  { missionary | 2:: missionary,  cowgirl position } ,  tearing up,  streaming tears,  crying  ,  { 2::clenched teeth , sweat, heavy breathing,   (orgasm,  trembling,  female orgasm:1.3) ,  grabbing penis  |  shouting , cum on body , bukkake , trembling,  orgasm , heavy breathing,  | 2::empty eyes , open mouth , holding arms , cum on body,  cum on breasts,  facial ,  } , { arms up | arms behind back | sweat } ,  { cum in pussy , (x-ray , uterus:1.3) | pussy juice } , 



### 四つん這い
1boy , fatman , faceless male,  torso grab,  all fours,   sex from behind , (orgasm,  ecstasy:1.3),   open mouth,  pussy juice,  motion lines,  trembling,   (clitoris:1.2), 


## 受精
{ 2::lying , on bed , missionary  }  ,  pussy , vaginal , sex , 1boy , deep insertion , deep penetration, cum in pussy ,  close-up face ,  cum in pussy , 1boy ,  torso grab,  (trembling,  motion lines,  motion blur:1.2),  tightening pussy , ( x-ray , fertilization,  fertilization egg ,  empty eyes,  surprised:1.2), pov 

### 横向き
doggystyle,  holding arms ,  pussy , vaginal , sex , 1boy , deep insertion , deep penetration, cum in pussy ,  close-up face ,  cum in pussy , 1boy ,  torso grab,  (trembling,  motion lines,  motion blur:1.2),  tightening pussy , ( x-ray , multiple views,  fertilization,  fertilization egg ,  empty eyes,  surprised:1.2) 

### テープ拘束
 crying   , streaming tears, surprised,   sitting , white panties ,   (tape gag,  arms behind back,  restrained:1.1),  in warehouse , knees together feet apart,  spread legs,   sweat,  lace trim panties , from below , close-up crotch , looking at viewer,  recording,  battery indicator,  "REC"
 
( motion lines , motion blur,  trembling:1.3), HDA_DoggyStyleXL_v1.3, doggystyle,  1boy ,  (tape gag,  arms behind back,  restrained:1.4),  on bed , (HDA_AhegaoXL:0.8) ahegao, 


## イラマチオ

one eye closed,  surprised,  another's head grab , irrumatio, deepthroat,  penis ,   crying , tearing up,  streaming tears,  drooling,  multiple boys,  holding arms , cowboy shot,  cum in mouth , (surprised,   trembling:1.3), 

## 睡眠強姦
 1girl ,  school uniform,  pleated skirt,   { serafuku | shirt ,  bow , checkered skirt } ,   { 1-2$$ hair hair ornament |  hair ribbon | hair ornament  |  hairclip | 0.4::glasses }   13 yo , { small | medium} breasts, __nsp/my/hair__ ,  __nsp/my/hair_color__ , __nsp/my/hair_length__ ,  (sleeping , close-eye:1.3) ,{ open mouth | half closed mouth } ,  { black |white thighhighs } ,  clothes lift, lifted bra  ,  nipples, 
{ missionary , { arms behind back | arms  up | covering breasts  }  ,  { torso grab |  breasts grab  }   | cowgirl position , { torso grab | leg grab }  , { arms behind back | covering breasts  | sweat }   |  { all fours,  doggystyle , |  on stomach,  prone bone   } ,  { torso grab |  hip grab }  , { front , close-up face | from behind , close-up pussy , ass } , { arms behind back , restrained  |  sweat  }   }  ,  pussy , vaginal , sex , 1boy , deep insertion , deep penetration, { sweat | 0.7::cum in pussy , orgasm,  (trembling:1.3),  }   , { 0.3::sweat |  multiple views , close-up pussy  | 1.4::multiple views ( x-ray , uterus in pussy:1.3) } ,  tightening pussy , tightening  uterus ,  trembling uterus  , 

### ペニスこすりつけ
spread legs,  close-up crotch , skirt lift,  pov ,  front , pov ,  lace panties , erotic panties  , { light blue | light pink | white }  panties ,  penis attach crotch ,  (panties aside:1.2),  grabbing pussy , 

## オマンコ見せ　後ろから
all fours,  doggystyle,  open pussy , from behind , (multiple views:1.2),  pussy juice  , from below , ass grab 

## オマンコ見せ　後ろから開き
 top-down bottom-up, ass,  spread ass ,  open mouth,   on bed , spread pussy , pussy juice , heavy breathing,  ,close-up hymen

## オマンコ見せ
{ standing , spread legs,  spread pussy, directly below , ceiling  | sitting , spread legs , spread pussy  } , open pussy , close-up pussy , pussy juice ,  (trembling:0.8),  { cum in pussy | sweat } 

## オマンコ開き（男から）
spread legs,  panties aside,  close-up pussy ,   spread pussy ,   crotch grab ,  pov , pussy juice ,  front , pov , (crotch grab:1.2) , uterus , urethra , hymen, arms behind back 

## オマンコ開き（後ろから
(on stomack , ,from behind:1.3) , ass ,   close-up pussy ,   spread pussy  , pov , pussy juicee ,  front , pov , crotch grab , uterus , urethra , hymen, 

## 胸もみ
grabbing another’s breast ,  (1boy:1.2) ,  sitting , on floor , breasts grab ,  grab from behind  , upper body,  close-up breasts,  close-up nipples, 

## パンツ近く
spread legs,  close-up crotch , skirt lift,  pov ,  front , pov ,  lace panties , erotic panties 

## 手コキ
 ? , { scared |  surprised | frown }   tearing up, { 1.4::half closed mouth |   close mouth } , { open mouth |  1.2::one eye closed }   tearing up, { kneeing | leaning forward } , { 1.5::from side | from above , pov }  1boy ,  motion lines,  motion blur,  penis , handjob,  cum shot , bukkake , { sweat |  spoken exclamation mark }   , looking at penis , look aged down, { 1boy , handjob,  |  gangbang, multiple penis } , { bukkake | cum on body , cum on breasts,   facial } 

### 制服レイプ　フェラ
{ scared |  surprised | frown } , crying, streaming tears,  tearing up, { open mouth |  1.2::one eye closed }   tearing up, close-up face ,  upper body,  { from side | 2::from above , pov , { head grab }  }  1boy ,  motion lines,  motion blur,  { 2::irrumatio,  deepthroat , deep insertion ,  (motion blur,  motion lines:1.2) , { sweat | cum in mouth }   | licking penis   }  , upper body, 

### 制服レイプ　輪かん
gangbang,  { cowgirl position | lying , missionary  | 2::all fours,  doggy , penis in mouth , pussy in penis }   sex ,  cum in pussy  , locking arms 

### 制服レイプ　レイプ目
{ missionary | cowgirl position | on stomach,  prone bone }  ,  pussy , vaginal , sex , 1boy , deep insertion , deep penetration, cum in pussy ,  close-up face ,(multiple views,  x-ray , uterus in pussy:1.3) ,

### 騎乗位
, crying, sad , tearing up,  school uniform,  clothes lift,  bra lift , nipples,  heavy breathing,  (tightening penis , undulating vaginal:1.3) ,   female orgasm,  orgasm,  cowgirl position ,  squatting,  from below , ceiling , open mouth,   , restrained,  in classroom, 1boy ,   ( x-ray , cum in uterus :1.2) 

### 後ろから手マン
sitting , on white couch , 1boy , covering from behind , spread legs , fingering another's pussy , pussy juice,   sweat,   faceless male,  trembling,  half open mouth, 

### 後ろから胸も見
  sitting , on white couch , 1boy , covering from behind , spread legs , grabbing another's breasts ,  sweat,  embarrassed,  open mouth,  pussy juice,  drooling,  (trembling:1.3), ahegao,  saliva ,  female female orgasm, 

### レイプ汎用
on bed , embarrassed, cowgirl position, straddling,  motion lines,  motion blur,  cum in pussy,  multiple views,   orgasm,  trembling,  female orgasm,   heavy breathing,  , { looking at viewer | looking away } , { open mouth , crying , shouting   |  1.5::scared, open mouth,  sweat,  trembling,   | wavy mouth, drooling, orga  (trembling)  | (surprised , clenched teeth , female orgasm:1.2),  } , (trembling , orgasm)   , pussy juice ,     pov , from below, grabbing another's breast,    crying, 

### 睡眠感

__nsp/my/hair_color__ , __nsp/my/hair_length__  , __nsp/my/hair__ , school uniform,  __nsp/NSFW/eyecolor__ ,   serafuku,  red  ribbon , sitting , on couch , 

sex from behind , pussy in penis , 1 boy , penis ,  sleeping,  close eyes , half close mouth , spread legs,  panties , clothes lift,  nipples,  lift bra , grabbing another's breast,  pussy juice , motion lines,  motion blur,  (trembling:0.8),  open mouth,  drooling,  heavy breathing, cum in pussy 


on bed , 
(sex from behind, grabbing from behind,  , grabbing another's breast:1.2),   pussy in penis , 1 boy , penis ,  sleeping,  close eyes , half close mouth , spread legs,  panties , clothes lift,  nipples,  lift bra ,  pussy juice , motion lines,  motion blur,  (trembling:0.8),  open mouth,  drooling,  heavy breathing, cum in pussy 

### 足開き
1girls , shirt , school uniform,  serafuku,  pleated skirt,   in office , sitting , couch , 1boy , grabbing another's breast,  grabbing from behind,  (faceless female:1.2)  , (sleeping , sleepy ,  close-eyes:1.2) ,half open mouth , drooling , spread legs , panties ,  
 ( battery indicator,   recording mark ,"REC":1.3) ,  

### 睡眠パイズリ
score_9, score_8_up, score_7_up,  best quality, masterpiece, very aesthetic, absurdres , megami magazine, bokeh, intricate details, hyperdetailed, (official art, extreme detailed,) ( highest detailed), HDR  BREAK  <lora:Difference_EdgeEmphasisForEbaraPonylr1e04:0.3>,   ,detail eyes , shiny eyes ,
 1girl ,   { 1-2$$ hair hair ornament |  hair ribbon | hair ornament  |  hairclip | 0.4::glasses }   13 yo , { small | medium} breasts, __nsp/my/hair__ ,  __nsp/my/hair_color__ , __nsp/my/hair_length__ ,  (sleeping , close-eye:1.3) ,{ open mouth | half closed mouth } ,  { black |white thighhighs } ,    nipples, 
lying , on bed , paizuri,  1boy, penis , grabbing another's breast,  cum on breasts,  cum shot , upper body  


### 睡眠感

in cafe ,  white serafuku,  pleated skirt,  nipples , half open mouth , drooling,  teacup, (sleeping , close-eye:1.3) , spread legs,  panties ,  clothes lift  , bra  , recording,  battery indicator,  recording mark ,"REC" ,

#### 序章 パンチラ

1girls , shirt , school uniform,  serafuku,  pleated skirt, mini skirt ,  (sleeping , sleepy ,  close-eyes:1.2) ,half open mouth , drooling , { white | light pink | light blue } panties , { cotton | lace } panties ,  lying ,  { clothes lift | bra | bra lift , nipples } ,  ( battery indicator,  video recording , recording mark ,"REC":1.3) , { 0.5::school bag | 2::(sweat:0.8) } , { from above | from side | from below }  , close-up { crotch | breasts , upper body } 

#### 処女膜確認

1girls , shirt , school uniform,  serafuku,  pleated skirt, mini skirt ,  (sleeping , sleepy ,  close-eyes:1.2)  , { half open mouth , drooling ,  lying  , ( { arms up | arms behind back | arms on breasts }:1.4)  |  on stomach , ass  } ,  {  bra | bra lift , nipples },  ( battery indicator,  recording , recording mark ,"REC":1.3) , close-up  pussy  , 1boy , ( spread pussy :1.2) , hymen , spread legs


#### 座り胸触り + おまんこ開き
1girls , shirt , school uniform,  serafuku,  pleated skirt, mini skirt ,  (sleeping , sleepy ,  close-eyes:1.2)  , half open mouth , drooling ,  {  bra | bra lift , nipples },  
sitting , on white couch , spread legs,  (grabbing another's breast,  grabbing from behind:1.2),  (trembling:1.1), (heavy breathing:0.8),   (spread pussy:1.2) ,  (1boy , faceless male:1.2),  clothes lift,  bra , pussy juice , nipples,  pussy  ( battery indicator,  recording , recording mark ,"REC":1.3) 


#### 後ろから挿入
1girls , shirt , school uniform,  serafuku,  pleated skirt, mini skirt ,  (sleeping , sleepy ,  close-eyes:1.2)  , half open mouth , drooling ,  {  bra | bra lift , nipples },  
(sitting , on white couch:1.2) , spread legs,  (grabbing another's breast,  grabbing from behind:1.2),  (trembling:1.1), (heavy breathing:0.8), sex , sex from behind ,   (reverse upright straddle . , sex from behind , penis in pussy :1.2) , penis , motion lines,   (1boy:1.2) , faceless male,  clothes lift,  pussy juice , nipples,  pussy  ( battery indicator,  recording , recording mark ,"REC":1.3) , { sweat | (cum in pussy,  uterus , x-ray:1.1)  }


#### 後ろから挿入寝バック
top-down bottom-up,  ass grab ,   (trembling:1.1), (heavy breathing:0.8), (in pussy :1.2) ,  motion lines,   (1boy:1.2) , faceless male,  clothes lift,  pussy juice , nipples,  pussy , pov ,  ( battery indicator,  recording , recording mark ,"REC":1.3) , { sweat | 1.3::(cum in pussy,  uterus , x-ray:1.4)  }

### りんかん

1girls , gangbang,  cum shot , bukkake , facial , cum on breasts,  cum on body,  cum in pussy,   shirt , school uniform,  serafuku,  (sleeping , sleepy ,  close-eyes:1.2)  , half open mouth , drooling ,  {  bra | bra lift , nipples },   missionary,  sex , multiple penis , bukkake,  (trembling:1.1), (heavy breathing:0.8), (in pussy :1.2) ,  motion lines,   (1boy:1.2) , faceless male,  clothes lift,  pussy juice , nipples,  pussy , pov ,  ( battery indicator,  recording , recording mark ,"REC":1.3) , { sweat | 1.3::(cum in pussy,  uterus , x-ray:1.4)  }


### めざめりんかん
1girls , gangbang,  cum shot , bukkake , facial , torso grab,  cum on breasts,  cum on body,  cum in pussy,   nude , naked, completely nude ,  surprised, { open mouth | wink } ,  tearing up,  streaming tears,   crying,  streaming tears,   orgasm,  female orgasm,   missionary,  sex , multiple penis , bukkake,  (trembling:1.1), (heavy breathing:0.8), (in pussy :1.2) ,  motion lines,   (1boy:1.2) , faceless male,  clothes lift,  pussy juice , nipples,  pussy , pov ,  ( battery indicator,  recording , recording mark ,"REC":1.3) , { sweat | 1.3::(cum in pussy,  uterus , x-ray:1.4)  } , (motion lines,  motion blur:1.3)


### レイプ語
HDA_AfterGangbangXL , lying on floor ,  standing boy , tearing up,  streaming tears,  empty eyes,  empty eyes,  arms behind back ,  spread legs,   from side ,  

### 目覚め
1girls , gangbang,  nude , naked, completely nude ,  tearing up,   crying,  streaming tears , all fours , doggy style , { irrumatio | licking penis } ,  from side , , orgasm,  female orgasm,   missionary,  sex ,  (trembling:1.1), (heavy breathing:0.8), (in pussy :1.2) ,  motion lines,   (1boy:1.2) , faceless male,  pussy juice , nipples,  pussy , ( battery indicator,  recording , recording mark ,"REC":1.3) , { sweat | 1.3::(cum in pussy,  uterus , x-ray:1.4)  } , (motion lines,  motion blur:1.3)

#### 盗撮

##### ロッカー
 in locker room , serafuku,  pleated skirt,  dressing skirt , panties  ,  bra ,  looking away ,

 #### 
   in office , sitting , on office chair,  table , holding cup,  smile ,  open mouth,  speaking ,  

#### 睡眠姦
1773234367

lying , on bed, open mouth,  sleeping, closed eyes,  open mouth,  open shirt,  white bra ,  from below ,  pillow ,  lace bra , lingerie,  skirt lift , white panties ,  (bra lift:1.2) , nipples,  large breasts,  spread legs,  close-up crotch , arms up , arms behind back 

lying , on bed, open mouth,  sleeping, closed eyes,  open mouth,  open shirt,   from below ,  pillow ,   skirt lift ,  pussy , nipples,  large breasts,  spread legs,  close-up crotch , clitoris,   arms up , spread another's pussy , pov ,  pussy juice , ecstasy,  heavy breathing, 

#### 挿入間近
lying , on bed, open mouth,  sleeping, closed eyes,  open mouth,   { from above , { spread pussy | sweat } , pov , 1boy ,  |  2::1boy ,  from below  } ,   imminent penetration,  1boy , penis , ,  spread legs, 

#### 挿入

lying , on bed, open mouth,  sleeping, closed eyes,  open mouth,   { from above , { spread pussy | sweat } , pov , 1boy ,  |  2::1boy ,  from below  } ,   missionary,  sex ,   1boy , deep penetration , trembling,   spread legs,  { leg grab  | torso grab | sweat }   , cum


## 後ろから
spread legs,  (grabbing from behind:1.2),  sex , penis , deep penetration,  reverse upright straddle,  on couch ,   , school uniform,  kneehighs,  serafuku,  black pleated skirt,  1boy ,  breasts grab , motion lines,  clothes lift,  bra  nipples,  open mouth,  heavy breathing,  , (trembling:0.8),  skirt lift, pussy ,   from below, ceiling,  clitoris,  close-up pussy , pussy juice, 

spread legs,  (grabbing from behind:1.2),  sex , penis , (deep penetration,  x-ray:1.2) ,   reverse upright straddle,  on couch ,   , school uniform,  kneehighs,  serafuku,  black pleated skirt,  1boy ,  breasts grab , motion lines,  clothes lift,  bra  nipples,  open mouth,  heavy breathing,  , (trembling:0.8),  skirt lift, pussy ,   from below, ceiling,  clitoris,  close-up pussy , pussy juice,  arms behind back  , (cum in uterus , trembling:1.3), 
## 種付けプレス
mating press,  missionary,  spread legs,  cowboy shot,  on bed,  heavy breathing,  indoors,  1boy , sex ,  penis ,  deep penetration, tearing up,  streaming tears,  tape gag,  trembling, fat man ,  (used condom,:1.2)  , holding arms 


## ごうかん
1boy , pov , from  below , cowgirl position , gangbang , fellatio , handjob , 2boys ,  ecstasy,  sex , (motion lines , motion blur,:1.2)    ,  on floor    open clothes,  nipples,  tongue out,  drooling,  hypnosis,  empty eyes,  heart-shaped pupils,  fellatio ,  missionary,  sex , irrumatio,  skirt lift,  lifted by self,  ,  bra  , cum on tongue,  facial , cum on breasts,  bukkake,  (japanese sound effects:1.2),  ejaculation,  female ejaculation,  x-ray ,  cum in uterus 


## SEX
 (orgasm,  ecstasy:1.3),  nipples,  
arms behind back , restrained,  all fours,  doggystyle,   motion lines,  motion blur, leaning forward,  tearing up,  streaming tears, sex , torso grab 

1girl , 1boy , black background , simple background, 
dim lights ,  medium breasts,  nose blush,  nipples, 
in prison ,   teen , toddler body ,  age down , slender , silver hair  , short hair,  small breasts,  flat chest,  loli , pink frilled dress,  skirt ,  
faceless female,  from behind , fellatio,  from below,  kneeing, 