

## 表情テープ
{ {2-3$(embarrassed, nose blush:1.3) | (trembling:0.8)| streaming tears | frown | disgust | tearing up |  (sweat:0.8) | open eyes  | crying |  sad , sobbing | panicking | (surplized:1.3)  | half-closed eyes }  }  { (trembling:1.1) |  (trembling:1.3) } , { (tape gag:1.3)| 0.2::bindfold | 0.2::(tape gag:1.3) ,0.2::bindfold } 

## SEX



HDA_DoggyStyleXL_v1.3


## 表情
crying,  tearing up , streaming tears , { frown | sweat } , heavy breathing , drooling ,  close-up face , { sweat | bukkake , facial}
(torogao:1.3),  hetero,  open mouth,  drooling,  (trembling:1.3),  orgasm , female orgasm  , (motion lines , motion blur:1.4), 


## フェラ奉仕系
1boy , 
 {  0.5::(black blindfold:1.3) | sweat  }  , tearing up,  streaming tears,  scared,  tearing up , { sweat | (surprised:1.2) }  , heavy breathing,    sweat , heavy breathing,  (orgasm,  female orgasm,  trembling:1.3) , kneeing , on floor , 
{
  1::{ HDA_AllFours-fellatioXL , fellatio ,  { pov | from above }  , motion lines,  trembling,  }  |
  1::{ HDA_DeepthroatXL , deep throat , pov , cum in mouth ,  { pov | from above } , motion lines,  trembling,  } |
  1::{ HDA_FellatioXL, fellatio , drooling , cum drool ,  { pov | from above } , motion lines  }
  1::{ HDA_KissingPenisXL , kiss on penis  ,  { pov | from above } } |
  1::{ HDA_OralInvitationXL , { cum on tongue , cum in throat | throat , tongue out }  ,  { pov | from above } } |
  1::{ HDA_PaizuriXL , paizuri , { sweat | fellatio | licking penis } ,  { pov | from above } } , motion lines,  trembling,  |
  0.2::{ HDA_SideFellatioXL , from side , (look up:1.2)  } 
}

## 改良
1boy , 
 {  0.2::(black blindfold:1.3) | sweat  }  , orgasm,  heavy breathing,    sweat , heavy breathing,  (orgasm,  female orgasm,  trembling:1.3)  , on bed  ,
{
  1::{ fellatio ,  { pov | from above }  , motion lines,  trembling,  } , all fours,  |
  1::{  deep throat , pov , cum in mouth ,  { pov | from above } , motion lines,  trembling,  } |
  1::{  fellatio , drooling , cum drool ,  { pov | from above } , motion lines  }
  1::{ licking penis,  kiss on penis  ,  { pov | from above } } |
  0.2::{ HDA_OralInvitationXL , { cum on tongue , cum in throat | throat , tongue out }  ,  { pov | from above } } |
  1::{ paizuri,  kneeing, pov, {  fellatio | deepthroat | licking penis } , { sweat |  0.2::head grab } , cum in mouth , heavy breathing }  |
  0.2::{ HDA_SideFellatioXL , from side , (look up:1.2)  } 
}

### その他

paizuri,  kneeing,  fellatio , pov , deepthroat , head grab , cum in mouth , heavy breathing
paizuri,  kneeing,  from above , pov , deepthroat , head grab , cum in mouth ,( surprised:1.2), 
heavy breathing,  open mouth,  cum in throat,  tongue out,  cum on tongue,  drooling,  


### 頭抑え

  kneeing,  cum in mouth ,  (trembling,  orgasm,  heavy breathing:1.2),   looking at viewer,  tearing up, {  0.5:: (blindfold:1.5) | sweat }  , on bed  , close-up face , upper body 

## その他
{
  HDA_AllFoursMasturbationXL , masturbation,  on bed , ,  hetero,  (drooling,  trembling,  orgasm:1.3),  from behind ,  finger in pussy ,  bottom-up , frown , female orgasm , heavy breathing,  |
}

## 挿入前
  { 
  looking at viewer,  , tearing up,    { 2-3$$ { crying,  sobbing  | 3::(black blindfold:1.3) }  |  { tape gag | open mouth }  |  { covering breasts |  arms behind back , restrained | covering crotch }  | heavy breathing  | (surprised:1.2) }  all fours , doggystyle,  ass , from above , pov ,   imminent penetration,  torso grab , crying , sobbing ,  pov , "REC" , recording,  battery indicator,  penis , on bed  | 
   looking at viewer,  , tearing up,    { 2-3$$ { crying,  sobbing  | 0.5::(black blindfold:1.5) }  |  { tape gag | open mouth }  |  { covering breasts | covering crotch }  | heavy breathing  | (surprised:1.2) }  , all fours , top-down bottom-up,  doggystyle,  ass , from above , pov ,   imminent penetration,  torso grab , crying , sobbing ,  pov , "REC" , recording,  battery indicator,  penis , on bed ,  { sweat | doggystyle } | 
    looking at viewer,  , tearing up,    { 2-3$$ { crying,  sobbing  | 0.5::(black blindfold:1.5) }  |  { tape gag | open mouth }  |  { covering breasts | covering crotch }  | heavy breathing  | (surprised:1.2) }  , cowgirl position,  { arms behind back | covering breasts | arms breasts squeezed together } ,  (imminent penetration:1.2), { torso grab | breasts brag }  , crying , sobbing ,  pov , "REC" , recording,  battery indicator,  (penis:1.2) , on bed ,  { sweat }  }

## SEX系全般
 { (black blindfold:1.5) |   (torogao:1.3),  hetero,  open mouth,  drooling,  (trembling:1.3),  orgasm , female orgasm  , (motion lines , motion blur:1.4),  heavy breathing,  orgasm } ,

{
  1::{HDA_CowgirlPositionXL ,  cowgirl position,  { sweat | squatting } , from below  , pov } |
  0.5::{HDA_DeepPenetrationFromBehindXL , close-up face , doggystyle , { pillow grab | sheets grab } , (trembling:1.4)  , from below ,  surprised,  orgasm,  drooling,   , nude female} | 
  0.5::{HDA_DoggyStyleXL_v1.3 , close-up face , doggystyle , { pillow grab | sheets grab } , (trembling:1.4)  ,   from below ,  surprised,  orgasm,  drooling, nude female , { sweat | (trembling,  surprised:1.4) } , front , close-up face } }  | 
  2::{HDA_MissionaryXL_v1.2,  { from side | pov } ,  { sweat | spread legs , { torso grab | leg grab  } }  |
  { sitting , on couch , (1boy , faceless male:1.4),  , (sex from behind, grabbing from behind,  , grabbing another's breast:1.2),   pussy in penis , 1 boy , penis ,  sleeping,  close eyes , half close mouth , spread legs,  panties , clothes lift,  nipples,  lift bra ,  pussy juice , motion lines,  motion blur, open mouth,  drooling,  heavy breathing, cum in pussy  ,   sweat , heavy breathing,  (orgasm,  female orgasm,  trembling:1.3) }   | 
  { <lora:reverse-upright-straddle-ponyxl-lora-nochekaiser:0.85:stop=10>, reverse upright straddle, sex from behind, sex, vaginal, sitting on lap, penis, testicles, spread legs} |
  { <lora:prone-bone-ponyxl-lora-nochekaiser:0.85:stop=10>, prone bone, sex from behind, boy on top, on stomach, sex, ass ripple,  lying, nude,  penis, open mouth, blush,  { (arms behind back , restrained:1,3) | sheets grab }  , faceless male,  holding arms } | 
    { <lora:prone-bone-ponyxl-lora-nochekaiser:0.85:stop=10>,  standing sex, spread legs,  doggystyle,  sex from behind, on stomach, sex,  lying, nude,  penis, open mouth, blush,  { (arms behind back , restrained:1,3) | 3::(sheets grab:1.2) }  , faceless male,  holding arms } , { HDA_AhegaoXL | 3:: tearing up,   female orgasm,   }  ,  { 4:: light smile   drooling,  open mouth | (tape gag , surprised:1.3),  orgasm,  }  orgasm,  (trembling:1.3),  tearing up,  (from below , close-up pussy:1.4)  , leaning forward,  cum in pussy,  cum explosion,   HDA_AhegaoXL  , arms behind back ,  (x-ray , uterus in cum:1.2) | 
      { sitting , on  bed , HDA_CowgirlPositionXL ,  from behind , ass } , { HDA_AhegaoXL | 3:: tearing up,   female orgasm,   }  ,  { (tape gag , surprised:1.3),  orgasm,  }  orgasm,  (trembling:1.3),  tearing up,  (from below , close-up pussy:1.4)  
      

} , {1-3$$sweat | used condom | cum in pussy | (Multiple view, Frame , cum in uterus:1.3)} 


## オマン湖見せ
embarrassed,  open mouth,  { nose blush | embarrassed } , heavy breathing,   

{
  1::{ HDA_PovSpreadPussyXL ,  spread pussy, close-up pussy , hymen , {  from below , { sitting | squatting } | front , sitting ,  }  , cervix,  ,  } ,
  1::{ <lora:cervix_Pony_V1.0:1> spread pussy, cervix , {  from below , { sitting | squatting } | front , sitting ,  }  , cervix,  ,  }   , (close-up pussy ,multiple views:1.3), 
} ,  pussy juice , orgasm

## レイプ
{  (black blindfold:1.3) |  (tape gag: 1.2) |    (black blindfold:1.3) , (tape gag: 1.2)  | { clenched teeth |  open mouth }  , tearing up,  streaming tears,  scared,  tearing up , { sweat | (surprised:1.5) } }
{
    1::{ <lora:spitroast-ponyxl-lora-nochekaiser:1:stop=10>, spitroast, double penetration, mmf threesome, group sex, threesome,  gangbang,  sex from behind, vaginal, doggystyle,  } , drooling,  { fellatio | deepthroat }  , { from side | cowboy shot | from above }  , 2boys ,
      1::{ gangbang,  group sex,  cowgirl position,  gangbang , deepthroat,   3boys,  } 
}

## パンチラ , ブラ
{ (blindfold:1.5) | 2::(crying , sad , sobbing , scared , surprised:1.3) } , indoors , { white | light pink | light blue | plaid } panties ,  lace trim panties, skirt lift, { sweat |  (open clothes,  bra:1.3) } , { (sweat:0.7) | 0.4::("REC" , recording,  battery indicator:1.5) }  
{
  { sitting, wariza , knees together feet apart, indoors, (knees together feet apart:1.3) } | 
  { lying , on floor , from below , close-up croch } |
  { lying , on floor , (from behind , ass:1.3) ,on stomach , close-up croch } |
  { lying , on floor , from above ,  on back  , close-up croch , indoors , { (blindfold:1.5) | 2::(crying , sad , sobbing , scared , surprised:1.3) }  , skirt lift } |
  { lying , on floor , from above ,  on back  , close-up croch ,  upper body , <lora:bra-lift-ponyxl-lora-nochekaiser:1>, bra lift, bra, nipples, panties, hands on chest, covering breasts,  }  
}

## 四つん這いオナニー

HDA_AllFoursMasturbationXL , masturbation,  on bed , ,  hetero,  (drooling,  trembling,  orgasm:1.3),  from behind ,  finger in pussy ,  bottom-up , frown , female orgasm , heavy breathing,  |
  
  ## 手コキ

  cuddling handjob,  Cuddling  , penis, pov , breasts press,   motion lines,  motion blur,  light smile , open mouth,  (head tilt:1.2),  pov ,  sweat,  heavy breathing,  ecstasy,   ejaculation,