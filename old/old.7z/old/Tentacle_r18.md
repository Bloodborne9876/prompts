 illustration  ,  (Top Quality, 8k:1.1), (Sharp Focus:1.2), (perfect anatomy:1.2) BREAK
1girl,  solo , <lora:hoshimachi_suisei_v1:0.8:lbw=OUTD> sui1, 1girl, solo, side ponytail, hoshimachi suisei, fingerless gloves, single thighhigh, jewelry, single sock, thigh strap, bracelet, blue socks, buttons, single kneehigh, plaid dress, blue choker, blue belt, plaid skirt, mini crown, grey skirt, blue ascot, long sleeves, plaid jacket BREAK
{ panicking,  surprised |   frown  | 3::scared, cry  } ,  tearing up ,  BREAK 
in cave , on floor , (many many oily tentacles:1.2), (mucus:1.2), (tentacle swarm:1.2), spread legs, (tentacle wraps around arms:1.1), (tentacle wraps around legs:1.1), (tentacle wraps around breasts:1.1), (tentacle wraps around waist:1.1), sobbing, perfect anatomy, dynamic pose,  
{ from above | from below | front }  ,  pussy , vaginal ,   <lora:horo_tentacle:1:lbw=OUTD> , wet clothes,  <lora:against_glass_v0.2:1> 

shiny hair,  shiny skin, masterpiece,  best quality,  (perfect anatomy:1.2) ,  detail eyes , focus eyes break
1girl,  solo ,<lora:suisei1:1> suiseidef ,  { sweat  |  2::torn clothes,  torn skirt,  torn jacket ,  plaid skirt, mini crown, grey skirt, blue ascot, long sleeves, plaid jacket , nipples  | naked , (nude:1.2)  } BREAK  


illustration  ,  (Top Quality, 8k:1.1), (Sharp Focus:1.2), (perfect anatomy:1.2) BREAK
1girl,  solo , <lora:hoshimachi_suisei_v1:0.8:lbw=OUTD> sui1, 1girl, solo, side ponytail, hoshimachi suisei, fingerless gloves, single thighhigh, jewelry, single sock, thigh strap, bracelet, blue socks, buttons, single kneehigh, plaid dress, blue choker, blue belt, plaid skirt, mini crown, grey skirt, blue ascot, long sleeves, plaid jacket , { sweat | 2:: (torn clothes,  torn legwear,  torn shirt,  torn skirt:1.4) }   BREAK
{panicking,  surprised |  frown   | scared, cry , tearing up,  teardrop,  streaming tears  } ,  sweat , (shouting:1.2), (many many oily tentacles:1.2), (mucus:1.2), wet clothes,  <lora:against_glass_v0.2:1:lbw=MIDD> , hands on glass ,  window fog , knee on glass


# pile
sitting, wariza , __nsp/my/angle__ , { arms behind head | arms behind back } , arms wrap tentacles ,
(pussy , vaginal:1.2) ,  ( knees together , legs closed:1.3) , (front:1.2), { <lora:hugging_own_legs_v0.3:1> hugging own legs | squatting } , (looking at another,  looking away:1.3),
<lora:kneestogetherfeetapart:1> , knees together feet apart, sitting, pussy , vaginal
pussy , vaginal , ( knees together , legs closed:1.3) , (front:1.2), pov , {  sitting ,  { wariza | 2::spread legs , (front:1.2) ,   (tentacles restraint legs:1.2) | 1.2::hands on floor } }  ,  tentacles,  tentacle pit , { water surface |  tentacle pit  }  , { looking at viewer | looking to the side | face down } , legs around tentacles  , (open mouth:1.2)
(tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , tearing up ,   standing  , (spread legs:1.3),  (focus crotch:1.2)   ,  (Directly below:1.3) , (from below:1.2) ,  bottomless , (skirt lift,  lifted by self:1.1) , looking at viewer ,  embarrassed,  upper body,  (headless , body only:1.2) , dynamic pose, (pussy:1.2)  






# 基本

## 前座

## ヘッダー
{ cry ,sad , tearing up , streaming tears , sobbing , open mouth |  (embarrassed,blush:1.3), ,(steam:0.8),(wet:0.8),(sweat:0.8),(trembling:1.3) ,(parted lips:1.3),(harf open eyes:1.4),(feeling weak:1.5) , open mouth } BREAK
(tentacle pit:1.1) , tentacles , tentacle nest ,tentacles , tentacle pit , tentacles , <lora:tentacles_v0.4:0.75>   BREAK
[X]


1girl , solo , nsfw , {10$$ cry | sad | tearing up | streaming tears | sobbing | open mouth | scard | (embarrassed, nose blush:1.3) | (ecstasy:1.1) | (trembling:0.8)|   (drooling:0.6) | { open mouth | clenched teeth | (face down:1.5)  } , {sweat | cun in pussy} }  BREAK    (looking at another,  looking to the side,:1.5) 


## 腕上げ

sitting, wariza , from above , arms behind head ,  arms wrap tentacles ,

### パンチラ

#### たくし上げ
(pussy , vaginal:1.2) , {sitting , wariza | sitting  } , pussy { front | from above } , bottomless ,  skirt , (skirt lift,  lifted by self:1.3) , looking at viewer , water surface , 

#### 膝抱え
(pussy , vaginal:1.2) ,  ( knees together , legs closed:1.3) , (front:1.2), { <lora:hugging_own_legs_v0.3:1> hugging own legs | squatting } , (looking at another,  looking away:1.3),

#### 立膝
<lora:kneestogetherfeetapart:0.7:lbw=MIDD> , knees together feet apart, sitting, pussy , vaginal


## 胸隠し * 1 * 3
<lora:covering_breasts_v0.1:1> ,  { open mouth | 2::closed mouth }, covering crotch , covering breasts  , { standing , upper body , bottomless  | sitting , wariza  }, open mouth, { front | from above } 

## 2
{ 2::frown , nose blush,  embarrassed,  sweat,  |  cry , sad , clenched teeth,  sweat,   }  , dynamic pose, frown , disgust , looking at another , looking to the side,     tentacles, tentacles pit , (many many oily tentacles:1.2), (mucus:1.2), <lora:tentacles_v0.4:0.7:lbw=MIDD> , pussy  { (ass:1.3) , all fours,  doggystyle,  } , ? , { spoken question mark | spoken ellipsis }    (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , <lora:tentacles_v0.4:0.6:lbw=MIDD>  , from behind , { multiple views,  face | sweat } 


## 座りパンチラ * 2 * 6
pussy , vaginal , ( knees together , legs closed:1.3) , (front:1.2), pov , {  sitting ,  { wariza | 2::spread legs , (front:1.2) ,   (tentacles restraint legs:1.2) | 1.2::hands on floor } }  ,  tentacles,  tentacle pit , { water surface |  tentacle pit  }  , { looking at viewer | looking to the side | face down } , legs around tentacles  , (open mouth:1.2)

## 下から見る * 1 * 3
(tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , tearing up ,   standing  , (spread legs:1.3),  (focus crotch:1.2)   , narrow waist ,  (Directly below:1.3) , (from below:1.2) ,  bottomless , (skirt lift,  lifted by self:1.1) , looking at viewer ,  embarrassed,  upper body,  (headless , body only:1.2) , dynamic pose, (pussy:1.2)  

## 終わり

empty eyes,  bukkake,  open mouth , ,  ,   lying , { cry  | frown }  , tearing up  , streaming tears,    tentacle-pit , tentacle-pit,tentacles,  in tentacles pit , (many many oily tentacles:1.2), (mucus:1.2), { spread legs | bukkake } ,  cum on body,  cum in pussy,  facial,  cum on breasts, after pussy ,  <lora:tentacles_v0.4:0.8:lbw=MIDD> , __nsp/my/angle__ ,  <lora:bukkake_v0.4:0.75:lbw=MIDD>

## 終わり 2 * 2
streaming tears,  tearing up,  open mouth,  after sex,  orgasm,  female orgasm,  <lora:aftersex:0.7:lbw=MIDD> , after sex, cum, lying, cumdrip, ass, on stomach, on back, fucked silly, sweat, cum pool, bukkake, trembling , { pillow hug | sheets grab } 

## 終わり2
streaming tears,  tearing up,  open mouth,  after sex,  orgasm,  female orgasm,  sitting , on couch  ,  spread legs,  empty eyes,  looking at another,  looking to the side,  after sex, cum,  cumdrip, fucked silly, sweat, cum pool, bukkake, trembling , { pillow hug | sheets grab } , hands on pussy,  hands on vaginal , 

## 救出　保護

empty eyes, cry , sad  ,  (heavy breathing:1.2)  , tearing up,  streaming tears, { pregnancy |   after sex,  cum in vaginal } , { sitting , on couch | lying }  , indoors , on bed , open mouth  , face down , looking at down , scared, 

## タイトル
{ sad , cry}  , (heavy breathing:1.2)  , tearing up,  streaming tears, <lora:tentacles_v0.4:0.8:lbw=MIDD> , (many many oily tentacles:1.2), (mucus:1.2), (__nsp/my/panties__:1.2) , __nsp/my/new_panties__ , focus panties , detail panties , { 2::{front | cowboy shot }, ( knees together , legs closed:1.3) , (front:1.2), pov , {  sitting ,spread legs |   { <lora:hugging_own_legs_v0.3:1> hugging own legs | 2::hands on floor } } },  water surface , { looking at viewer | looking to the side | face down } 



## 全体

  { panicking,  surprised  ,  __nsp/my/tear__ |   frown  , __nsp/my/tear__  | scared, cry , __nsp/my/tear__ | 6:: (sexual ecstasy:1.3), orgasm, in heat,  heart-shaped pupils, (trembling:1.4), open mouth , pussy juice , fucked silly , heavy breathing ,  } BREAK 
in cave , <lora:tpit:1.2> , tpit , tentacle pit  , (restrained, cum, tentacles, tentacle pit:1.3)  , sweat ,  vaginal,  pussy , tentacles fellatio , pussy in tentacles ,  (focus crotch:1.4) ,  narrow waist ,  looking at down ,  cum on body,  facial,  cum on breasts, { pussy in vaginal  | <lora:multiple_insertions_v0.2:1> multiple insertions |  <lora:large_insertion_v0.1:1> | <lora:multiple_insertions_v0.2:1> multiple insertions  , <lora:large_insertion_v0.1:1> } , __nsp/my/angle__ 

(restrained:1.4) , panicking,  surprised , open mouth,  (heavy breathing:1.2)  , tearing up,  streaming tears , teardrop , empty eyes,  sobbing, <lora:tentacles_v0.4:0.8> , (many many oily tentacles:1.2), (mucus:1.2), (tentacle wraps around arms:1.1) ,  (tentacles wraps around legs:1.1), (tentacles wraps around breasts:1.1), (tentacles wraps around waist:1.1) , sitting ,  spread legs, pussy vaginal  , front , pov , 


##フェラ

in cave , <lora:tpit:1.2> , tpit , tentacle pit  , (restrained, cum, tentacles, tentacle pit:1.3)  ,  upper body ,    <lora:projectile_cum_v0.2:1> ,  projectile cum , bukkake , excessive cum, after fellatio , cum in mouth ,  
tentacles in mouth,  (mouth in tentacles:1.2) ,  (restrained:1.2),   { from side  | from above } 


星街すいせい。目が覚めたようだな。
私は君の事を知っている。
君の部屋には触手の生物が蔓延っている。このテープの後、一斉に触手が襲いかかるだろう。
部屋から出る方法は１つ。触手の攻めに耐えきり快楽堕ちしないことだ。
選択は君次第だ。ゲームを始めよう。


## テンプレ

illustration  , focus eyes , ultra detail eyes ,   (Top Quality, 8k:1.1), (Sharp Focus:1.2), (perfect anatomy:1.2) BREAK
1girl,  solo ,
[X] BREAK
[Y] BREAK


 sleep on back , in hotel ,   on bed , closed eyes , bra ,   <lora:sukebra(bsb&fsb):1> , fsb , frosuke ,  lying,  on  floor , sleeping, { closed eyes |  half-closed eyes } , upper body, 
