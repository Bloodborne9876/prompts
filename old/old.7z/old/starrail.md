## ヘルタ水着

herta \(honkai: star rail\) ,  long hair, grey hair, hair flower,  frill swimsuit,    ,  small breasts,  flat chest,  12 yo , straw hat,  sandals,  upper body,  hands on hair 
sitting ,  wariza , miniskirt , on beach , looking at viewer,  in beach,  sunset,  lens flare,  from above , cowboy shot , wind , wind hair , wind cloths ,  sunset,   light smile ,  embarrassed,  open mouth,  sunburn,  from above , hands on hat , 


## ホタル水着