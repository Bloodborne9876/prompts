shiroko \(blue archive\) , shiroko, animal ears, blue eyes, grey hair, hair ornament, hairpin, halo, (medium hair:1.2), wolf ears, nude , naked , completely nude,  drooling,  (trembling:1.4), covering breasts,   tearing up,  crying  BREAK 


## テンプレ

### 割合

- 導入: 10枚
- 挿入: 30枚
- メス落ち : 30枚
- アフター : 20枚

## 導入1

 { {2-5$$  panicking | tearing up  |  frown |  surprised |   half-closed eyes }  }  ,  { half open mouth  | close mouth } , { 4::(looking away:1.5) | looking at viewer } 
sitting , hugging own legs,  on ground , (white panties:1.3), (knees together feet apart,:1.3) 


### 導入 パンツ
sitting , spread legs,  on ground , (pink panties , lingerie , lace panties :1.3), (knees together feet apart,:1.3)    , legs wrap tentacles,  arms wrap tentacles torso wrap tentacles, 


## 導入　見直し
<!-- 
キャラ
{ sitting , on ground , spread legs,  legs wrap tentacles ,  { mucus ,covering breasts,  covering crotch }    |  knees together feet apart, sitting,  |  3::doggystyle,  all fours,  { 2::front , cleavage collarbone , open clothes  |  ass , legs wrap tentacles , from behind , spread legs }   }  ,  ({ white | light pink | light blue }  panties , { 2::lace panties , lingerie |  cotton panties  } :1.2),   legs wrap tentacles , torso wrap tentacles BREAK -->

nsfw , on ground , tentacles , (many many tentacles , tentacle nest:1.1) , tentacle pit ,
 { {8-15$$  panicking | embarrassed | tearing up |  (sweat:0.8) | crying | tearing up | streaming tears | open eyes  | crying | sobbing |  scared | frown |  shouting | panicking | half-closed eyes }  }  ,   (trembling:1.1), { 4::open mouth | clenched teeth | (one eye closed:1.4)  , wavy mouth | close mouth } , { 4::(looking away:1.5) | face down | looking at viewer } , close-up character,  { 3::sweat | (multiple views, split view:1.2) } 

## 導入　見直し4
in cave ,  { sitting ,  spread legs  ,  { arms up , restrained | sweat }   |  knees together feet apart,  sitting,  { covering panties | sweat } , |  doggystyle,  all fours,  from behind  , ass  | standing ,  (spread legs:1.3), (focus crotch:1.1)  , (directly below:1.3) , (from below:1.2) ,  { arms up , restrained | sweat }    }  , {   3-5$$tearing up | frown | surprised,  panicking |  streaming tears | cry | sad |   scared | horror \(theme\)  } , {  4::open mouth | teeth mouth } , { (looking away:1.5) | looking at viewer } ,  sweat,  (mucus:1.2) , { 1.5::(sweat:0.8) |  (multiple views:1.3) } BREAK , ( legs wrap tentacles:1.1) ,  lace trim panties ,  
 <lora:tentacles_Pony_V1.0:0.5> SHOKUSYU, TENTACLES,TENTACLES PIT ,  restrained, 


## 導入　見直し5
<lora:FComic_1to1000_Pony_V1:1:stop=10>fcomic_1to1000_pony, (comic:1.25),
(Multi view, Frame, Text, speech bubble, frame, heart, trembling, focus line, vibrating line, comic expression, Sound effect)
in cave ,  { sitting ,  spread legs  ,  { arms up , restrained | sweat }   |  knees together feet apart,  sitting,  { covering panties | sweat } , |  doggystyle,  all fours,  from behind  , ass  | standing ,  (spread legs:1.3), (focus crotch:1.1)  , (directly below:1.3) , (from below:1.2) ,  { arms up , restrained | sweat }    }  , {   3-5$$tearing up | frown | surprised,  panicking |  streaming tears | cry | sad |   scared | horror \(theme\)  } , {  4::open mouth | teeth mouth } , { (looking away:1.5) | looking at viewer } ,  sweat,  (mucus:1.2) BREAK , ( legs wrap tentacles:1.1) ,  lace trim panties ,  {1.5::crying , sobbing , streaming tears | scared , surprised } , tearing up 




## 導入2
nsfw , on ground , tentacles , (many many tentacles , tentacle nest:1.1) , tentacle pit ,
キャラ, 胸の大きさ
{ { standing  |  sitting  , on ground  }   spread legs ,  legs wrap tentacles ,  mucus ,   {1-3$$sweat |  covering crotch }  , { front | from below }  |  sitting , on ground ,  (knees together feet apart:1.3),  { front | from below }   |1.5::doggystyle,  all fours, { front , close-up face  | 4::ass , from behind } , on ground }  ,  BREAK (close-up crotch:1.1),  ( { light pink | light blue |  white }  panties ), 
 { {8-15$$  panicking | embarrassed | tearing up |  (sweat:0.8) | crying | tearing up | streaming tears | open eyes  | crying | sobbing |  scared | frown |  shouting | panicking | half-closed eyes }  }  ,   (trembling:1.1), { 4::open mouth | clenched teeth | (one eye closed:1.4)  , wavy mouth | close mouth } , { 4::(looking away:1.5) | face down | looking at viewer } , BREAK 

## 導入3
 nsfw , on ground , tentacles , (many many tentacles , tentacle nest:1.1) , tentacle pit , in cave , { sitting , spread legs , {  { arms up, arms wrap tentacles ,  restrained | covering breasts | covering crotch }   | sweat } , legs wrap tentacles | knees together feet apart, sitting ,  | lying , from behind ,  ass , spread legs, on stomach , legs wrap tentacles , looking at viewer | doggystyle, all fours, from behind , ass , legs wrap tentacles | standing , (spread legs:1.3), (focus crotch:1.1) , (directly below:1.3) , (from below:1.2) ,  { arms up |  covering crotch  } , legs wrap tentacles } , { disgust |  surprised, panicking | crying , sad , streaming tears } , { 2::open mouth | clenched teeth  } , { (looking away:1.1) | looking at viewer } , sweat, (mucus:1.2) , { 1-2$$(sweat:0.8) , heavy breathing | (multiple views ,close-up pussy) } ,  { 1-3$$sweat | torn clothes |  imminent penetration }  ,  { 2::from below , ceiling | sweat } 


 ## 導入　漫画風

 nsfw , on ground , tentacles ,  tentacle pit , in cave , { sitting , spread legs , arms up , arms wrap tentacles ,  restrained | sweat } , legs wrap tentacles | knees together feet apart, sitting,  lying , from behind ,  ass , spread legs, on stomach , legs wrap tentacles , looking at viewer ,  doggystyle, all fours, from behind , ass , legs wrap tentacles , standing , (spread legs:1.3), (focus crotch:1.1) , (directly below:1.3) , (from below:1.2) ,  arms up ,  arms wrap tentacles , restrained  , legs wrap tentacles  , { 3-5$$tearing up | frown | surprised, panicking | streaming tears | cry | sad | scared | horror \(theme\) } ,  open mouth ,  clenched teeth , (looking away:1.5) , looking at viewer , sweat, (mucus:1.2) ,  (sweat:0.8) , heavy breathing , open clothes,  nipples  ,   panties ,  lace trim panties BREAK ,  torn clothes , imminent penetration , (mosaic censoring:1.7) 

<lora:FComic1To3Page_Pony_V1:1:stop=20>
(3page),comic,Multi view, Frame, Text, speech bubble, frame, heart, trembling, focus line, vibrating line, comic expression, Sound effect, 1girl, solo focus, (full body:1.3), (cowboy shot), (3koma+:1.2) 

 
 ## ぶっかけ
, { 2::(looking away:1.5) | face down | looking at viewer } BREAK on ground 
{ 3-5$$tearing up | frown | surprised, panicking | streaming tears | cry | sad | scared | horror \(theme\) } , { 4::open mouth | clenched teeth  } , { (looking away:1.5) | looking at viewer } , sweat, (mucus:1.2) , 
wariza , bukkake,  cum on breasts,  facial ,  <lora:extreme_bukkake_v0.1-pony:1> frown , tearing up,  looking away ,  __nsp/my/angle__


### パンツ重視

{ doggystyle, from behind |   spread legs,  from below } ,   legs wrap tentacles ,   (surprised:1.2), tearing up,  streaming tears,  open mouth ,  <lora:better panties-v1:1> , light blue panties , (panties under pantyhose:1.1),  close-up crotch  ,  { arms wrap tentacles |   (covering panties:1.3) } 


### negative
 (insertion , tentacle insertion , missionary,  tentacle sex:1.3) 


 <!-- ( legs wrap tentacles:1.1) , { pussy , sex , tentacles sex } , pussy in tentacles , trembling, orgasm, cum in pussy, trembling, (trembling:1.3), -->

## 変数
${face=!{ 8-15$$  panicking | embarrassed | tearing up |  (sweat:0.8) | crying | tearing up | streaming tears | open eyes  | crying | sobbing |  scared | frown |  shouting | panicking | half-closed eyes }    ,(motion blur:1.2), ( motion lines,    trembling:1.3), { 2::open mouth | clenched teeth , orgasm,  trembling,  | (one eye closed:1.4)  , wavy mouth , trembling,  orgasm } , { 2::(looking away:1.5) | face down | looking at viewer } } 

## SEXテンプレ
 { 1-3$$orgasm | sweat |  heavy breathing | head tilt |  one eye closed | light smile |  trembling | spoken heart  }  , { sweat , orgasm, female orgasm  |  drooling,  embarrassed,  heavy breathing,  open mouth } , spread legs,   legs grab , multiple views, uterus   (trembling:1.3),  close-up face ,  ahegao ,  sex , pov , from below,  { legs grab | torso grab | hip grab } 

## 挿入見直し
on ground , tentacles , (many many tentacles , tentacle nest:1.1) ,
{ 3-5$$  panicking | embarrassed | tearing up |  (sweat:0.8) | crying | tearing up | streaming tears | open eyes  | crying | sobbing |  scared | frown |  shouting | (surprized:1.2) | half-closed eyes }    ,(motion blur:1.2), ( motion lines,    trembling:1.3), { 4::open mouth | clenched teeth , orgasm,  trembling,  | (one eye closed:1.4)  , wavy mouth , trembling,  orgasm } , { 2::(looking away:1.5) | face down | looking at viewer } BREAK
 { missionary vaginal, spread legs,  deep insertion , huge tentacles  , missionary ,  { arms up  | covering breasts | arms behind head |  gangbang,  grabbing tentacles  }  | (from behind:1.3) , leaning forward,  (wall:1.1) , (touch the wall  , wall on hands:1.2) | 1.5:: all fours,  doggystyle, { front , close-up face  |  from behind , pussy vaginal  , ass , spread legs } |  knees together feet apart, sitting, arms up , restrained tentacles,  arms wrap tentacles   |  straddling , cowgirl position, { spread legs |  squatting } , { front |  from below , ceiling | from above } }  , tentacles sex , large insertion , deep insertion ,   close-up pussy in tentacles ,  (tentacles in pussy:1.2) , tentacles in vaginal ,  tentacles sex , multiple insertion , large insertion ,  {1-3$$ legs wrap tentacles | torso wrap tentacles | tentacles wrap breasts | arms wrap tentacles } ,  { 2-3$$sweat | (multiple views, split view:1.2) | 1.5::xray , tentacles in uterus | cum in pussy  | 1.2::(bukkake,  cum on body,  cum on breasts,  facial, nipples:1.2)  }  , { sweat |   <lora:HDA_TentacleSexXL_v1.2:0.8>HDA_TentacleSexXL_v1.2 } 


( doggystyle, all fours,    from behind , ass focus  :1.4),  close-up , pussy , anus , tentacle sex , orgasm,  pussy juice ,   (double penetration:1.2),  from below , dynamic angle ,  (multiple views,  close-up pussy :1.3) , HDA_CowgirlPositionXL  , arms wrap tentacles , legs wrap tentacles , restrained,   gangbang, 

## 挿入見直し2
spread legs, (directly below:1.3) , (trembling, motion lines:1.5),  ass focus ,  (tentacles in pussy:1.2) , tentacles in vaginal ,  tentacles sex , double  penetration, deep penetration,  large insertion ,  {2-3$$ legs wrap tentacles | torso wrap tentacles | tentacles wrap breasts } , { 2.5::sweat | 1::(multiple views , close-up pussy:1.2) }   ,  (breastfeeding:1.2),  {2-3$$ (double  penetration:1.2) |spread anus | (irrumatio:1.2),  (drooling:1.3) }  , { arms up | reaching | arms behind back }  , (arms wrap tentacles:1.3) 

## 挿入見直し3 四つん這い
{top-down bottom-up | doggystyle,  all fours } , irrumatio, (trembling, motion lines:1.5),  ass focus ,  (tentacles in pussy:1.2) , tentacles in vaginal ,  tentacles sex , double  penetration, deep penetration,  large insertion ,  {1-3$$ legs wrap tentacles | torso wrap tentacles | tentacles wrap breasts } , { 2.5::sweat | 1::(multiple views , close-up pussy:1.2) }   ,  (breastfeeding:1.2),  {2-5$$(from below:1.3) | spread legs | (double  penetration:1.2) |spread anus | (irrumatio:1.2),  (drooling:1.3) } 
## 搾乳

cowboy shot , leaning forward, arms up, restrained,   standing ,   nipples,   <lora:extreme_bukkake_v0.1-pony:1> <lora:milking_Pony_V1.0:1:stop=10>syokusyu, lactation, milking machine,  tentacles ,  milking tentacles,  legs wrap tentacles  , spread legs,  upper body,  close-up breasts,  tentacle sex ,  { 4::sweat | 1.2::(trembling:1.3),  (multiple views,  close-up pussy:1.3) } 

## 合体
 {  panicking , surprised,  tearing up | tearing up , sobbing, streaming tears  , crying } , { sweat | embarrassed }  ,  (trembling:1.1), { open mouth | 1.5::clenched teeth | (one eye closed:1.4)  , wavy mouth  } , { 2::(looking away:1.5) | face down | looking at viewer } , BREAK 
 in cave , tentacle nest , tentacle pit 
{
  {
    { doggystyle,  all fours } , irrumatio, (trembling, motion lines:1.5),  ass focus ,  (tentacles in pussy:1.2) , tentacles in vaginal ,  tentacles sex ,  {1-3$$ legs wrap tentacles | torso wrap tentacles | tentacles wrap breasts } , { sweat | 1.2::(multiple views , close-up pussy:1.2) }   ,  from side , anus insertion , ass insertion ,  (irrumatio:1.3),  arms wrap tentacles , (cum in pussy , cum in mouth , cum in ass , bukkake,  cum on breasts,  cum on body,  facial:1.2) , surprised,    
  } | 
 2::{ 
sitting ,   spread legs, (directly below:1.3) , (trembling, motion lines:1.5),  ass focus ,  (tentacles in pussy:1.2) , tentacles in vaginal ,  tentacles sex ,  {2-3$$ legs wrap tentacles | torso wrap tentacles | tentacles wrap breasts } , { 2.5::sweat | 1::(multiple views , close-up pussy:1.2) }   ,  (breastfeeding:1.2),  {2-3$$ (double  penetration:1.2) |spread anus | (irrumatio:1.2)}  , { arms up | reaching | arms behind back }  , (arms wrap tentacles:1.3) 

 } |
 {
  {top-down bottom-up | doggystyle,  all fours } , irrumatio, (trembling, motion lines:1.5),  ass focus ,  (tentacles in pussy:1.2) , tentacles in vaginal ,  tentacles sex , {1-3$$ legs wrap tentacles | torso wrap tentacles | tentacles wrap breasts } , { 2.5::sweat | 1::(multiple views , close-up pussy:1.2) }   ,  (breastfeeding:1.2),  {2-5$$(from below:1.3) | spread legs | (double  penetration:1.2) |spread anus | (irrumatio:1.2) }
 } 
}  , cum in pussy,  bukkake,  cum on breasts,  facial ,  (sound effects,  mosaic censoring:1.2),   close-up pussy ,  { sweat |  (ceiling,  from below:1.3),  (open mouth:1.2) }   {  double  penetration |  2::deep penetration} , large insertion

## 挿入見直し4
sitting  , spread legs,  , irrumatio,  directly below  ,  (trembling, motion lines:1.5),  ass focus ,  (tentacles in pussy:1.2) , tentacles in vaginal ,  tentacles sex , double  penetration, deep penetration,  large insertion ,  {1-3$$ legs wrap tentacles | torso wrap tentacles | tentacles wrap breasts } , { 2.5::sweat | 1::(multiple views , close-up pussy:1.2) }  

## 挿入 , その他
spread legs, sole ,   arms up , restrained,  cum explosion,  (trembling, motion lines:1.5),    cum in pussy,  , tentacle is penis , penis in pussy ,  tentacles sex , large insertion , deep insertion ,  gangbang,  grabbing tentacles,   close-up pussy in tentacles ,  ass focus , (looking away,:1.3) , (tentacles in pussy:1.2) , tentacles in vaginal ,  tentacles sex , multiple insertion , large insertion ,  {1-3$$ legs wrap tentacles | torso wrap tentacles | tentacles wrap breasts } , { 2.5::sweat | 1.5::(multiple views , close-up pussy:1.2) }  , __nsp/my/angle__

## 挿入漫画風
doggystyle,  all fours  ,   spread legs, (directly below:1.3)  , top-down bottom-up  doggystyle,  all fours  
irrumatio, (trembling, motion lines:1.5),  ass focus ,  (tentacles in pussy:1.2) , tentacles in vaginal ,  tentacles sex , double  penetration, deep penetration,  large insertion ,  legs wrap tentacles , torso wrap tentacles , tentacles wrap breasts  BREAK , 
<lora:FComic_HardCore_Pony_V1:1:stop=30>,(Multi view, Frame, Text, speech bubble, frame, heart, trembling, focus line, vibrating line, comic expression, Sound effect), 
1girl, solo focus, breasts, navel, nipples, pussy, clitoris, vaginal, anus, ass, nude, torn clothes, pussy juice , motion lines,  motion blur,  cum in pussy, 


## フェラ

in cave ,  . facial,  cum on breasts,  cum on body,  facial , cum in mouth  <lora:extreme_bukkake_v0.1-pony:1> , 
{ licking tentacle | tentacle irrumatio | irrumatio }  , { 2:: from above , looking at viewer,   |  kneeing,  from side   }  upper body, { arms up |   grab tentacle  }   drooling, 
  { 1.5::(ecstasy:1.3) , orgasm  | 0.2::HDA_AhegaoXL , saliva }  ,  drooling  trembling,  (sweat:1.2),  heavy breathing  , open mouth,  cum in throat,  throat , (ecstasy:1.2), 



## 漫画
<lora:FComic_1to1000_Pony_V1:1:stop=10>fcomic_1to1000_pony, (comic:1.25),
(Multi view, Frame, Text, speech bubble, frame, heart, trembling, focus line, vibrating line, comic expression, Sound effect)
1girl, solo focus, breasts, navel, nipples, pussy, clitoris, vaginal, anus, ass, nude, torn clothes, pussy juice,  trembling,  
spread legs, (directly below:1.3)  ,  doggystyle,  all fours, irrumatio, gangbang,  rape,  (trembling, motion lines:1.5),  ass focus ,  (tentacles in pussy:1.2) , tentacles in vaginal ,  tentacles sex , double  penetration, deep penetration,  large insertion ,  {1-3$$ legs wrap tentacles | torso wrap tentacles | tentacles wrap breasts } , anus insertion , ass insertion ,  (irrumatio:1.3),  arms wrap tentacles , (cum in pussy , cum in mouth , cum in ass , bukkake,  cum on breasts,  cum on body,  facial:1.2) , {1.5::crying , sobbing , streaming tears | scared , surprised } , tearing up 



## 挿入簡略
{ 1-2$$sweat | (multiple views, split view:1.2) | 3::(xray , tentacles in uterus:1.3) | cum in pussy }  ,   , tentacle sex ,  (HDA_TentacleSexXL_v1.2:0.8), { 1-3$$legs wrap tentacles | amrs wrap tentacles | torso wrap tentacles }  , tentacles sex ,  { <lora:Bukkake:1>  | facial }  ,  { sitting , spread legs | doggystyle , { front | from below | from behind } | { cowgirl position | squatting | straddling | reverse upright straddle | upright straddle  | straddling paizuri } } , tentacles sex ,  

## 最後
pov   ,HDA_TentacleSexXL_v1.2 , paizuri , tentacle paizuri  , facial,  cum on breasts,  cum on body,  cum in pussy,   cum,  bukkake,  <lora:bukkake_v0.4:1> 

## レイプ目

{ licking tentacle | tentacle irrumatio | irrumatio }  , gangbang,  { squatting | straddling | reverse upright straddle | upright straddle |  cowgirl position }   double penetration , from below , ass ,  tentacle irrumatio,  tentacle handjob ,  
  { 1.5::(ecstasy:1.3) , orgasm  | 0.2::HDA_AhegaoXL , saliva }  ,  drooling  trembling,  (sweat:1.2),  heavy breathing  , open mouth,  cum in throat,  throat , (ecstasy:1.2),  ( sweat |  0.2::x-ray , uterus  |  (multiple views,   { 4::close-up pussy  | cum in uterus }:1.2) )  , (empty eyes:1.3),  spread ass, 

 thighhighs,black footwear,loafers , { sweat | torn clothes }  | 4::(nude , naked, completely nude) , black thighhighs }  , in cave ,   {  0.2::on back , from above  | on stomach , (from behind:1.2) , ass | top-down bottom-up , ass  , (from behind:1.2) }   facial,  cum on breasts,  cum on body,  facial , cum in mouth  bukkake,   ,   gangbang,  rape,  
{ licking tentacle }  , gangbang,   lying,  on ground , after sex,  HDA_AfterSexXL , cum explosion,  expressionless,    drooling  trembling,  (sweat:1.2),  heavy breathing  , open mouth,  cum in throat,  throat ,  cum explosion,    , (empty eyes:1.3),  spread ass,  { arms up | arms behind back | tentacle grab }  , 

## SEX汎用
(HDA_CowgirlPositionXL:0.7) , on bed ,  female orgasm,   sex ,  (female orgasm:1.3),  open mouth,   
 { 1-2$$wince |  (orgasm:1.5) |  heavy breathing | frown | half open mouth | drooling }   (trembling:1.4),  motion lines,   ( split view ,  cum in uterus:1.3) , tearing up,  close-up face  , HDA_AhegaoXL,  1boy , cowgirl position,  straddling,  (heavy breathing:1.2), 

## バック
on ground , tentacles , (many many tentacles , tentacle nest:1.1) ,
{ 8-15$$  panicking | embarrassed | tearing up |  (sweat:0.8) | crying | tearing up | streaming tears | open eyes  | crying | sobbing |  scared | frown |  shouting | panicking | half-closed eyes }    ,(motion blur:1.2), ( motion lines,    trembling:1.3), { 2::open mouth | clenched teeth , orgasm,  trembling,  | (one eye closed:1.4)  , wavy mouth , trembling,  orgasm } , { 2::(looking away:1.5) | face down | looking at viewer } BREAK
 doggystyle,  all fours,  drooling,  open mouth,  tearing up,  spread legs,  head down , legs wrap tentacles  , { sweat | (multiple views , close-up pussy:1.2) } , { sweat |   1.5::<lora:HDA_TentacleSexXL_v1.2:0.8>HDA_TentacleSexXL_v1.2 }  , uterus , uterus in cum 

## フェラ
on ground , tentacles , (many many tentacles , tentacle nest:1.1) ,
{ 8-15$$  panicking | embarrassed | tearing up |  (sweat:0.8) | crying | tearing up | streaming tears | open eyes  | crying | sobbing |  scared | frown |  shouting | panicking | half-closed eyes }   , { standing , armpits |  all fours,  doggystyle } , legs wrap tentacles ,   ( tentacles in mouth ,  tentacles irrumatio:1.3), { sweat  |   (cum in mouth , surprised,  streaming tears:1.2) }  open mouth,   drooling,   <lora:HDA_TentacleSexXL_v1.2:1>HDA_TentacleSexXL_v1.2 , { sweat | upper body }

## レイプ目
nsfw , on ground , tentacles , (many many tentacles , tentacle nest:1.1) , tentacle pit ,
(empty eyes,  expressionless:1.5),  drooling,  open mouth,  (cum in pussy , cum explosion,   bukkake , cum on body,  cum on breasts,  facial , after vaginal,  after sex:1.3),  steam,  heavy breathing,   (trembling:1.4),  (trembling:1.6) , , vaginal ,  after rape, { (from behind , ass  , all fours , doggystyle:1.2) | ( lying , on stomach:1.2) , spread legs,  full body , arms up , arms wrap tentacles , from above } , close-up crotch , tearing up,   on ground  , (looking away:1.7) ,  upper body,  legs wrap tentacles , 

## temp
### 立ちバック
from below, ass, standing , pussy , vaginal ,  , nose blush  ,  pussy juice,  ceiling,  , indoors,  in hotel 

## バック
nsfw , on ground , tentacles , (many many tentacles , tentacle nest:1.1) , tentacle pit ,
{ 8-15$$  panicking | embarrassed | tearing up |  (sweat:0.8) | crying | tearing up | streaming tears | open eyes  | crying | sobbing |  scared | frown |  shouting | panicking | half-closed eyes }  , <lora:HDA_TentacleSexXL_v1.2:1.2> (shot from behind. from behind, back view, side view:1.2), (tentacle sex:1.2), low angle ,  open arms  , restrained arms  , arms wrap tentacles , legs wrap tentacles  , from behind , hip ,  open mouth,  drooling,   purple eyes  , { x-ray , uterus in cum |  0.75::multiple views,  uterus in cum }

## くぱぁ

{ spread legs , from below , cervix , cervix perpose , pussy juice  | 
doggystyle,  (from behind , ass:1.2) ,  spread pussy,   pussy juice,   { 2::from below | front  }  } 


## 漫画風

### メス堕ち くぱぁ

<lora:FComic1To3Page_Pony_V1:1>
(3page),(comic),Multi view, Frame, Text, speech bubble, frame, heart, trembling, focus line, vibrating line, comic expression, Sound effect, 1girl, solo focus, skirt lift, shirt lift, show off nipple, show off pussy , nipple , pussy , hetero, oral,  (full body:1.3), (cowboy shot),
spread legs , from below , cervix , cervix perpose , pussy juice  ,   (from behind , ass:1.2) ,  spread pussy,   pussy juice,   { 2::from below | front  }   , spread legs,  from below ,cervix, 1girl , solo , 

### レイプ目

 thighhighs,black footwear,loafers , { sweat | torn clothes }  | 4::(nude , naked, completely nude) , black thighhighs }  , in cave ,  lying , on back , cum in pussy ,   from below   facial,  cum on breasts,  cum on body,  facial , cum in mouth  bukkake,   ,   gangbang,  rape,  
{ licking tentacle }  , gangbang,   lying,  on ground , after sex,  HDA_AfterSexXL , cum explosion,  expressionless,    drooling  trembling,  (sweat:1.2),  heavy breathing  , open mouth,  cum in throat,  throat ,  cum explosion,    , (empty eyes:1.3),  close-up pussy , (clitoris,  masturbation:1.2),  finger in pussy , 

<!-- 
## 挿入

 on ground ,    tentacles , (many many tentacles ,   tentacle nest:1.4) , tentacle pit <lora:Tentacles:0.65:0.5:lbw=ALL:stop=10> ,  tentacles  ,  (in tentacle pit:1.4) , faint light , in trapped  BREAK
 { {8-15$$(embarrassed, nose blush:1.3) |(trembling:1.3) | (motion lines , motion blur:1.3) | streaming tears | frown | disgust | tearing up |  (sweat:0.8) | open eyes  | crying | sobbing |  shouting | panicking | half-closed eyes |  scared  }  }  ,  { 2::(sweat:0.8) |  0.3::cumin pussy , cum on body , cum explosion  }  (trembling:1.1), { 4::open mouth,  wavy mouth |   clenched teeth | (one eye closed:1.4)  , wavy mouth   | shouting , sweat,   | close mouth }   BREAK
torn , cloths -->
<!-- 
## 正常位 サンプル
spread legs,  legs wrap tentacles , restrained legs , pussy vaginal , sex , tentacles sex , missionary ,  pussy in tentacles , front , (trembling:1.3), sex , pussy sex , tentacles in pussy, open pussy , large insertion , tentacle sex, tentacle pit, tentacles, large tentacle, thick tentacle ,  <lora:large_insertion_v0.1-000003:0.8>  tentacles, large insertion, large tentacle, thick tentacle , deep insertion

## 導入

{  sitting , hugging own legs,  on ground , (white panties:1.3), (knees together feet apart,:1.3)  | { from above | from below } , { skirt lift,  ({ pink panties | white panties }:1.3) ,  lingerie } ,upper body, { lying | standing }  ,  { covering breasts |  arms up  }  }  -->

## メス落ち見直し
 { 5-6$$(embarrassed:0.8) |  | (trembling:1.4)| (tears:0.7) |(drooling:0.8) | (sweat:0.8) | open eyes | fucked silly  }  ,  { 1.5::sweat | 0.5::cum in pussy , cum on body , cum explosion , ecstasy ,  orgasm , female orgasm  }   , (trembling:1.1), { close mouth | open mouth } , { 1-3$$fucked silly  embarrassed |  (heavy breathing:1.2) , light smile | ahegao }  , { 2::sweat | spoken heart }  , (heart-shaped pupils:1.2),  drooling ,  pink eyes, (trembling:1.2) , motion lines,  pussy , vaginal , tentacles , in pussy BREAK
 { missionary vaginal, spread legs,  deep insertion , huge tentacles  , missionary ,  { arms up  | covering breasts | arms behind head |  gangbang,  grabbing tentacles  }  | (from behind:1.3) , leaning forward,  (wall:1.1) , (touch the wall  , wall on hands:1.2) | 1.5:: all fours,  doggystyle, { front , close-up face  |  from behind , pussy vaginal  , ass , spread legs } |  knees together feet apart, sitting, arms up , restrained tentacles,  arms wrap tentacles   |  straddling , cowgirl position, { spread legs |  squatting } , { front |  from below , ceiling | from above } }  , tentacles sex , large insertion , deep insertion ,   close-up pussy in tentacles ,  (tentacles in pussy:1.2) , tentacles in vaginal ,  tentacles sex , multiple insertion , large insertion ,  {1-3$$ legs wrap tentacles | torso wrap tentacles | tentacles wrap breasts } ,  { 1-3$$sweat | (multiple views, split view:1.2) | xray , tentacles in uterus | cum in pussy , uterus in pussy }


## メス落ち2
on ground , tentacles , (many many tentacles , tentacle nest:1.1) ,
 { 5-6$$(embarrassed:0.8) |  | (trembling:1.4)| (tears:0.7) |(drooling:0.8) | (sweat:0.8) | open eyes | fucked silly  }  ,  { 1.5::sweat | 0.5::cum in pussy , cum on body , cum explosion , ecstasy ,  orgasm , female orgasm  }   , (trembling:1.1), { close mouth | open mouth } , { 1-3$$fucked silly  embarrassed |  (heavy breathing:1.2) , light smile | ahegao }  , { 2::sweat | spoken heart }  , (heart-shaped pupils:1.2),  drooling ,  pink eyes, (trembling:1.2) , motion lines,  pussy , vaginal , tentacles , in pussy BREAK , motion lines,  pussy , vaginal , tentacles , in pussy BREAK
 <lora:HDA_TentacleSexXL_v1.2:0.75>HDA_TentacleSexXL_v1.2 ,    doggystyle,  from behind ,  ass , (  uterus  ,  multiple views :1.2) ,  tentacle on nipples,  inhaling nipples, 


 { 2-3$$  light smile | orgasm |  ahegao | fucked silly  | tearing up |  open eyes  |  shouting |  one eye closed } ,  ,   { 1.5::sweat | 0.5::cum in pussy , cum on body , cum explosion , ecstasy ,  orgasm , female orgasm  }   , (trembling:1.1), { close mouth | open mouth } ,  { 2::sweat | spoken heart }  , { sweat |  (heart-shaped pupils:1.2) } ,  drooling ,  { purple eyes |  pink eyes } , (trembling:1.2) , motion lines,  pussy , vaginal , tentacles , in pussy BREAK
{ 2-3$$ open mouth |  orgasm,  trembling,  | (one eye closed:1.4)  , wavy mouth }  , trembling, female  orgasm  , { 2::(looking away:1.5) | face down | looking at viewer } BREAK
 { sitting , spread legs , { 2::arms up , arms wrap tentacles ,  restrained | sweat } , legs wrap tentacles | knees together feet apart, sitting, | lying , from behind ,  ass , spread legs, on stomach , legs wrap tentacles , looking at viewer | doggystyle, all fours, from behind , ass , legs wrap tentacles | standing , (spread legs:1.3), (focus crotch:1.1) , (directly below:1.3) , (from below:1.2) , { 2::arms up ,  arms wrap tentacles , restrained | sweat } , legs wrap tentacles }  ,  { sweat |   <lora:HDA_TentacleSexXL_v1.2:0.8>HDA_TentacleSexXL_v1.2 }  , { sweat | multiple views , { close-up pussy |   uterus , uterus in cum }  }



## オマンコ見せ
  { 5-6$$(embarrassed:0.8) |  | (trembling:1.4)| (tears:0.7) |(drooling:0.8) | (sweat:0.8) | open eyes | fucked silly  }  , { light smile | 2::ahegao }   , heavy breathing,   lying  , spread legs , pussy   ,  open pussy , (hands spread pussy ,   spread pussy:1.3) ,   hands on pussy , embarrassed,  ceiling , from below ,   close-up pussy  ,  pussy juice,  

 { 5-6$$(embarrassed:0.8) |  | (trembling:1.4)| (tears:0.7) |(drooling:0.8) | (sweat:0.8) | open eyes | fucked silly  }  ,  {  ecstasy ,  orgasm , female orgasm  }   , (trembling:1.1), { close mouth | open mouth | wavy mouth } ,  { 2::sweat | spoken heart }  , heavy breathing,  steam ,  (heart-shaped pupils:1.4),  drooling ,  pink eyes, (trembling:1.2) , motion lines,  pussy , vaginal  BREAK
 looking at viewer,  fucked silly, drooling, ,   from behind , close-up pussy ,  (spread pussy,  hands spread pussy:1.3)  , spread legs,  front , pov , uterus , pussy juice , { ahegao ,  | light smile , (head tilt:1.2)}  <lora:cervix_Pony_V1.0:0.55> spread pussy, (cervix , cervix prolapse:1.2)


 spread legs , from below , <lora:cervix_Pony_V1.0:0.9:stop=10>  cervix , cervix perpose , pussy juice  ,  { from below |  (from behind , ass:1.2) }   spread pussy,   (pussy juice:1.2),   spread legs,  from below , spread pussy,  open mouth,  (heavy breathing,  orgasm,  ecstasy:1.3), ( imminent penetration:1.2), 

### バック
 looking at viewer,   all fours,  doggystyle,  (from behind , pov :1.2) , ass , from below ,   pussy juice , { ahegao ,  | light smile , (head tilt:1.2)} ,   spread pussy , open mouth,  heavy breathing,  (cum on breasts,  cum on body,  facial,:1.2) 

 ## メス落ちレイプ
 { ucked silly , orgasm , female orgasm  | 2::drooling , ahegao }  , {  sweat | trembling |  open mouth | surprised  |  shouting |  one eye closed | drooling  } ,   { 1.5::sweat | 0.5::cum in pussy , cum on body , cum explosion , ecstasy ,  orgasm , female orgasm  }  , (trembling:1.1) ,  { 2::sweat | spoken heart }  , { sweat |  (heart-shaped pupils:1.2) } ,  drooling ,  { purple eyes |  pink eyes } , (trembling:1.2) , BREAK
 __nsp/my/angle__ ,  gangbang,   bukkake, cum on breasts,  cum on body,  facial , open mouth, drooling   { licking tentacles |   (irrumatio:1.3),  tenacle is penis , penis in mouth  | sweat  } ,  cum injection,  cum in mouth ,  deep insertion , <lora:HDA_TentacleSexXL_v1.2:0.8>HDA_TentacleSexXL_v1.2  , arms wrap tentacles , heavy breathing,   nipple on tentacle ,  { sweat , heavy breathing  |  0.8:: { light smile | surprised } ,  (multiple views,  cum in uterus:1.3) } 

### 寝バック
 { ucked silly , orgasm , female orgasm  | 2::drooling , ahegao }  , {  sweat | trembling |  open mouth | surprised  |  shouting |  one eye closed | drooling  } ,   { 1.5::sweat | 0.5::cum in pussy , cum on body , cum explosion , ecstasy ,  orgasm , female orgasm  }  , (trembling:1.1) ,  { 2::sweat | spoken heart }  , { sweat |  (heart-shaped pupils:1.2) } ,  drooling ,  { purple eyes |  pink eyes } , (trembling:1.2) , BREAK
 lying , on stomach,  top-down bottom-up,  on ground ,  bukkake, cum on breasts,  cum on body,  facial , open mouth, drooling  ,   cum injection,  cum in mouth ,  deep insertion , <lora:HDA_TentacleSexXL_v1.2:0.4>HDA_TentacleSexXL_v1.2  ,  heavy breathing,   { sweat , heavy breathing  |  2:: { crying |  surprised } ,  (multiple views,  cum in uterus:1.3) }  , <lora:HDA_Doggystyle_HairPulledBackXL:1>HDA_Doggystyle_HairPulledBackXL , 


### なめ
open mouth,  cleavage,  collarbone,  (open mouth,  heavy breathing:1.3),  facial ,   arms behind back , heavy breathing,  (head tilt:1.3),  (close-up face  , upper body:1.3),   all fours,  licking penis,  tongue out,  facial,   tentacle grab, from side , 

open mouth,  cleavage,  collarbone,  (open mouth,  heavy breathing:1.3),  facial ,  heavy breathing,  (head tilt:1.3),  (close-up face  , upper body:1.3),  light smile , leaning forward,  ( from above ,  cum in throat, heavy breathing,  cum in mouth :1.2),  bukkake,  facial , cum on breasts,   tongue out,  facial,   tentacle grab, from side , 

#### 泣き
(ecstasy,  orgasm:1.3),  heavy breathing,  open mouth,  cleavage,  collarbone,  (open mouth,  heavy breathing:1.1),  facial ,  heavy breathing,  tearing up,  facial,  bukkake, <lora:extreme_bukkake_v0.1-pony:1:stop=10>   cum on breasts,  cum on body,  streaming tears,  sobbing,  (close-up face  , upper body:1.3),  (scared , surprised:1), leaning forward,  ( from above ,  cum in throat, heavy breathing,  cum in mouth :1.2),  bukkake,  facial , cum on breasts,   tongue out,  facial,   tentacle grab, from side , 


## 後ろ挿入おねだり
(from behind:1.2) , all fours,  doggystyle,   looking at viewer,  heavy breathing,  open mouth,  spread  ass ,   close-up pussy , 

## オナニー
masturbation,  female masturbation,  pussy juice,  pussy in finger , { spread legs |  all fours,  from behind , ass ,  | lying  , from below } , from below , close-up pussy 

<!-- {  missionary vaginal, spread legs,  deep insertion , huge tentacles  , missionary , | (from behind:1.3) , leaning forward,  (wall:1.1) , (touch the wall  , wall on hands:1.2) ,   |  4::all fours,  doggystyle, { 2::from behind  | front } , pussy vaginal , ass , spread legs |  knees together feet apart, sitting, arms up , restrained tentacles,  arms wrap tentacles  | { lying, missionary ,  {arms up | arms behind head | arms behind back  }   |  2::straddling , cowgirl position, squatting,  from below,  ceiling  } | spread legs, sole ,   arms up , restrained,  cum explosion,  (trembling, motion lines:1.5), __nsp/my/angle__ ,   cum in pussy  } , tentacle is penis , penis in pussy ,  tentacles sex , large insertion , deep insertion ,  gangbang,  grabbing tentacles,   close-up pussy in tentacles ,  ass focus ,  looking at viewer,  , (tentacles in pussy:1.2) , tentacles in vaginal ,  tentacles sex , multiple insertion , large insertion ,  {1-3$$ legs wrap tentacles | torso wrap tentacles | tentacles wrap breasts }  ,  (bukkake,  cum on body,  cum on breasts,   facial:1.3),  __nsp/my/angle__ , multiple views,  -->

## 口の中に出す
nsfw , on ground , tentacles , (many many tentacles , tentacle nest:1.1) , tentacle pit , sweat , steam,  
mouth in tentacles  , ahegao , sweat,  bukkake ,  ecstasy,  irrumatio , close-up face , upper body,  from above ,  projectile cum , cum on tongue, 

## フェラ2
 { 5-6$$(embarrassed:0.8) |  | (trembling:1.4)| (tears:0.7) |(drooling:0.8) | (sweat:0.8) | open eyes | fucked silly  }  ,  { 1.5::sweat | 0.5::cum in pussy , cum on body , cum explosion , ecstasy ,  orgasm , female orgasm  }   , (trembling:1.1), { close mouth | open mouth | wavy mouth } , { 1-3$$:light smile |  frown | embarrassed |  (heavy breathing:1.2)     | ahegao }  , { 2::sweat | spoken heart }  , (heart-shaped pupils:1.2),  drooling ,  pink eyes, (trembling:1.2) , motion lines,  pussy , vaginal , tentacles , in pussy BREAK
nsfw , tentacle nest , sitting , from side ,   wariza  
pov , from above , close-up face , tentacles in mouth , facial ,  open mouth,  { licking tentacles |   (irrumatio:1.3),  tenacle is penis , penis in mouth  } , cum injection,  cum in mouth ,  deep insertion 

## 終わり
lying , on ground ,  empty eyes,  open mouth,  drooling,  trembling,  bukkake,  cum on breasts,  cum in pussy,  cum explosion,  spread legs,  { from side | from above }  , { sweat  |  spread pussy } 


## 正面
all fours,  doggystyle,  front , close-up  face , pov , 

<!-- 
## メス堕ち
 tentacles , (many many tentacles ,   tentacle nest:1.4) , tentacle pit <lora:Tentacles:0.65:0.5:lbw=ALL:stop=10> ,  tentacles  ,  (in tentacle pit:1.4) , faint light , in trapped  BREAK
 { 5-6$$(embarrassed:0.8) |  | (trembling:1.4)| (tears:0.7) |(drooling:0.8) | (sweat:0.8) | open eyes | fucked silly  }  ,  { sweat | 1.5::(cum in pussy , cum on body , cum explosion , ecstasy ,  orgasm , female orgasm:1.4)  } , (tentacles in vaginal:1.5)  , (motion lines,  motion blur,  trembling,:1.8) , (trembling:1.1), {1-2$$ open mouth | wavy mouth } , ,{ 1-3$$:light smile |  embarrassed   | ahegao }  , (heavy breathing:1.2) , sweat , spoken heart , (heart-shaped pupils:1.2),  drooling ,  pink eyes, (multiple insertion , large insertion:1.3) ,  (trembling,  pussy juice,  ecstasy:1.8), -->


## SEX系

###  正常位
spread legs,  pussy , vaginal , arms on breasts,  love hotel , night ,  dark light    light smile , heavy breathing , embarrassed,  ecstasy,  spread legs,    open mouth,  pussy pussy juice, drooling,  
1boy , sex ,  missionary,  sex , deep insertion , penis , penis in pussy , trembling,   motion lines,  <lora:missionary:1:lbw=ALL:stop=10>missionary , lying , on bed , pillow  ,  cum in pussy  , m legs , sole ,  ( large insertion,  deep insertion:1.4)

### バック
(from behind:1.3) , standing , (wall:1.1) , (touch the wall  , wall on hands:1.2) ,  standing,  ass focus ,  pussy , rear pussy,  (looking away,:1.3)  ,  (ass focus:1.2) , { doggystyle,  all fours | 2::leaning forward , (ass focus:1.3) }  , open mouth , (despair face :1.1),  pussy , vaginal , (peeing:1.2), ( tentacles in pussy ,:1.2) 

### バック2
from behind , all fours,  doggystyle,  (tentacles in vaginal:1.5)  , (motion lines,  motion blur,  trembling,:1.8) 


### 正常位
{ lying, , on back ,  missionary |  straddling , cowgirl position, from below,  ceiling } , missionary, vaginal, tentacles in vaginal , spread legs  , motion blur,  multiple views , pussy   ,   arms wrap tentacles ,  legs wrap tentacles , (tentacles extending from the ground in pussy:1.3) , ( motion effect ,  intense insertion ,  orgasm climax trembling ,  trembling:1.4) , ( tentacles in pussy ,:1.5) , sex ,  focus crotch ,  cum in pussy , ( __nsp/my/angle__ , close-up face:1.5) , upper body 


### 正常位3
{ lying, missionary ,  {arms up | hands on own chest  |  breasts squeezed together }   |  straddling , cowgirl position, from below,  ceiling  ,  { sweat | hands on own chest  |  breasts squeezed together } } missionary, vaginal, tentacles in vaginal , spread legs ,, motion blur,  ( motion effect ,  intense insertion ,  orgasm climax trembling ,  trembling:2)

### 騎乗位

squatting cowgirl position, vaginal, pov, pussy in vaginal , cum in pussy,  cum in pussy,  tentacles in vaginal  , (motion lines,  motion blur,  trembling,:1.3) 

### 横向き
{  (front:1.3) |  (from behind:1.3) }  , (prone bone:1.3),  ahegao,    pussy in tentacle ,  (lying on her stomach:1.3) , tearing up, top-down bottom-up , pussy focus , (tentacles in pussy:1.2)  , from side , 

### おまんこ開
lying  , spread legs , pussy   ,  open pussy , (hands spread pussy ,   spread pussy:1.3) ,   hands on pussy , light smile , embarrassed,  cum in pussy in

#### 立ち
hotel , spread legs,  standing , directly below  , from below , upper body,  spread legs , pussy  , open pussy , (hands spread pussy ,   spread pussy:1.3) ,   hands on pussy , light smile , embarrassed, (pussy juice:1.2) , (close up pussy , close up utels:1.3) 

## フェラ3

nsfw , on ground , tentacle , tentacle nest , tentacle pit , in cave 
{ 8-15$$  panicking | embarrassed | tearing up |  (sweat:0.8) | crying | tearing up | streaming tears | open eyes  | crying | sobbing |  scared |  shouting | panicking | half-closed eyes } ,  (surprised:1.2)     ,(motion blur:1.2),  heavy breathing,  
(tentalce irrumatio) , tentacle in mouth , (looking at another,  looking away:1.4), (bukkake,  cum on body,  facial,  cum on breasts:1.1),  { sweat |  (close-up face:1.2) }  , <lora:tentacles_Pony_V1.0:0.8> SHOKUSYU, TENTACLES,TENTACLES PIT  , { sweat |  cum in mouth , bukkake , facial }   {   (arms up  restrained:1.2) , { lying , on ground |  sitting , on ground  } , spread legs , lace panties |  all fours , doggystyle,  {  from side | __nsp/my/angle__  } }

## 四つん這い中だし
  (cum in pussy,  cum on body,  bukkake,  facial:1.4) , (from behind , all fours,  doggystyle:1.5)  , (close-up pussy :1.5),  (ass , open pussy ,  hand on own hip:1.3), 

## メス落ち汎用
 { 5-6$$(embarrassed:0.8) |  | (trembling:1.4)| (tears:0.7) |(drooling:0.8) | (sweat:0.8) | open eyes | fucked silly  }  ,  { 1.5::sweat | 0.5::cum in pussy , cum on body , cum explosion , ecstasy ,  orgasm , female orgasm  }   , (trembling:1.1), { close mouth | open mouth | wavy mouth } , { 1-3$$:light smile |  frown | embarrassed |  (heavy breathing:1.2)     | ahegao }  , { 2::sweat | spoken heart }  , (heart-shaped pupils:1.2),  drooling ,  pink eyes, (trembling:1.2) , motion lines,  pussy , vaginal , tentacles , in pussy BREAK
 tentacles , (many many tentacles ,   tentacle nest:1.4) , tentacle pit <lora:Tentacles:0.65:0.5:lbw=ALL:stop=10> ,  tentacles  ,  (in tentacle pit:1.4) , faint light , in trapped  BREAK


 { 5-6$$(embarrassed:0.8) |  | (trembling:1.4)| (tears:0.7) | (drooling:0.8) | (sweat:0.8) | open eyes | fucked silly  }  ,  { 1.5::sweat | 0.5::cum in pussy , cum on body , cum explosion , ecstasy ,  orgasm , female orgasm  }   , (trembling:1.1), { open mouth | closed mouth  | wavy mouth } , { 1-3$$:light smile |  frown |  heavy breathing | embarrassed   | ahegao } ,  { 2::sweat | spoken heart }  , (heart-shaped pupils:1.2),  drooling ,  pink eyes, (trembling:1.2) , motion lines,  pussy , vaginal , tentacles , in pussy BREAK
{ spread legs,  night front , lying , on bed  , spread pussy,  hands open pussy , uterus , ass  | from behind,  hands on hip , open pussy , all fours ,  pussy , doggystyle,  from behind , ass , close-up pussy , spread legs,  __nsp/my/angle__ | standing , front , from below ,  close-up pussy , directly below , hands on pussy , spread legs , spread pussy } , pussy,  orgasm,  ahegao,  { 2.5::sweat | multiple views }  ,  { 1-2$$multiple insertion | large insertion }  , deep insertion , cum in pussy , (bukkake,  cum on body,  cum on breasts,  facial , bukkake , cum on body:1.2),   (tentacle is penis , tentacles in pussy , tentacles sex:1.2)  , (heavy breathing,  steam:1.2)  ,  (gangbang,  rape:1.2),  
 
 ## 中田氏懇願
  { 5-6$$(embarrassed:0.8) |  | (trembling:1.4)| (tears:0.7) |(drooling:0.8) | (sweat:0.8) | open eyes | fucked silly  }  , lying  , spread legs , pussy   ,  open pussy , (hands spread pussy ,   spread pussy:1.3) ,   hands on pussy , light smile , embarrassed,  cum in pussy in

## 口に出される
  from above , (tearing up , streaming tears:1.3),   open mouth,  (cum in mouth:1.3) ,  close-up face ,  upper body,  (looking away:1.3) 

## バック
   all fours,  doggystyle, from behind  , from below ,   doggystyle,  pussy juice,  heavy breathing,  looking at viewer,  ass ,  close-up pussy 

   ## レイプ
   
 (many many tentacles , tentacle nest:1.4) ,, tentacles , (in tentacle pit:1.4) ,   heavy breathing, faint light , in trapped , <lora:Tentacles:0.25:0.25:lbw=NAME12:stop=5> , BREAK 
( empty eyes , expressionless,  :1.9),  streaming tears,  half open mouth BREAK
(gangbang:1.2),  rape,  grabbing tentacles , projectile cum,  squatting,  cowgirl position,  missionary  ,  (sex , tentacles in pussy:1.2) , (close-up face:1.2) , (trembling,  motion lines:1.7),  cowboy shot,   (multiple views:1.5)  , (cum in pussy,  cum on body, projectile cum, bukkake,  facial:1.9),  ( close-up pussy ,  tentacles in pussy:1.3) ,  (tentacles in mouth:1.3)